-- Perfil usado pelo site. Pode ser professor, palestrante, vendedor e por aí vai.
alter table public.comunicador
  add column if not exists genero text default 'nao_informado';

alter table public.comunicador
  add column if not exists atuacao text default 'palestrante';

-- O banco guarda somente o caminho; a imagem fica no Storage privado.
alter table public.comunicador
  add column if not exists foto_path text;

update public.comunicador
set genero = coalesce(genero, 'nao_informado'),
    atuacao = coalesce(atuacao, 'palestrante');

alter table public.comunicador
  alter column genero set default 'nao_informado',
  alter column genero set not null,
  alter column atuacao set default 'palestrante',
  alter column atuacao set not null;

-- Quando o Supabase Auth cria alguém, este gatilho monta o perfil do site.
create or replace function public.criar_comunicador_apos_cadastro()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.comunicador (id, nome, email, instituicao, genero, atuacao)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'nome', ''), split_part(new.email, '@', 1)),
    new.email,
    new.raw_user_meta_data ->> 'instituicao',
    coalesce(nullif(new.raw_user_meta_data ->> 'genero', ''), 'nao_informado'),
    coalesce(nullif(new.raw_user_meta_data ->> 'atuacao', ''), 'palestrante')
  )
  on conflict (id) do update
    set nome = excluded.nome,
        email = excluded.email,
        instituicao = excluded.instituicao,
        genero = excluded.genero,
        atuacao = excluded.atuacao;

  return new;
end;
$$;

drop trigger if exists criar_comunicador_no_cadastro on auth.users;

create trigger criar_comunicador_no_cadastro
  after insert or update of email, raw_user_meta_data on auth.users
  for each row execute function public.criar_comunicador_apos_cadastro();

-- Completa perfis de usuários que já estavam no Auth antes deste script.
insert into public.comunicador (id, nome, email, instituicao, genero, atuacao)
select
  id,
  coalesce(nullif(raw_user_meta_data ->> 'nome', ''), split_part(email, '@', 1)),
  email,
  raw_user_meta_data ->> 'instituicao',
  coalesce(nullif(raw_user_meta_data ->> 'genero', ''), 'nao_informado'),
  coalesce(nullif(raw_user_meta_data ->> 'atuacao', ''), 'palestrante')
from auth.users
on conflict (id) do update
  set nome = excluded.nome,
      email = excluded.email,
      instituicao = coalesce(excluded.instituicao, public.comunicador.instituicao),
      genero = coalesce(excluded.genero, public.comunicador.genero),
      atuacao = coalesce(excluded.atuacao, public.comunicador.atuacao);

-- Cada pessoa só lê e edita o próprio perfil.
alter table public.comunicador enable row level security;

drop policy if exists comunicador_select_proprio on public.comunicador;
create policy comunicador_select_proprio
  on public.comunicador for select
  to authenticated
  using (id = (select auth.uid()));

drop policy if exists comunicador_update_proprio on public.comunicador;
create policy comunicador_update_proprio
  on public.comunicador for update
  to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

grant select on public.comunicador to authenticated;
grant update (nome, instituicao, genero, atuacao, foto_path) on public.comunicador to authenticated;

-- Fotos privadas: cada usuário pode ler e substituir apenas a própria.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'avatars',
  'avatars',
  false,
  3145728,
  array['image/png', 'image/jpeg', 'image/webp']
)
on conflict (id) do update
set public = excluded.public,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists avatar_select_proprio on storage.objects;
create policy avatar_select_proprio
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

drop policy if exists avatar_insert_proprio on storage.objects;
create policy avatar_insert_proprio
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

drop policy if exists avatar_update_proprio on storage.objects;
create policy avatar_update_proprio
  on storage.objects for update
  to authenticated
  using (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  )
  with check (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

-- Reuniões pessoais continuam privadas.
alter table public.sessao enable row level security;

drop policy if exists sessao_select_propria on public.sessao;
create policy sessao_select_propria
  on public.sessao for select
  to authenticated
  using (comunicador_id = (select auth.uid()));

drop policy if exists sessao_insert_propria on public.sessao;
create policy sessao_insert_propria
  on public.sessao for insert
  to authenticated
  with check (comunicador_id = (select auth.uid()));

drop policy if exists sessao_update_propria on public.sessao;
create policy sessao_update_propria
  on public.sessao for update
  to authenticated
  using (comunicador_id = (select auth.uid()))
  with check (comunicador_id = (select auth.uid()));

-- EXCEÇÃO TEMPORÁRIA: estas cinco sessões são dados de demonstração do TCC
-- e ficam visíveis após o login. Remova as seis políticas *_demonstracao/*_demo_select
-- quando o projeto deixar de precisar do botão de demonstração.
drop policy if exists sessao_select_demonstracao on public.sessao;
create policy sessao_select_demonstracao
  on public.sessao for select
  to authenticated
  using (comunicador_id = '11111111-1111-4111-8111-111111111111'::uuid);

-- As views são security invoker, então os dados que formam o resumo também
-- precisam de permissão de leitura. As políticas abaixo não liberam escrita.
drop policy if exists janela_demo_select on public.janela;
create policy janela_demo_select
  on public.janela for select to authenticated
  using (exists (
    select 1 from public.sessao s
    where s.id = janela.sessao_id
      and s.comunicador_id = '11111111-1111-4111-8111-111111111111'::uuid
  ));

drop policy if exists inferencia_demo_select on public.inferencia;
create policy inferencia_demo_select
  on public.inferencia for select to authenticated
  using (exists (
    select 1 from public.sessao s
    where s.id = inferencia.sessao_id
      and s.comunicador_id = '11111111-1111-4111-8111-111111111111'::uuid
  ));

drop policy if exists inferencia_dimensao_demo_select on public.inferencia_dimensao;
create policy inferencia_dimensao_demo_select
  on public.inferencia_dimensao for select to authenticated
  using (exists (
    select 1
    from public.inferencia i
    join public.sessao s on s.id = i.sessao_id
    where i.id = inferencia_dimensao.inferencia_id
      and s.comunicador_id = '11111111-1111-4111-8111-111111111111'::uuid
  ));

drop policy if exists participante_demo_select on public.participante;
create policy participante_demo_select
  on public.participante for select to authenticated
  using (exists (
    select 1 from public.sessao s
    where s.id = participante.sessao_id
      and s.comunicador_id = '11111111-1111-4111-8111-111111111111'::uuid
  ));

drop policy if exists alerta_demo_select on public.alerta_semaforo;
create policy alerta_demo_select
  on public.alerta_semaforo for select to authenticated
  using (exists (
    select 1 from public.sessao s
    where s.id = alerta_semaforo.sessao_id
      and s.comunicador_id = '11111111-1111-4111-8111-111111111111'::uuid
  ));

-- Os dashboards usam as views existentes, somente depois do login.
revoke all on public.v_resumo_sessao from anon;
revoke all on public.v_timeline_sessao from anon;
grant select on public.v_resumo_sessao to authenticated;
grant select on public.v_timeline_sessao to authenticated;

-- Demonstrações agora pertencem ao perfil real do Kayky, mas continuam separadas
-- das reuniões privadas por esta marca explícita.
alter table public.sessao
  add column if not exists is_demo boolean not null default false;

update public.comunicador
set nome = 'Kayky Pires',
    email = 'kaykyypiress@gmail.com',
    atuacao = 'Docente'
where id = '2aa7dbf5-0e16-4bdf-9873-df8a9256438e'::uuid;

update public.sessao
set comunicador_id = '2aa7dbf5-0e16-4bdf-9873-df8a9256438e'::uuid,
    is_demo = true
where comunicador_id = '11111111-1111-4111-8111-111111111111'::uuid
   or id in (
     '22222222-2222-4222-8222-000000000001'::uuid,
     '22222222-2222-4222-8222-000000000002'::uuid,
     '22222222-2222-4222-8222-000000000003'::uuid,
     '22222222-2222-4222-8222-000000000004'::uuid,
     '22222222-2222-4222-8222-000000000005'::uuid
   );

create or replace view public.v_resumo_sessao
with (security_invoker = true)
as
select
  s.id as sessao_id,
  s.comunicador_id,
  s.titulo,
  s.codigo,
  s.status,
  s.iniciada_em,
  s.encerrada_em,
  s.encerrada_em - s.iniciada_em as duracao,
  (select count(*) from public.participante p where p.sessao_id = s.id) as n_participantes,
  (select count(*) from public.inferencia i where i.sessao_id = s.id) as n_inferencias,
  (select count(*) from public.janela j where j.sessao_id = s.id and j.dimensao = 'engajamento') as n_janelas,
  (select avg(j.fracao_estado) from public.janela j where j.sessao_id = s.id and j.dimensao = 'engajamento') as fracao_engajado_media,
  (select avg(j.nivel_medio) from public.janela j where j.sessao_id = s.id and j.dimensao = 'engajamento') as engajamento_medio,
  (select count(*) filter (where j.cor = 'verde') from public.janela j where j.sessao_id = s.id and j.dimensao = 'engajamento') as janelas_verde,
  (select count(*) filter (where j.cor = 'amarelo') from public.janela j where j.sessao_id = s.id and j.dimensao = 'engajamento') as janelas_amarelo,
  (select count(*) filter (where j.cor = 'vermelho') from public.janela j where j.sessao_id = s.id and j.dimensao = 'engajamento') as janelas_vermelho,
  (select count(*) from public.alerta_semaforo a where a.sessao_id = s.id and a.cor <> 'verde') as n_alertas,
  s.is_demo
from public.sessao s;

drop policy if exists sessao_select_demonstracao on public.sessao;
create policy sessao_select_demonstracao
  on public.sessao for select
  to authenticated
  using (is_demo = true);

drop policy if exists janela_demo_select on public.janela;
create policy janela_demo_select
  on public.janela for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = janela.sessao_id and s.is_demo = true));

drop policy if exists inferencia_demo_select on public.inferencia;
create policy inferencia_demo_select
  on public.inferencia for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = inferencia.sessao_id and s.is_demo = true));

drop policy if exists inferencia_dimensao_demo_select on public.inferencia_dimensao;
create policy inferencia_dimensao_demo_select
  on public.inferencia_dimensao for select to authenticated
  using (exists (
    select 1 from public.inferencia i
    join public.sessao s on s.id = i.sessao_id
    where i.id = inferencia_dimensao.inferencia_id and s.is_demo = true
  ));

drop policy if exists participante_demo_select on public.participante;
create policy participante_demo_select
  on public.participante for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = participante.sessao_id and s.is_demo = true));

drop policy if exists alerta_demo_select on public.alerta_semaforo;
create policy alerta_demo_select
  on public.alerta_semaforo for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = alerta_semaforo.sessao_id and s.is_demo = true));

-- Visualizações montadas pelo usuário ficam disponíveis em qualquer dispositivo.
create table if not exists public.dashboard_visualizacao (
  comunicador_id uuid not null references public.comunicador(id) on delete cascade,
  id text not null,
  nome text not null,
  configuracao jsonb not null default '{}'::jsonb,
  atualizado_em timestamptz not null default now(),
  primary key (comunicador_id, id)
);

alter table public.dashboard_visualizacao enable row level security;

drop policy if exists dashboard_visualizacao_propria on public.dashboard_visualizacao;
create policy dashboard_visualizacao_propria
  on public.dashboard_visualizacao for all to authenticated
  using (comunicador_id = (select auth.uid()))
  with check (comunicador_id = (select auth.uid()));

grant select, insert, update, delete on public.dashboard_visualizacao to authenticated;

-- Preferências visuais da extensão. Não há nomes nem dados dos participantes:
-- somente escolhas de aparência vinculadas à conta do comunicador.
create table if not exists public.extensao_preferencia (
  comunicador_id uuid primary key references public.comunicador(id) on delete cascade,
  configuracao jsonb not null default '{}'::jsonb,
  atualizado_em timestamptz not null default now()
);

alter table public.extensao_preferencia enable row level security;

drop policy if exists extensao_preferencia_propria on public.extensao_preferencia;
create policy extensao_preferencia_propria
  on public.extensao_preferencia for all to authenticated
  using (comunicador_id = (select auth.uid()))
  with check (comunicador_id = (select auth.uid()));

grant select, insert, update, delete on public.extensao_preferencia to authenticated;

-- Anotações de momentos importantes. Somente o dono da reunião pode vê-las e alterá-las.
create table if not exists public.anotacao_sessao (
  id bigint generated by default as identity primary key,
  sessao_id uuid not null references public.sessao(id) on delete cascade,
  comunicador_id uuid not null references public.comunicador(id) on delete cascade,
  instante timestamptz not null,
  fim timestamptz,
  texto text not null check (char_length(texto) between 1 and 280),
  criado_em timestamptz not null default now()
);

alter table public.anotacao_sessao
  add column if not exists fim timestamptz;

alter table public.anotacao_sessao enable row level security;

drop policy if exists anotacao_sessao_propria on public.anotacao_sessao;
create policy anotacao_sessao_propria
  on public.anotacao_sessao for all to authenticated
  using (
    comunicador_id = (select auth.uid())
    and exists (select 1 from public.sessao s where s.id = anotacao_sessao.sessao_id and s.comunicador_id = (select auth.uid()))
  )
  with check (
    comunicador_id = (select auth.uid())
    and exists (select 1 from public.sessao s where s.id = anotacao_sessao.sessao_id and s.comunicador_id = (select auth.uid()))
  );

grant select, insert, update, delete on public.anotacao_sessao to authenticated;

-- PRIVACIDADE FINAL: reuniões pessoais continuam restritas ao proprietário.
-- Somente registros explicitamente marcados com is_demo ficam disponíveis
-- para todas as contas autenticadas.
drop policy if exists sessao_select_demonstracao on public.sessao;
create policy sessao_select_demonstracao on public.sessao for select to authenticated using (is_demo = true);

drop policy if exists janela_demo_select on public.janela;
create policy janela_demo_select on public.janela for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = janela.sessao_id and s.is_demo = true));

drop policy if exists inferencia_demo_select on public.inferencia;
create policy inferencia_demo_select on public.inferencia for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = inferencia.sessao_id and s.is_demo = true));

drop policy if exists inferencia_dimensao_demo_select on public.inferencia_dimensao;
create policy inferencia_dimensao_demo_select on public.inferencia_dimensao for select to authenticated
  using (exists (
    select 1 from public.inferencia i join public.sessao s on s.id = i.sessao_id
    where i.id = inferencia_dimensao.inferencia_id and s.is_demo = true
  ));

drop policy if exists participante_demo_select on public.participante;
create policy participante_demo_select on public.participante for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = participante.sessao_id and s.is_demo = true));

drop policy if exists alerta_demo_select on public.alerta_semaforo;
create policy alerta_demo_select on public.alerta_semaforo for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = alerta_semaforo.sessao_id and s.is_demo = true));

drop policy if exists sessao_delete_propria on public.sessao;
create policy sessao_delete_propria
  on public.sessao for delete
  to authenticated
  using (comunicador_id = (select auth.uid()));

grant delete on public.sessao to authenticated;
grant usage, select on sequence public.anotacao_sessao_id_seq to authenticated;
