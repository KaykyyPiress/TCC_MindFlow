-- Diagnóstico seguro e somente leitura para o histórico da extensão.
-- O resultado esperado é true nas quatro colunas.

select
  to_regclass('public.v_timeline_sessao') is not null as timeline_pronta,
  has_function_privilege(
    'anon',
    'public.entrar_sessao(text,text,jsonb)',
    'execute'
  ) as anon_pode_entrar,
  has_function_privilege(
    'anon',
    'public.registrar_inferencia(uuid,text,timestamp with time zone,jsonb,text,real,real,integer)',
    'execute'
  ) as anon_pode_registrar,
  has_function_privilege(
    'anon',
    'public.sair_sessao(uuid,text)',
    'execute'
  ) as anon_pode_sair;
