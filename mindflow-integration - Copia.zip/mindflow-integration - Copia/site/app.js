// Login, reuniões e dashboards conversam com o Supabase.
// A coleta ainda pode virar extensão, aplicativo ou API sem mexer nessas telas.
const appShell = document.querySelector('#appShell');
const views = [...document.querySelectorAll('[data-view]')];
const navItems = [...document.querySelectorAll('.nav-item')];
const floatingFallback = document.querySelector('#floatingFallback');
const supabaseSettings = window.MINDFLOW_SUPABASE;
const db = window.supabase && supabaseSettings
  ? window.supabase.createClient(supabaseSettings.url, supabaseSettings.anonKey)
  : null;
const dataApi = db && window.createMindFlowData ? window.createMindFlowData(db) : null;
let currentView = 'landing';
let viewHistory = [];
let waitingTimer;
let meetingTimer;
let metricsTimer;
let meetingSeconds = 0;
let pipWindow = null;
let authMode = 'login';
let signedInUser = null;
let currentMeetingId = null;
let selectedSummaryId = null;
let accountMeetings = [];
let overviewFinishedMeetings = [];
let overviewComparisonSelection = new Set();
let overviewComparisonPreset = 'essential';
let overviewComparisonDetails = new Map();
let overviewComparisonRenderToken = 0;
let overviewDashboardLayouts = [];
let activeOverviewDashboardLayoutId = 'overview-normal';
let editingOverviewDashboardOrder = [];
let editingOverviewDashboardVisible = new Set();
let editingOverviewDashboardSizes = {};
let draggedOverviewDashboardWidgetId = null;
let overviewResizeState = null;
let overviewDashboardEditorMode = 'create';
let pendingProfilePhoto = null;
let currentSummary = null;
let currentSummaryTimeline = [];
let filteredSummaryTimeline = [];
let timelineTableExpanded = false;
let chartTimeline = [];
let dashboardLayouts = [];
let activeDashboardLayoutId = 'normal';
let editingDashboardOrder = [];
let editingDashboardVisible = new Set();
let editingDashboardSizes = {};
let draggedDashboardWidgetId = null;
let summaryResizeState = null;
let currentAnnotations = [];
let currentSummaryAlerts = [];
let pendingSummaryFocus = null;
let selectedAnnotationMoment = null;
let selectedAnnotationEnd = null;
let chartRangeClickAnchor = null;
let chartRangePointerState = null;
let dashboardEditorMode = 'create';
let landingCarouselIndex = 0;
let landingCarouselTimer = null;
let extensionPresenceRefreshing = false;
let meetingActionId = null;
let meetingActionTitle = '';
const DASHBOARD_WIDGETS = {
  engagementCard: 'Card de fontes em engajamento alto',
  participantsCard: 'Card de participantes',
  windowsCard: 'Card de janelas analisadas',
  alertsCard: 'Card de alertas',
  reactions: 'Tempo por reação',
  chart: 'Gráfico de evolução',
  traffic: 'Distribuição do semáforo',
  quality: 'Qualidade da captura',
  peaks: 'Momentos de pico',
  averages: 'Média das reações',
  heatmap: 'Mapa de momentos',
  comparison: 'Começo x final',
  attention: 'Pontos de atenção',
  participantsChart: 'Participantes ao longo do tempo',
  recommendations: 'Recomendações',
  table: 'Tabela de leituras',
  finalSummary: 'Resumo final'
};
const DEFAULT_DASHBOARD_VISIBLE = ['engagementCard', 'participantsCard', 'windowsCard', 'alertsCard', 'reactions', 'chart', 'table', 'finalSummary'];
const DASHBOARD_DEFAULT_SIZES = {
  engagementCard: { columns: 3, height: null },
  participantsCard: { columns: 3, height: null },
  windowsCard: { columns: 3, height: null },
  alertsCard: { columns: 3, height: null },
  reactions: { columns: 12, height: null },
  chart: { columns: 12, height: null },
  traffic: { columns: 12, height: null },
  quality: { columns: 12, height: null },
  peaks: { columns: 12, height: null },
  averages: { columns: 12, height: null },
  heatmap: { columns: 12, height: null },
  comparison: { columns: 12, height: null },
  attention: { columns: 12, height: null },
  participantsChart: { columns: 12, height: null },
  recommendations: { columns: 12, height: null },
  table: { columns: 12, height: null },
  finalSummary: { columns: 12, height: null }
};
const DASHBOARD_WIDGET_DESCRIPTIONS = {
  engagementCard: 'Mostra a média de participantes classificados como engajados.',
  participantsCard: 'Mostra o maior total de participantes analisados ao mesmo tempo.',
  windowsCard: 'Mostra quantos intervalos da reunião entraram na análise.',
  alertsCard: 'Conta mudanças do semáforo coletivo para atenção ou revisão e leva aos horários registrados.',
  reactions: 'Compara por quanto tempo cada reação foi predominante.',
  chart: 'Mostra a intensidade coletiva das quatro dimensões na mesma escala de 0% a 100% usada pela extensão.',
  traffic: 'Resume quanto tempo ficou nos níveis verde, amarelo e vermelho.',
  quality: 'Ajuda a entender a cobertura e a consistência dos dados recebidos.',
  peaks: 'Aponta o maior valor de cada reação e quando ele aconteceu.',
  averages: 'Compara a média das quatro reações no período escolhido.',
  heatmap: 'Oferece uma leitura rápida da reação predominante em cada janela.',
  comparison: 'Compara o comportamento do início e do final da reunião.',
  attention: 'Reúne os trechos que mais merecem revisão.',
  participantsChart: 'Mostra quantas pessoas foram analisadas ao longo do tempo.',
  recommendations: 'Transforma padrões dos indicadores em sugestões de revisão.',
  table: 'Exibe as leituras detalhadas de cada janela.',
  finalSummary: 'Sintetiza os resultados do intervalo selecionado em texto.'
};
const OVERVIEW_DASHBOARD_WIDGETS = {
  meetingsCard: 'Card de reuniões concluídas',
  engagementCard: 'Card de fontes em engajamento alto',
  participantsCard: 'Card de participantes',
  alertsCard: 'Card de alertas',
  alerts: 'Reuniões com alertas',
  engagement: 'Engajamento por reunião',
  traffic: 'Semáforo consolidado',
  ranking: 'Reuniões por engajamento alto',
  volume: 'Volume de dados analisados',
  comparison: 'Comparação de reuniões'
};
const OVERVIEW_DASHBOARD_DEFAULT_SIZES = {
  meetingsCard: { columns: 3, height: null },
  engagementCard: { columns: 3, height: null },
  participantsCard: { columns: 3, height: null },
  alertsCard: { columns: 3, height: null },
  alerts: { columns: 12, height: null },
  engagement: { columns: 12, height: null },
  traffic: { columns: 12, height: null },
  ranking: { columns: 6, height: null },
  volume: { columns: 6, height: null },
  comparison: { columns: 12, height: null }
};
const LEGACY_OVERVIEW_SIZE_COLUMNS = { compact: 3, half: 6, wide: 8, full: 12 };
const OVERVIEW_DASHBOARD_WIDGET_DESCRIPTIONS = {
  meetingsCard: 'Total de reuniões concluídas vinculadas à conta.',
  engagementCard: 'Parcela média de fontes nos níveis alto ou muito alto de engajamento.',
  participantsCard: 'Soma das pessoas analisadas nas reuniões.',
  alertsCard: 'Total de mudanças do semáforo para atenção ou revisão.',
  alerts: 'Lista as reuniões com alertas e permite abrir os horários marcados.',
  engagement: 'Compara a porcentagem média da turma classificada como engajada.',
  traffic: 'Consolida os níveis verde, amarelo e vermelho.',
  ranking: 'Organiza reuniões pela parcela média de fontes em engajamento alto, sem atribuir nota.',
  volume: 'Mostra quantas leituras formaram os resultados.',
  comparison: 'Responde perguntas colocando reuniões lado a lado, sem indicar vencedores.'
};
const DEFAULT_OVERVIEW_DASHBOARD_VISIBLE = ['meetingsCard', 'engagementCard', 'participantsCard', 'alertsCard', 'engagement', 'comparison'];
const VIEW_TITLES = {
  landing: 'Início',
  home: 'Minhas reuniões',
  setup: 'Nova reunião',
  live: 'Reunião ao vivo',
  overview: 'Dashboard geral',
  summary: 'Resumo da reunião',
  extension: 'Aparência da extensão',
  support: 'Central de ajuda',
  profile: 'Meu perfil',
  account: 'Dados de cadastro'
};
const HELP_CONTEXT = {
  home: ['Suas reuniões ficam aqui', 'Abra um resumo, edite o título ou exclua uma reunião que não precisa mais guardar.'],
  overview: ['Monte sua própria visão', 'Escolha os indicadores, arraste os blocos e salve diferentes dashboards para comparar reuniões.'],
  summary: ['Revise os momentos importantes', 'Selecione diretamente no gráfico: dois cliques criam a faixa e o mesmo intervalo recalcula o resumo e define a próxima anotação.'],
  extension: ['Ajuste o painel do Meet', 'Defina o que aparece fixo, o que surge ao passar o mouse e o tamanho dos elementos.'],
  support: ['Central de ajuda', 'Aqui estão as explicações sobre indicadores, cores, extensão e interpretação dos dados.'],
  profile: ['Seus dados de perfil', 'Atualize as informações usadas para identificar sua conta.'],
  account: ['Privacidade da conta', 'Consulte os dados salvos e as opções relacionadas ao seu cadastro.']
};
const DEFAULT_EXTENSION_PREFERENCES = Object.freeze({
  preferencesVersion: 2,
  theme: 'light',
  scale: 'normal',
  fontSize: 'normal',
  trendDisplay: 'hover',
  confidenceDisplay: 'hover',
  scoresDisplay: 'always',
  chartDisplay: 'always',
  sourcesDisplay: 'hover',
  technicalDisplay: 'hover'
});
let currentExtensionPreferences = { ...DEFAULT_EXTENSION_PREFERENCES };

function normalizeExtensionDisplayMode(value, legacyValue, fallback) {
  if (['hidden', 'hover', 'always'].includes(value)) return value;
  if (legacyValue === false) return 'hidden';
  if (legacyValue === true) return 'always';
  return fallback;
}

function normalizeExtensionPreferences(value = {}) {
  const legacyFontSizes = { normal: 'small', large: 'normal', extra: 'large' };
  const fontSize = value.preferencesVersion === 2
    ? value.fontSize
    : legacyFontSizes[value.fontSize] || DEFAULT_EXTENSION_PREFERENCES.fontSize;
  return {
    preferencesVersion: 2,
    theme: ['light', 'dark'].includes(value.theme) ? value.theme : DEFAULT_EXTENSION_PREFERENCES.theme,
    scale: ['small', 'normal', 'large'].includes(value.scale) ? value.scale : DEFAULT_EXTENSION_PREFERENCES.scale,
    fontSize: ['small', 'normal', 'large'].includes(fontSize) ? fontSize : DEFAULT_EXTENSION_PREFERENCES.fontSize,
    trendDisplay: normalizeExtensionDisplayMode(value.trendDisplay, value.showTrend, DEFAULT_EXTENSION_PREFERENCES.trendDisplay),
    confidenceDisplay: normalizeExtensionDisplayMode(value.confidenceDisplay, value.showConfidence, DEFAULT_EXTENSION_PREFERENCES.confidenceDisplay),
    scoresDisplay: normalizeExtensionDisplayMode(value.scoresDisplay, value.showSecondary, DEFAULT_EXTENSION_PREFERENCES.scoresDisplay),
    chartDisplay: normalizeExtensionDisplayMode(value.chartDisplay, value.showChart, DEFAULT_EXTENSION_PREFERENCES.chartDisplay),
    sourcesDisplay: normalizeExtensionDisplayMode(value.sourcesDisplay, value.showSources, DEFAULT_EXTENSION_PREFERENCES.sourcesDisplay),
    technicalDisplay: normalizeExtensionDisplayMode(value.technicalDisplay, value.showTechnical, DEFAULT_EXTENSION_PREFERENCES.technicalDisplay)
  };
}

function readExtensionDisplayChoice(toggleId, selectId) {
  return document.querySelector(toggleId).checked
    ? document.querySelector(selectId).value
    : 'hidden';
}

function fillExtensionDisplayChoice(toggleId, selectId, mode) {
  const toggle = document.querySelector(toggleId);
  const select = document.querySelector(selectId);
  toggle.checked = mode !== 'hidden';
  select.value = mode === 'always' ? 'always' : 'hover';
}

function syncExtensionOptionControls() {
  document.querySelectorAll('[data-extension-option]').forEach(row => {
    const enabled = row.querySelector('input[type="checkbox"]').checked;
    row.dataset.enabled = String(enabled);
    row.querySelector('select').disabled = !enabled;
  });
}

function readExtensionPreferencesForm() {
  return normalizeExtensionPreferences({
    theme: document.querySelector('#extensionTheme').value,
    scale: document.querySelector('#extensionScale').value,
    fontSize: document.querySelector('#extensionFontSize').value,
    preferencesVersion: 2,
    trendDisplay: readExtensionDisplayChoice('#extensionShowTrend', '#extensionTrendDisplay'),
    confidenceDisplay: readExtensionDisplayChoice('#extensionShowConfidence', '#extensionConfidenceDisplay'),
    scoresDisplay: readExtensionDisplayChoice('#extensionShowSecondary', '#extensionScoresDisplay'),
    chartDisplay: readExtensionDisplayChoice('#extensionShowChart', '#extensionChartDisplay'),
    sourcesDisplay: readExtensionDisplayChoice('#extensionShowSources', '#extensionSourcesDisplay'),
    technicalDisplay: readExtensionDisplayChoice('#extensionShowTechnical', '#extensionTechnicalDisplay')
  });
}

function fillExtensionPreferencesForm(preferences) {
  const normalized = normalizeExtensionPreferences(preferences);
  document.querySelector('#extensionTheme').value = normalized.theme;
  document.querySelector('#extensionScale').value = normalized.scale;
  document.querySelector('#extensionFontSize').value = normalized.fontSize;
  fillExtensionDisplayChoice('#extensionShowTrend', '#extensionTrendDisplay', normalized.trendDisplay);
  fillExtensionDisplayChoice('#extensionShowConfidence', '#extensionConfidenceDisplay', normalized.confidenceDisplay);
  fillExtensionDisplayChoice('#extensionShowSecondary', '#extensionScoresDisplay', normalized.scoresDisplay);
  fillExtensionDisplayChoice('#extensionShowChart', '#extensionChartDisplay', normalized.chartDisplay);
  fillExtensionDisplayChoice('#extensionShowSources', '#extensionSourcesDisplay', normalized.sourcesDisplay);
  fillExtensionDisplayChoice('#extensionShowTechnical', '#extensionTechnicalDisplay', normalized.technicalDisplay);
  syncExtensionOptionControls();
  renderExtensionPreview(normalized);
}

function renderExtensionPreview(preferences = readExtensionPreferencesForm()) {
  const panel = document.querySelector('#extensionPreviewPanel');
  panel.dataset.theme = preferences.theme;
  panel.dataset.scale = preferences.scale;
  panel.dataset.fontSize = preferences.fontSize;
  document.querySelector('#extensionPreviewTrend').dataset.display = preferences.trendDisplay;
  document.querySelector('#extensionPreviewConfidence').dataset.display = preferences.confidenceDisplay;
  document.querySelector('#extensionPreviewScores').dataset.display = preferences.scoresDisplay;
  document.querySelector('#extensionPreviewChart').dataset.display = preferences.chartDisplay;
  document.querySelector('#extensionPreviewSources').dataset.display = preferences.sourcesDisplay;
  document.querySelector('#extensionPreviewTechnical').dataset.display = preferences.technicalDisplay;
}

async function loadExtensionPreferences() {
  if (!dataApi || !signedInUser) return;
  const status = document.querySelector('#extensionSyncStatus');
  status.textContent = 'Carregando...';
  status.dataset.state = 'loading';
  const { data, error } = await dataApi.getExtensionPreferences(signedInUser.id);
  if (error) {
    status.textContent = 'Banco ainda não preparado';
    status.dataset.state = 'error';
    fillExtensionPreferencesForm(currentExtensionPreferences);
    return;
  }
  currentExtensionPreferences = normalizeExtensionPreferences(data?.configuration);
  fillExtensionPreferencesForm(currentExtensionPreferences);
  status.textContent = data?.updatedAt ? 'Sincronizado com sua conta' : 'Usando configuração padrão';
  status.dataset.state = 'saved';
}
let latestMetrics = {
  reaction: 'Aguardando dados',
  face: '—',
  engagement: 0,
  boredom: 0,
  confusion: 0,
  frustration: 0,
  analyzed: 0,
  total: 0,
  capturedAt: null
};

function setSidebarCollapsed(collapsed, remember = true) {
  appShell.classList.toggle('sidebar-collapsed', collapsed);
  const button = document.querySelector('#sidebarToggle');
  button.setAttribute('aria-expanded', String(!collapsed));
  button.setAttribute('aria-label', collapsed ? 'Expandir menu' : 'Recolher menu');
  button.title = collapsed ? 'Expandir menu' : 'Recolher menu';
  if (remember) localStorage.setItem('mindflow-sidebar', collapsed ? 'collapsed' : 'expanded');
}

function initializeSidebar() {
  const saved = localStorage.getItem('mindflow-sidebar');
  const shouldCollapse = saved ? saved === 'collapsed' : window.matchMedia('(max-width: 1050px)').matches;
  setSidebarCollapsed(shouldCollapse, false);
}

document.querySelector('#sidebarToggle').addEventListener('click', () => {
  setSidebarCollapsed(!appShell.classList.contains('sidebar-collapsed'));
});

// A apresentação inicial troca as prévias sozinha, mas deixa o usuário escolher o ritmo.
function showLandingCarouselSlide(index) {
  const slides = [...document.querySelectorAll('[data-carousel-slide]')];
  const dots = [...document.querySelectorAll('[data-carousel-dot]')];
  if (!slides.length) return;
  landingCarouselIndex = (index + slides.length) % slides.length;
  slides.forEach((slide, slideIndex) => {
    const active = slideIndex === landingCarouselIndex;
    slide.hidden = !active;
    slide.classList.toggle('active', active);
  });
  dots.forEach((dot, dotIndex) => {
    const active = dotIndex === landingCarouselIndex;
    dot.classList.toggle('active', active);
    dot.setAttribute('aria-selected', String(active));
  });
  document.querySelector('#carouselCaption').textContent = slides[landingCarouselIndex].dataset.caption;
}

function restartLandingCarousel() {
  clearInterval(landingCarouselTimer);
  landingCarouselTimer = setInterval(() => showLandingCarouselSlide(landingCarouselIndex + 1), 5600);
}

document.querySelector('#landingCarousel').addEventListener('click', event => {
  const dot = event.target.closest('[data-carousel-dot]');
  const direction = event.target.closest('[data-carousel-direction]');
  if (dot) showLandingCarouselSlide(Number(dot.dataset.carouselDot));
  if (direction) showLandingCarouselSlide(landingCarouselIndex + (direction.dataset.carouselDirection === 'next' ? 1 : -1));
  if (dot || direction) restartLandingCarousel();
});
document.querySelector('#landingCarousel').addEventListener('mouseenter', () => clearInterval(landingCarouselTimer));
document.querySelector('#landingCarousel').addEventListener('mouseleave', restartLandingCarousel);
showLandingCarouselSlide(0);
restartLandingCarousel();

function showView(name, options = {}) {
  if (!options.fromHistory && currentView !== name && !['landing', 'auth'].includes(currentView)) {
    if (viewHistory.at(-1) !== currentView) viewHistory.push(currentView);
    viewHistory = viewHistory.slice(-12);
  }
  currentView = name;
  const pageTitle = name === 'auth' ? (authMode === 'register' ? 'Criar conta' : 'Entrar') : (VIEW_TITLES[name] || 'Painel');
  document.title = `${pageTitle} — MindFlowIA`;
  appShell.classList.toggle('auth-mode', name === 'auth' || name === 'landing');
  views.forEach(view => view.classList.toggle('active', view.dataset.view === name));
  const navTarget = name === 'setup' || name === 'live' ? 'home' : name === 'summary' ? 'overview' : name;
  navItems.forEach(item => item.classList.toggle('active', item.dataset.go === navTarget));
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (name === 'summary') loadSelectedSummary();
  if (name === 'overview') {
    renderOverview(accountMeetings);
    applyOverviewDashboardLayout(activeOverviewDashboardLayoutId);
    void refreshExtensionPresence();
  }
  if (name === 'profile') loadProfileEditor();
  if (name === 'account') prepareRegistrationDataView();
  if (name === 'extension') void loadExtensionPreferences();
  updateHelpContext(name);
}

function goToPreviousView() {
  let target = viewHistory.pop();
  while (target === currentView) target = viewHistory.pop();
  showView(target || 'home', { fromHistory: true });
}

document.querySelector('#overviewBackButton').addEventListener('click', goToPreviousView);
document.querySelector('#summaryBackButton').addEventListener('click', goToPreviousView);

// Qualquer botão com data-go troca de tela sem recarregar a página.
document.addEventListener('click', event => {
  const trigger = event.target.closest('[data-go]');
  if (trigger) showView(trigger.dataset.go);

  const authTrigger = event.target.closest('[data-auth-open]');
  if (authTrigger) {
    setAuthMode(authTrigger.dataset.authOpen);
    showView('auth');
  }

  const meetingTrigger = event.target.closest('[data-open-meeting]');
  if (meetingTrigger) openStoredMeeting(meetingTrigger);

  const alertTrigger = event.target.closest('[data-open-alerts]');
  if (alertTrigger) {
    selectedSummaryId = alertTrigger.dataset.openAlerts;
    pendingSummaryFocus = 'alerts';
    showView('summary');
  }

  const editMeetingTrigger = event.target.closest('[data-edit-meeting]');
  if (editMeetingTrigger) openMeetingTitleEditor(editMeetingTrigger.dataset.editMeeting, editMeetingTrigger.dataset.meetingTitle || '');

  const deleteMeetingTrigger = event.target.closest('[data-delete-meeting]');
  if (deleteMeetingTrigger) openMeetingDeleteDialog(deleteMeetingTrigger.dataset.deleteMeeting, deleteMeetingTrigger.dataset.meetingTitle || '');
});

function updateHelpContext(viewName) {
  const [title, text] = HELP_CONTEXT[viewName] || ['Como podemos ajudar?', 'Entenda os indicadores, o fluxo da extensão e as opções de personalização.'];
  document.querySelector('#helpPopoverTitle').textContent = title;
  document.querySelector('#helpPopoverText').textContent = text;
}

function toggleHelpPopover(forceOpen) {
  const popover = document.querySelector('#helpPopover');
  const launcher = document.querySelector('#helpLauncher');
  const shouldOpen = typeof forceOpen === 'boolean' ? forceOpen : popover.hidden;
  popover.hidden = !shouldOpen;
  launcher.setAttribute('aria-expanded', String(shouldOpen));
}

document.querySelector('#helpLauncher').addEventListener('click', () => toggleHelpPopover());
document.querySelector('#closeHelpPopover').addEventListener('click', () => toggleHelpPopover(false));
document.querySelector('#helpPopover').addEventListener('click', event => {
  if (event.target.closest('[data-go]')) toggleHelpPopover(false);
});
document.querySelector('#helpCustomizeShortcut').addEventListener('click', () => {
  toggleHelpPopover(false);
  if (currentView === 'summary' && currentSummary) {
    openDashboardEditor('create');
    return;
  }
  showView('overview');
  openOverviewDashboardEditor('create');
});

function openMeetingTitleEditor(meetingId, title) {
  if (!meetingId) return;
  meetingActionId = meetingId;
  meetingActionTitle = title || 'Reunião';
  const modal = document.querySelector('#meetingEditModal');
  const input = document.querySelector('#meetingEditTitle');
  input.value = meetingActionTitle;
  modal.hidden = false;
  requestAnimationFrame(() => input.focus());
}

function openMeetingDeleteDialog(meetingId, title) {
  if (!meetingId) return;
  meetingActionId = meetingId;
  meetingActionTitle = title || 'esta reunião';
  document.querySelector('#deleteMeetingDialogTitle').textContent = `Excluir “${meetingActionTitle}”?`;
  document.querySelector('#meetingDeleteModal').hidden = false;
}

function closeMeetingDialogs() {
  document.querySelector('#meetingEditModal').hidden = true;
  document.querySelector('#meetingDeleteModal').hidden = true;
}

document.querySelectorAll('[data-close-meeting-dialog]').forEach(button => button.addEventListener('click', closeMeetingDialogs));
document.querySelectorAll('.modal-backdrop').forEach(backdrop => backdrop.addEventListener('click', event => {
  if (event.target === backdrop) closeMeetingDialogs();
}));

document.querySelector('#meetingEditForm').addEventListener('submit', async event => {
  event.preventDefault();
  const title = document.querySelector('#meetingEditTitle').value.trim();
  if (!title || !meetingActionId || !dataApi) return;
  const editingId = meetingActionId;
  const { error } = await dataApi.updateMeeting(editingId, { title });
  if (error) {
    showToast('Não foi possível atualizar o título.');
    return;
  }
  if (currentSummary?.id === editingId) {
    currentSummary.title = title;
    document.querySelector('#summaryTitle').textContent = title;
  }
  closeMeetingDialogs();
  await loadAccount();
  showToast('Título atualizado.');
});

document.querySelector('#confirmDeleteMeeting').addEventListener('click', async () => {
  if (!meetingActionId || !dataApi || !signedInUser) return;
  const deletingId = meetingActionId;
  const { error } = await dataApi.deleteMeeting(deletingId, signedInUser.id);
  if (error) {
    showToast('Não foi possível excluir. Confira as permissões e os vínculos da reunião.');
    return;
  }
  if (selectedSummaryId === deletingId) selectedSummaryId = null;
  if (currentSummary?.id === deletingId) currentSummary = null;
  closeMeetingDialogs();
  await loadAccount();
  showView('home');
  showToast('Reunião excluída.');
});

document.querySelector('#logoutButton').addEventListener('click', async () => {
  stopMeeting();
  if (db) await db.auth.signOut();
  signedInUser = null;
  viewHistory = [];
  showView('landing');
});

// Alternância visual entre login e cadastro.
document.querySelectorAll('[data-auth-tab]').forEach(button => {
  button.addEventListener('click', () => setAuthMode(button.dataset.authTab));
});

function setAuthMode(mode) {
  authMode = mode;
  const isRegister = mode === 'register';
  if (currentView === 'auth') document.title = `${isRegister ? 'Criar conta' : 'Entrar'} — MindFlowIA`;
  document.querySelector('#authFormContent').hidden = false;
  document.querySelector('#authRecovery').hidden = true;
  document.querySelector('#authSuccess').hidden = true;
  document.querySelectorAll('[data-auth-tab]').forEach(tab => {
    const selected = tab.dataset.authTab === mode;
    tab.classList.toggle('active', selected);
    tab.setAttribute('aria-selected', String(selected));
  });
  document.querySelectorAll('.register-only').forEach(field => { field.hidden = !isRegister; });
  document.querySelectorAll('.login-only').forEach(field => { field.hidden = isRegister; });
  document.querySelector('#authTitle').textContent = isRegister ? 'Crie sua conta' : 'Acesse sua conta';
  document.querySelector('#authDescription').textContent = isRegister
    ? 'Cadastre-se para criar e acompanhar suas reuniões.'
    : 'Entre para continuar no painel.';
  document.querySelector('#authSubmit').textContent = isRegister ? 'Criar conta' : 'Entrar';
  document.querySelector('#password').autocomplete = isRegister ? 'new-password' : 'current-password';
  document.querySelector('#password').type = 'password';
  document.querySelector('#confirmPassword').type = 'password';
  document.querySelector('#toggleLoginPassword').textContent = 'Mostrar senha';
  document.querySelector('#toggleLoginPassword').setAttribute('aria-pressed', 'false');
  document.querySelector('#togglePasswordsButton').textContent = 'Mostrar senhas';
  document.querySelector('#togglePasswordsButton').setAttribute('aria-pressed', 'false');
  document.querySelector('#registerName').required = isRegister;
  document.querySelector('#registerInstitution').required = isRegister;
  document.querySelector('#confirmPassword').required = isRegister;
  document.querySelector('#acceptTerms').required = isRegister;
  clearAuthError();
}

// No login também dá para conferir a senha sem mexer no fluxo de cadastro.
document.querySelector('#toggleLoginPassword').addEventListener('click', event => {
  const password = document.querySelector('#password');
  const willShow = password.type === 'password';
  password.type = willShow ? 'text' : 'password';
  event.currentTarget.textContent = willShow ? 'Ocultar senha' : 'Mostrar senha';
  event.currentTarget.setAttribute('aria-pressed', String(willShow));
});

// No cadastro dá para conferir o que foi digitado nos dois campos de senha.
document.querySelector('#togglePasswordsButton').addEventListener('click', event => {
  const password = document.querySelector('#password');
  const confirmation = document.querySelector('#confirmPassword');
  const willShow = password.type === 'password';
  password.type = willShow ? 'text' : 'password';
  confirmation.type = willShow ? 'text' : 'password';
  event.currentTarget.textContent = willShow ? 'Ocultar senhas' : 'Mostrar senhas';
  event.currentTarget.setAttribute('aria-pressed', String(willShow));
});

document.querySelector('#authForm').addEventListener('submit', async event => {
  event.preventDefault();
  clearAuthError();

  if (!db) return showAuthError('Não foi possível carregar a conexão com o Supabase.');

  const email = document.querySelector('#email').value.trim();
  const password = document.querySelector('#password').value;
  setAuthBusy(true);

  if (!email || !document.querySelector('#email').validity.valid) {
    setAuthBusy(false);
    return showAuthError('Informe um e-mail válido.');
  }
  if (password.length < 8) {
    setAuthBusy(false);
    return showAuthError('A senha precisa ter pelo menos 8 caracteres.');
  }

  if (authMode === 'register') {
    const name = document.querySelector('#registerName').value.trim();
    const institution = document.querySelector('#registerInstitution').value.trim();
    const gender = document.querySelector('#registerGender').value;
    const occupation = document.querySelector('#registerOccupation').value.trim();
    const confirmation = document.querySelector('#confirmPassword').value;
    const accepted = document.querySelector('#acceptTerms').checked;

    if (!name) { setAuthBusy(false); return showAuthError('Informe seu nome completo.'); }
    if (!institution) { setAuthBusy(false); return showAuthError('Informe sua instituição ou empresa.'); }
    if (!occupation) { setAuthBusy(false); return showAuthError('Informe sua atuação principal.'); }
    if (password !== confirmation) { setAuthBusy(false); return showAuthError('As senhas não são iguais.'); }
    if (!accepted) { setAuthBusy(false); return showAuthError('Você precisa aceitar os termos para continuar.'); }

    const { data, error } = await db.auth.signUp({
      email,
      password,
      options: { data: { nome: name, instituicao: institution, genero: gender, atuacao: occupation } }
    });
    setAuthBusy(false);
    if (error) return showAuthError(readableAuthError(error.message));

    // O Supabase pode responder sem erro quando o e-mail já existe, mas vem sem identidade.
    // Assim a tela não finge que criou uma segunda conta.
    if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
      return showAuthError('Este e-mail já possui uma conta. Use “Entrar” ou “Esqueci minha senha”.');
    }

    if (data.session) {
      signedInUser = data.user;
      await loadAccount();
      showView('home');
      showToast('Conta criada com sucesso.');
    } else {
      showAuthSuccess('Confirme seu e-mail', `Enviamos um link de confirmação para ${email}.`);
    }
    return;
  }

  const { data, error } = await db.auth.signInWithPassword({ email, password });
  setAuthBusy(false);
  if (error) return showAuthError(readableAuthError(error.message));
  signedInUser = data.user;
  await loadAccount();
  showView('home');
  showToast('Login realizado.');
});

document.querySelector('#forgotPasswordButton').addEventListener('click', () => {
  document.querySelector('#recoveryEmail').value = document.querySelector('#email').value;
  document.querySelector('#authFormContent').hidden = true;
  document.querySelector('#authRecovery').hidden = false;
});

document.querySelector('[data-auth-back]').addEventListener('click', () => setAuthMode('login'));

document.querySelector('#sendRecoveryButton').addEventListener('click', async () => {
  const email = document.querySelector('#recoveryEmail').value.trim();
  if (!email) return showToast('Informe o e-mail da sua conta.');
  if (!db) return showToast('Não foi possível carregar a conexão com o Supabase.');
  const button = document.querySelector('#sendRecoveryButton');
  button.disabled = true;
  button.textContent = 'Enviando...';
  const { error } = await db.auth.resetPasswordForEmail(email);
  button.disabled = false;
  button.textContent = 'Enviar link';
  if (error) return showToast(readableAuthError(error.message));
  showAuthSuccess('Confira seu e-mail', `Enviamos as instruções de recuperação para ${email}.`);
});

document.querySelector('#successButton').addEventListener('click', () => setAuthMode('login'));
document.querySelector('#termsButton').addEventListener('click', () => showToast('A página de termos será preparada antes dos testes com usuários.'));

function showAuthSuccess(title, message) {
  document.querySelector('#authFormContent').hidden = true;
  document.querySelector('#authRecovery').hidden = true;
  document.querySelector('#authSuccess').hidden = false;
  document.querySelector('#successTitle').textContent = title;
  document.querySelector('#successMessage').textContent = message;
}

function setAuthBusy(busy) {
  const button = document.querySelector('#authSubmit');
  button.disabled = busy;
  button.textContent = busy ? 'Aguarde...' : authMode === 'register' ? 'Criar conta' : 'Entrar';
}

function clearAuthError() {
  const errorBox = document.querySelector('#authFormError');
  errorBox.hidden = true;
  errorBox.textContent = '';
}

function showAuthError(message) {
  const errorBox = document.querySelector('#authFormError');
  errorBox.textContent = message;
  errorBox.hidden = false;
  errorBox.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  showToast(message);
}

function readableAuthError(message = '') {
  const normalized = message.toLowerCase();
  if (normalized.includes('invalid login')) return 'E-mail ou senha incorretos.';
  if (normalized.includes('email not confirmed')) return 'Confirme seu e-mail antes de entrar.';
  if (normalized.includes('already registered')) return 'Este e-mail já está cadastrado.';
  if (normalized.includes('database error')) return 'O perfil não pôde ser salvo no banco. Atualize a página e tente novamente.';
  if (normalized.includes('rate limit')) return 'Muitas tentativas seguidas. Aguarde alguns minutos e tente novamente.';
  if (normalized.includes('signup') && normalized.includes('disabled')) return 'Novos cadastros estão desativados no Supabase.';
  if (normalized.includes('password')) return 'A senha precisa ter pelo menos 8 caracteres.';
  return 'Não foi possível concluir. Tente novamente.';
}

document.querySelector('#newMeetingButton')?.addEventListener('click', prepareNewMeeting);

async function loadAccount() {
  if (!dataApi || !signedInUser) return;
  overviewComparisonDetails.clear();

  const staleBefore = new Date(Date.now() - 60_000).toISOString();
  try {
    await dataApi.closeStaleExtensionMeetings(signedInUser.id, staleBefore);
  } catch { /* a listagem continua mesmo se a migração de presença ainda não foi aplicada */ }

  const [{ data: profile }, { data: meetings, error }] = await Promise.all([
    dataApi.getProfile(signedInUser.id),
    dataApi.listMeetingSummaries()
  ]);

  const name = profile?.name || signedInUser.user_metadata?.nome || signedInUser.email?.split('@')[0] || 'Usuário';
  const initials = name.split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase();
  document.querySelector('.sidebar-user strong').textContent = name;
  applyProfileIdentity(initials, profile?.photoUrl);
  document.querySelector('#sidebarRole').textContent = occupationLabel(profile?.occupation);
  document.querySelector('.welcome-strip > div:first-child strong').textContent = `Olá, ${name.split(' ')[0]}.`;
  fillProfileForm(profile || {
    name,
    email: signedInUser.email,
    institution: signedInUser.user_metadata?.instituicao,
    gender: signedInUser.user_metadata?.genero,
    occupation: signedInUser.user_metadata?.atuacao
  });

  if (error) {
    renderMeetingError();
    return;
  }
  // A interface também filtra por proprietário. A proteção principal continua
  // sendo o RLS do Supabase, mas esta segunda barreira evita listagens indevidas.
  const ownedMeetings = (meetings || []).filter(meeting => meeting.ownerId === signedInUser.id);
  const personalMeetings = ownedMeetings.filter(meeting => !meeting.isDemo);
  const demoMeetings = (meetings || []).filter(meeting => meeting.isDemo);
  const finished = ownedMeetings.filter(meeting => meeting.status === 'encerrada');
  const engagementValues = finished.map(meeting => meeting.engagedFraction).filter(Number.isFinite);
  const engagementAverage = engagementValues.length
    ? engagementValues.reduce((total, value) => total + value, 0) / engagementValues.length
    : null;
  const participantsTotal = finished.reduce((total, meeting) => total + meeting.participants, 0);
  document.querySelector('#welcomeMeetingCount').textContent = finished.length === 1
    ? '1 reunião concluída no banco.'
    : `${finished.length} reuniões concluídas no banco.`;
  document.querySelector('#homeEngagement').textContent = engagementAverage === null ? '—' : formatPercent(engagementAverage);
  document.querySelector('#homeParticipants').textContent = String(participantsTotal);
  if (!selectedSummaryId) selectedSummaryId = finished[0]?.id || ownedMeetings[0]?.id || null;
  renderMeetings(personalMeetings);
  accountMeetings = ownedMeetings;
  renderOverview(accountMeetings);
  await loadOverviewDashboardLayouts();
  renderDemoMeetings(demoMeetings);
  void refreshExtensionPresence();
  document.querySelector('#homeDemoSection').hidden = !demoMeetings.length;
}

function renderExtensionPresence(meeting) {
  const banner = document.querySelector('#extensionLivePresence');
  if (!banner) return;
  banner.hidden = !meeting;
  if (!meeting) return;
  document.querySelector('#extensionLiveMeetingTitle').textContent = meeting.title || 'Reunião em andamento';
  document.querySelector('#extensionLiveMeetingCode').textContent = meeting.code ? `Código ${meeting.code}` : '';
}

async function refreshExtensionPresence() {
  if (extensionPresenceRefreshing || !dataApi || !signedInUser) return;
  extensionPresenceRefreshing = true;
  try {
    const activeSince = new Date(Date.now() - 45_000).toISOString();
    const { data, error } = await dataApi.getActiveExtensionMeeting(signedInUser.id, activeSince);
    renderExtensionPresence(error ? null : data);
  } catch {
    renderExtensionPresence(null);
  } finally {
    extensionPresenceRefreshing = false;
  }
}

function renderOverview(meetings = []) {
  const finished = meetings.filter(meeting => meeting.status === 'encerrada');
  overviewFinishedMeetings = finished;
  const engagementValues = finished.map(meeting => meeting.engagedFraction).filter(Number.isFinite);
  const engagementAverage = engagementValues.length
    ? engagementValues.reduce((sum, value) => sum + value, 0) / engagementValues.length
    : null;
  const participants = finished.reduce((sum, meeting) => sum + meeting.participants, 0);
  const alerts = finished.reduce((sum, meeting) => sum + meeting.alerts, 0);

  document.querySelector('#overviewMeetings').textContent = String(finished.length);
  document.querySelector('#overviewEngagement').textContent = engagementAverage == null ? '—' : formatPercent(engagementAverage);
  document.querySelector('#overviewParticipants').textContent = String(participants);
  document.querySelector('#overviewAlerts').textContent = String(alerts);
  renderOverviewAlertList(finished);
  renderOverviewTraffic(finished);
  renderOverviewRanking(finished);
  renderOverviewVolume(finished);

  const bars = document.querySelector('#overviewMeetingBars');
  if (!finished.length) {
    bars.innerHTML = '<div class="overview-empty">Quando você concluir uma reunião, as médias aparecerão aqui.</div>';
    renderOverviewComparisonPicker([]);
    return;
  }
  bars.innerHTML = finished.map(meeting => {
    const percent = meeting.engagedFraction == null ? 0 : Math.round(meeting.engagedFraction * 100);
    return `<div class="overview-bar-row"><span title="${escapeHtml(meeting.title)}">${escapeHtml(meeting.title)}</span><div><i style="width:${percent}%"></i></div><strong>${percent}%</strong></div>`;
  }).join('');
  renderOverviewComparisonPicker(finished);
}

function renderOverviewAlertList(meetings) {
  const container = document.querySelector('#overviewAlertList');
  const withAlerts = meetings
    .filter(meeting => Number(meeting.alerts || 0) > 0)
    .sort((a, b) => Number(b.alerts || 0) - Number(a.alerts || 0));
  if (!withAlerts.length) {
    container.innerHTML = '<div class="overview-empty">Nenhuma reunião concluída possui alertas.</div>';
    return;
  }
  container.innerHTML = withAlerts.map(meeting => `
    <article class="overview-alert-row">
      <div><strong>${escapeHtml(meeting.title)}</strong><span>${meeting.participants} participantes · ${formatPercent(meeting.engagedFraction)} de engajamento</span></div>
      <b>${meeting.alerts} alerta${meeting.alerts === 1 ? '' : 's'}</b>
      <button class="secondary-button small-button" type="button" data-open-alerts="${meeting.id}">Ver momentos</button>
    </article>`).join('');
}

function renderOverviewTraffic(meetings) {
  const container = document.querySelector('#overviewTrafficGrid');
  const levels = [
    { label: 'Estável', field: 'greenWindows', color: '#1b9c5a', description: 'Janelas verdes' },
    { label: 'Atenção', field: 'yellowWindows', color: '#d99b1b', description: 'Janelas amarelas' },
    { label: 'Para revisão', field: 'redWindows', color: '#dc4c5c', description: 'Janelas vermelhas' }
  ];
  const totals = levels.map(level => meetings.reduce((sum, meeting) => sum + Number(meeting[level.field] || 0), 0));
  const totalWindows = totals.reduce((sum, value) => sum + value, 0);
  if (!totalWindows) {
    container.innerHTML = '<div class="overview-empty">Ainda não há janelas suficientes para consolidar o semáforo.</div>';
    return;
  }
  container.innerHTML = levels.map((level, index) => {
    const percent = Math.round((totals[index] / totalWindows) * 100);
    return `<article style="--traffic-color:${level.color}"><span>${level.label}</span><strong>${percent}%</strong><div><i style="width:${percent}%"></i></div><small>${totals[index]} ${level.description.toLowerCase()}</small></article>`;
  }).join('');
}

function renderOverviewRanking(meetings) {
  const container = document.querySelector('#overviewRankingList');
  const ranked = meetings
    .filter(meeting => Number.isFinite(meeting.engagedFraction))
    .sort((a, b) => Number(b.engagedFraction) - Number(a.engagedFraction));
  if (!ranked.length) {
    container.innerHTML = '<div class="overview-empty">Ainda não há médias para organizar as reuniões.</div>';
    return;
  }
  container.innerHTML = ranked.map((meeting, index) => `
    <article class="overview-ranking-row">
      <b>${index + 1}</b>
      <div><strong>${escapeHtml(meeting.title)}</strong><span>${meeting.participants} participantes · ${meeting.alerts} mudanças · fontes em nível alto/muito alto</span></div>
      <em>${formatPercent(meeting.engagedFraction)}</em>
      <button class="text-button" type="button" data-open-meeting="${meeting.id}" data-meeting-status="${meeting.status}" data-meeting-code="${escapeHtml(meeting.code)}" data-meeting-title="${escapeHtml(meeting.title)}">Abrir</button>
    </article>`).join('');
}

function renderOverviewVolume(meetings) {
  const container = document.querySelector('#overviewVolumeGrid');
  const totalInferences = meetings.reduce((sum, meeting) => sum + Number(meeting.inferences || 0), 0);
  const totalWindows = meetings.reduce((sum, meeting) => sum + Number(meeting.windows || 0), 0);
  const averageWindows = meetings.length ? Math.round(totalWindows / meetings.length) : 0;
  const averageParticipants = meetings.length
    ? Math.round(meetings.reduce((sum, meeting) => sum + Number(meeting.participants || 0), 0) / meetings.length)
    : 0;
  const items = [
    { label: 'Inferências', value: totalInferences, note: 'Resultados individuais processados' },
    { label: 'Janelas', value: totalWindows, note: 'Intervalos consolidados' },
    { label: 'Média por reunião', value: averageWindows, note: 'Janelas analisadas' },
    { label: 'Público médio', value: averageParticipants, note: 'Participantes por reunião' }
  ];
  container.innerHTML = items.map(item => `<article><span>${item.label}</span><strong>${item.value}</strong><small>${item.note}</small></article>`).join('');
}

function renderOverviewComparisonPicker(meetings) {
  const validIds = new Set(meetings.map(meeting => meeting.id));
  overviewComparisonSelection = new Set([...overviewComparisonSelection].filter(id => validIds.has(id)));
  if (!overviewComparisonSelection.size && meetings.length >= 2) {
    meetings.slice(0, 2).forEach(meeting => overviewComparisonSelection.add(meeting.id));
  }
  const picker = document.querySelector('#comparisonMeetingPicker');
  picker.innerHTML = meetings.length
    ? meetings.map((meeting, index) => `
      <label class="comparison-meeting-option">
        <input type="checkbox" value="${meeting.id}" ${overviewComparisonSelection.has(meeting.id) ? 'checked' : ''}>
        <span><strong>${escapeHtml(meeting.title)}</strong><small>Reunião ${index + 1} · ${formatPercent(meeting.engagedFraction)}</small></span>
      </label>`).join('')
    : '<div class="overview-empty">Nenhuma reunião concluída para comparar.</div>';
  updateComparisonSelectionHint();
  renderOverviewComparison();
}

function updateComparisonSelectionHint(message = '') {
  const hint = document.querySelector('#comparisonSelectionHint');
  if (!hint) return;
  const count = overviewComparisonSelection.size;
  hint.textContent = message || `${count} de 4 reuniões selecionadas${count < 2 ? ' · escolha pelo menos 2' : ''}.`;
  hint.dataset.state = count >= 2 && count <= 4 ? 'ready' : 'waiting';
}

async function getOverviewComparisonDetails(meeting) {
  if (overviewComparisonDetails.has(meeting.id)) return overviewComparisonDetails.get(meeting.id);
  if (!dataApi) return {};
  const { data, error } = await dataApi.getTimeline(meeting.id);
  const timeline = error ? [] : data || [];
  const faceValues = timeline.map(row => row.faceRatio).filter(Number.isFinite);
  const details = {
    boredAverage: timeline.length ? averageMetric(timeline, 'boredFraction') : null,
    confusedAverage: timeline.length ? averageMetric(timeline, 'confusedFraction') : null,
    frustratedAverage: timeline.length ? averageMetric(timeline, 'frustratedFraction') : null,
    faceRatioAverage: faceValues.length ? faceValues.reduce((sum, value) => sum + value, 0) / faceValues.length : null,
    participantsAverage: timeline.length ? averageMetric(timeline, 'participants') : null
  };
  overviewComparisonDetails.set(meeting.id, details);
  return details;
}

function overviewComparisonMetrics() {
  const presetGroups = {
    essential: new Set(['performance', 'participation']),
    reactions: new Set(['reactions']),
    traffic: new Set(['traffic']),
    data: new Set(['data'])
  };
  const selectedGroups = presetGroups[overviewComparisonPreset] || presetGroups.essential;
  return [
    { group: 'performance', label: 'Fontes em engajamento alto (média)', field: 'engagedFraction', format: value => value == null ? '—' : formatPercent(value) },
    { group: 'performance', label: 'Mudanças por janela', field: 'alertRate', format: value => value == null ? '—' : formatPercent(value) },
    { group: 'reactions', label: 'Fontes em tédio alto (média)', field: 'boredAverage', format: value => value == null ? '—' : formatPercent(value) },
    { group: 'reactions', label: 'Fontes em confusão alta (média)', field: 'confusedAverage', format: value => value == null ? '—' : formatPercent(value) },
    { group: 'reactions', label: 'Fontes em frustração alta (média)', field: 'frustratedAverage', format: value => value == null ? '—' : formatPercent(value) },
    { group: 'participation', label: 'Maior público analisado', field: 'participants', format: value => String(Math.round(value ?? 0)) },
    { group: 'participation', label: 'Público médio por janela', field: 'participantsAverage', format: value => value == null ? '—' : Number(value).toFixed(1).replace('.', ',') },
    { group: 'traffic', label: 'Janelas estáveis', field: 'greenShare', format: value => value == null ? '—' : formatPercent(value) },
    { group: 'traffic', label: 'Janelas de atenção', field: 'yellowShare', format: value => value == null ? '—' : formatPercent(value) },
    { group: 'traffic', label: 'Janelas para revisão', field: 'redShare', format: value => value == null ? '—' : formatPercent(value) },
    { group: 'data', label: 'Inferências processadas', field: 'inferences', format: value => String(Math.round(value ?? 0)) },
    { group: 'data', label: 'Janelas analisadas', field: 'windows', format: value => String(Math.round(value ?? 0)) },
    { group: 'data', label: 'Cobertura facial', field: 'faceRatioAverage', format: value => value == null ? '—' : formatPercent(value) },
    { group: 'data', label: 'Duração', field: 'duration', format: value => formatDuration(value) }
  ].filter(metric => selectedGroups.has(metric.group));
}

async function getOverviewComparisonRecords(meetings) {
  const details = await Promise.all(meetings.map(getOverviewComparisonDetails));
  return meetings.map((meeting, index) => {
    const totalTraffic = Number(meeting.greenWindows || 0) + Number(meeting.yellowWindows || 0) + Number(meeting.redWindows || 0);
    return {
      ...meeting,
      ...details[index],
      alertRate: meeting.windows ? Number(meeting.alerts || 0) / Number(meeting.windows) : null,
      greenShare: totalTraffic ? Number(meeting.greenWindows || 0) / totalTraffic : null,
      yellowShare: totalTraffic ? Number(meeting.yellowWindows || 0) / totalTraffic : null,
      redShare: totalTraffic ? Number(meeting.redWindows || 0) / totalTraffic : null
    };
  });
}

async function renderOverviewComparison() {
  const container = document.querySelector('#meetingComparisonResults');
  const token = ++overviewComparisonRenderToken;
  const selected = overviewFinishedMeetings.filter(meeting => overviewComparisonSelection.has(meeting.id));
  if (selected.length < 2) {
    container.innerHTML = `<div class="overview-empty">${overviewFinishedMeetings.length < 2 ? 'Conclua pelo menos duas reuniões para comparar.' : 'Marque pelo menos duas reuniões.'}</div>`;
    return;
  }
  const metrics = overviewComparisonMetrics();
  if (!metrics.length) {
    container.innerHTML = '<div class="overview-empty">Escolha pelo menos um grupo de métricas.</div>';
    return;
  }
  container.innerHTML = '<div class="overview-empty compact-loading">Calculando as médias das reuniões...</div>';
  const records = await getOverviewComparisonRecords(selected);
  if (token !== overviewComparisonRenderToken) return;
  container.innerHTML = `<div class="multi-comparison-table-wrap"><table class="multi-comparison-table">
    <thead><tr><th>Métrica</th>${records.map(meeting => `<th title="${escapeHtml(meeting.title)}">${escapeHtml(meeting.title)}</th>`).join('')}</tr></thead>
    <tbody>${metrics.map(metric => `<tr><th>${metric.label}</th>${records.map(meeting => (
      `<td>${metric.format(meeting[metric.field])}</td>`
    )).join('')}</tr>`).join('')}</tbody>
  </table></div>`;
}

document.querySelector('#comparisonMeetingPicker').addEventListener('change', event => {
  if (!event.target.matches('input[type="checkbox"]')) return;
  if (event.target.checked && overviewComparisonSelection.size >= 4) {
    event.target.checked = false;
    updateComparisonSelectionHint('Limite de 4 reuniões. Desmarque uma para trocar.');
    showToast('Compare no máximo quatro reuniões por vez.');
    return;
  }
  if (event.target.checked) overviewComparisonSelection.add(event.target.value);
  else overviewComparisonSelection.delete(event.target.value);
  updateComparisonSelectionHint();
  renderOverviewComparison();
});

document.querySelector('#comparisonMetricPreset').addEventListener('change', event => {
  overviewComparisonPreset = event.target.value || 'essential';
  renderOverviewComparison();
});

document.querySelectorAll('[data-comparison-select]').forEach(button => {
  button.addEventListener('click', () => {
    if (button.dataset.comparisonSelect === 'recent') {
      overviewComparisonSelection = new Set(overviewFinishedMeetings.slice(0, 2).map(meeting => meeting.id));
    } else {
      overviewComparisonSelection.clear();
    }
    document.querySelectorAll('#comparisonMeetingPicker input[type="checkbox"]').forEach(input => {
      input.checked = overviewComparisonSelection.has(input.value);
    });
    updateComparisonSelectionHint();
    renderOverviewComparison();
  });
});

function focusOverviewWidget(widgetId) {
  const widget = document.querySelector(`[data-overview-widget="${widgetId}"]`);
  if (!widget) return;
  widget.hidden = false;
  widget.classList.add('overview-widget-highlight');
  widget.scrollIntoView({ behavior: 'smooth', block: 'center' });
  window.setTimeout(() => widget.classList.remove('overview-widget-highlight'), 1500);
}

function revealDashboardWidgetChange(scope, widgetId, enabled) {
  const isOverview = scope === 'overview';
  const labels = isOverview ? OVERVIEW_DASHBOARD_WIDGETS : DASHBOARD_WIDGETS;
  const feedback = document.querySelector(isOverview ? '#overviewDashboardEditorFeedback' : '#dashboardEditorFeedback');
  const label = labels[widgetId] || 'Bloco';
  feedback.textContent = enabled
    ? `Adicionado: ${label}. O bloco foi destacado no painel abaixo.`
    : `Ocultado: ${label}. Você pode reativá-lo a qualquer momento.`;
  if (!enabled) return;
  const attribute = isOverview ? 'data-overview-widget' : 'data-dashboard-widget';
  const widget = document.querySelector(`[${attribute}="${widgetId}"]`);
  if (!widget) return;
  requestAnimationFrame(() => {
    widget.classList.add('dashboard-widget-new-highlight');
    widget.scrollIntoView({ behavior: 'smooth', block: 'center' });
    window.setTimeout(() => widget.classList.remove('dashboard-widget-new-highlight'), 1900);
  });
}

document.querySelectorAll('[data-overview-action]').forEach(card => {
  const activate = event => {
    if (event?.target?.closest('.overview-widget-drag-handle, .overview-widget-resize')) return;
    focusOverviewWidget(card.dataset.overviewAction === 'alerts' ? 'alerts' : 'engagement');
  };
  card.addEventListener('click', activate);
  card.addEventListener('keydown', event => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    if (event.target.closest('.overview-widget-drag-handle, .overview-widget-resize')) return;
    event.preventDefault();
    activate(event);
  });
});

document.querySelector('#closeOverviewAlerts').addEventListener('click', () => {
  document.querySelector('[data-overview-widget="alerts"]').hidden = true;
});

function renderMeetings(meetings) {
  const list = document.querySelector('#meetingList');
  if (!meetings.length) {
    list.innerHTML = `
      <div class="meetings-empty">
        <span>□</span><strong>Nenhuma reunião registrada</strong>
        <p>Abra o Google Meet, entre na extensão e inicie a análise para criar a primeira sessão.</p>
      </div>`;
    return;
  }

  list.innerHTML = meetings.map(meeting => {
    const date = meeting.startedAt ? new Date(meeting.startedAt) : null;
    const day = date ? String(date.getDate()).padStart(2, '0') : '—';
    const month = date ? date.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '').toUpperCase() : 'NOVA';
    const statusLabel = { criada: 'Criada', em_andamento: 'Em andamento', encerrada: 'Concluída' }[meeting.status] || meeting.status;
    const statusClass = meeting.status === 'encerrada' ? 'completed' : meeting.status === 'em_andamento' ? 'running' : 'created';
    const details = `${meeting.participants} participantes · ${formatDuration(meeting.duration)}`;
    const score = meeting.engagedFraction == null ? '—' : formatPercent(meeting.engagedFraction);
    const primaryAction = meeting.status === 'encerrada'
      ? `<button class="secondary-button small-button" type="button" data-open-meeting="${meeting.id}" data-meeting-status="${meeting.status}" data-meeting-code="${escapeHtml(meeting.code)}" data-meeting-title="${escapeHtml(meeting.title)}">Ver resumo</button>`
      : `<span class="meeting-meet-note">Acompanhe pelo Google Meet</span>`;
    const action = `<div class="meeting-actions">${primaryAction}<button class="meeting-icon-action danger" type="button" title="Excluir reunião" aria-label="Excluir ${escapeHtml(meeting.title)}" data-delete-meeting="${meeting.id}" data-meeting-title="${escapeHtml(meeting.title)}">×</button></div>`;
    return `
      <article class="meeting-row">
        <div class="meeting-date"><strong>${day}</strong><span>${month}</span></div>
        <div class="meeting-main"><div class="meeting-title-row"><strong>${escapeHtml(meeting.title)}</strong><button class="inline-edit-pencil" type="button" title="Editar título" aria-label="Editar título de ${escapeHtml(meeting.title)}" data-edit-meeting="${meeting.id}" data-meeting-title="${escapeHtml(meeting.title)}">✎</button></div><span>${details} · código ${escapeHtml(meeting.code)}</span></div>
        <span class="status-pill ${statusClass}">${statusLabel}</span>
        <div class="meeting-score"><strong>${score}</strong><span>fontes em engajamento alto</span></div>
        ${action}
      </article>`;
  }).join('');
}

function renderDemoMeetings(meetings) {
  const list = document.querySelector('#demoMeetingList');
  if (!meetings.length) {
    list.innerHTML = '<div class="meetings-empty">Nenhuma demonstração disponível.</div>';
    return;
  }
  list.innerHTML = meetings.map(meeting => {
    const date = meeting.startedAt ? new Date(meeting.startedAt) : null;
    const day = date ? String(date.getDate()).padStart(2, '0') : '—';
    const month = date ? date.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '').toUpperCase() : 'DEMO';
    return `<article class="meeting-row demo-meeting-row">
      <div class="meeting-date"><strong>${day}</strong><span>${month}</span></div>
      <div class="meeting-main"><strong>${escapeHtml(meeting.title)}</strong><span>${meeting.participants} participantes · ${formatDuration(meeting.duration)} · dados de exemplo</span></div>
      <span class="status-pill demo">Demonstração</span>
      <div class="meeting-score"><strong>${formatPercent(meeting.engagedFraction)}</strong><span>fontes em engajamento alto</span></div>
      <div class="meeting-actions"><button class="secondary-button small-button" type="button" data-open-meeting="${meeting.id}" data-meeting-status="${meeting.status}" data-meeting-code="${escapeHtml(meeting.code)}" data-meeting-title="${escapeHtml(meeting.title)}">Abrir exemplo</button></div>
    </article>`;
  }).join('');
}

function openStoredMeeting(button) {
  if (button.dataset.meetingStatus === 'encerrada') {
    selectedSummaryId = button.dataset.openMeeting;
    showView('summary');
    return;
  }
  showView('overview');
  void refreshExtensionPresence();
  showToast('A reunião em andamento é controlada pela extensão no Google Meet.');
}

function renderMeetingError() {
  document.querySelector('#meetingList').innerHTML = `
    <div class="meetings-empty error">
      <strong>As reuniões ainda não puderam ser carregadas.</strong>
      <p>Execute o script de configuração no Supabase e entre novamente.</p>
    </div>`;
}

function occupationLabel(value = 'Palestrante') {
  const legacyLabels = {
    palestrante: 'Palestrante',
    professor: 'Professor(a)',
    vendedor: 'Vendedor(a)',
    treinador: 'Treinador(a)',
    consultor: 'Consultor(a)',
    outro: 'Outra atuação'
  };
  const normalized = String(value || '').trim();
  return legacyLabels[normalized.toLowerCase()] || normalized || 'Palestrante';
}

function fillProfileForm(profile = {}) {
  document.querySelector('#profileName').value = profile.name || '';
  document.querySelector('#profileGender').value = profile.gender || 'nao_informado';
  document.querySelector('#profileOccupation').value = occupationLabel(profile.occupation);
  const initials = (profile.name || 'MF').split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase();
  updatePhotoPreview(initials, profile.photoUrl);
}

function applyProfileIdentity(initials, photoUrl) {
  document.querySelector('#sidebarInitials').textContent = initials;
  const image = document.querySelector('#sidebarAvatarImage');
  image.hidden = !photoUrl;
  if (photoUrl) image.src = photoUrl;
  else image.removeAttribute('src');
  document.querySelector('#sidebarInitials').hidden = Boolean(photoUrl);
}

function updatePhotoPreview(initials, photoUrl) {
  document.querySelector('#profilePhotoInitials').textContent = initials;
  const image = document.querySelector('#profilePhotoImage');
  image.hidden = !photoUrl;
  if (photoUrl) image.src = photoUrl;
  else image.removeAttribute('src');
  document.querySelector('#profilePhotoInitials').hidden = Boolean(photoUrl);
}

document.querySelector('#profilePhotoInput').addEventListener('change', event => {
  const [file] = event.target.files;
  if (!file) return;
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
    event.target.value = '';
    return showToast('Escolha uma imagem PNG, JPG ou WebP.');
  }
  if (file.size > 3 * 1024 * 1024) {
    event.target.value = '';
    return showToast('A foto deve ter no máximo 3 MB.');
  }
  pendingProfilePhoto = file;
  updatePhotoPreview('', URL.createObjectURL(file));
});

async function loadProfileEditor() {
  if (!dataApi || !signedInUser) return;
  pendingProfilePhoto = null;
  document.querySelector('#profilePhotoInput').value = '';
  const { data, error } = await dataApi.getProfile(signedInUser.id);
  if (error) return showToast('Não foi possível carregar seu perfil.');
  fillProfileForm(data || { email: signedInUser.email });
}

document.querySelector('#profileForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!dataApi || !signedInUser) return;

  const profile = {
    name: document.querySelector('#profileName').value.trim(),
    gender: document.querySelector('#profileGender').value,
    occupation: document.querySelector('#profileOccupation').value.trim()
  };
  if (!profile.name || !profile.occupation) return showToast('Preencha seu nome e atuação.');

  const button = document.querySelector('#saveProfileButton');
  button.disabled = true;
  button.textContent = 'Salvando...';
  if (pendingProfilePhoto) {
    const uploaded = await dataApi.uploadProfilePhoto(signedInUser.id, pendingProfilePhoto);
    if (uploaded.error) {
      button.disabled = false;
      button.textContent = 'Salvar alterações';
      return showToast('Não foi possível enviar a foto.');
    }
    profile.photoPath = uploaded.data.path;
  }
  const { data, error } = await dataApi.updateProfile(signedInUser.id, profile);
  button.disabled = false;
  button.textContent = 'Salvar alterações';
  if (error) return showToast('Não foi possível salvar seu perfil.');

  pendingProfilePhoto = null;
  document.querySelector('#profilePhotoInput').value = '';
  fillProfileForm(data);
  await loadAccount();
  showToast('Perfil atualizado.');
});

function setPasswordVisibility(inputIds, button) {
  const inputs = inputIds.map(id => document.querySelector(`#${id}`));
  const willShow = inputs[0].type === 'password';
  inputs.forEach(input => { input.type = willShow ? 'text' : 'password'; });
  button.textContent = willShow
    ? (inputs.length > 1 ? 'Ocultar senhas' : 'Ocultar senha')
    : (inputs.length > 1 ? 'Mostrar senhas' : 'Mostrar senha');
}

function prepareRegistrationDataView() {
  document.querySelector('#accountUnlockForm').hidden = false;
  document.querySelector('#accountDataForm').hidden = true;
  document.querySelector('#accountCurrentPassword').value = '';
  document.querySelector('#accountCurrentPassword').type = 'password';
  document.querySelector('#toggleCurrentPassword').textContent = 'Mostrar senha';
  document.querySelector('#accountNewPassword').value = '';
  document.querySelector('#accountConfirmPassword').value = '';
  document.querySelector('#accountNewPassword').type = 'password';
  document.querySelector('#accountConfirmPassword').type = 'password';
  document.querySelector('#toggleNewPasswords').textContent = 'Mostrar senhas';
}

document.querySelector('#toggleCurrentPassword').addEventListener('click', event => {
  setPasswordVisibility(['accountCurrentPassword'], event.currentTarget);
});

document.querySelector('#toggleNewPasswords').addEventListener('click', event => {
  setPasswordVisibility(['accountNewPassword', 'accountConfirmPassword'], event.currentTarget);
});

document.querySelector('#accountUnlockForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!db || !dataApi || !signedInUser) return;
  const password = document.querySelector('#accountCurrentPassword').value;
  const button = document.querySelector('#unlockAccountButton');
  button.disabled = true;
  button.textContent = 'Confirmando...';
  const { error } = await db.auth.signInWithPassword({ email: signedInUser.email, password });
  button.disabled = false;
  button.textContent = 'Acessar dados de cadastro';
  if (error) return showToast('Senha atual incorreta. Tente novamente.');

  const { data: profile, error: profileError } = await dataApi.getProfile(signedInUser.id);
  if (profileError) return showToast('Não foi possível carregar os dados de cadastro.');
  document.querySelector('#accountEmail').value = signedInUser.email || '';
  document.querySelector('#accountInstitution').value = profile?.institution || '';
  document.querySelector('#accountUnlockForm').hidden = true;
  document.querySelector('#accountDataForm').hidden = false;
  document.querySelector('#accountNewPassword').focus();
});

document.querySelector('#accountDataForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!db || !dataApi || !signedInUser) return;
  const email = document.querySelector('#accountEmail').value.trim();
  const institution = document.querySelector('#accountInstitution').value.trim();
  const password = document.querySelector('#accountNewPassword').value;
  const confirmation = document.querySelector('#accountConfirmPassword').value;
  if (!email || !document.querySelector('#accountEmail').validity.valid) return showToast('Informe um e-mail válido.');
  if (!institution) return showToast('Informe sua instituição ou empresa.');
  if (password && password.length < 8) return showToast('A nova senha precisa ter pelo menos 8 caracteres.');
  if (password !== confirmation) return showToast('As novas senhas não são iguais.');

  const authChanges = {};
  const emailChanged = email.toLowerCase() !== String(signedInUser.email || '').toLowerCase();
  if (emailChanged) authChanges.email = email;
  if (password) authChanges.password = password;

  const button = document.querySelector('#saveAccountButton');
  button.disabled = true;
  button.textContent = 'Salvando...';
  if (Object.keys(authChanges).length) {
    const { data, error } = await db.auth.updateUser(authChanges);
    if (error) {
      button.disabled = false;
      button.textContent = 'Salvar dados de cadastro';
      return showToast(readableAuthError(error.message));
    }
    if (data.user) signedInUser = data.user;
  }

  const { error: profileError } = await dataApi.updateRegistrationData(signedInUser.id, institution);
  button.disabled = false;
  button.textContent = 'Salvar dados de cadastro';
  if (profileError) return showToast('A conta foi atualizada, mas não conseguimos salvar a instituição.');

  await loadAccount();
  showView('profile');
  showToast(emailChanged ? 'Confira o novo e-mail para confirmar a alteração.' : 'Dados de cadastro atualizados.');
});

function escapeHtml(value = '') {
  return String(value).replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[character]);
}

function formatPercent(value) {
  const number = Number(value);
  return Number.isFinite(number) ? `${Math.round(number * 100)}%` : '—';
}

function formatDuration(value) {
  if (!value) return 'sem duração';
  if (typeof value === 'string') return value.split('.')[0];
  return String(value);
}

function formatTime(value) {
  if (!value) return '—';
  return new Date(value).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

async function prepareNewMeeting() {
  clearInterval(waitingTimer);
  if (!dataApi || !signedInUser) return showToast('Entre na sua conta antes de criar uma reunião.');

  const button = document.querySelector('#newMeetingButton');
  if (!button) return showToast('As novas reuniões agora são iniciadas pela extensão no Google Meet.');
  button.disabled = true;
  button.textContent = 'Criando...';
  const { data, error } = await dataApi.createMeeting(signedInUser.id);
  button.disabled = false;
  button.textContent = '＋ Nova reunião';

  if (error) {
    showToast('Não foi possível criar a reunião. Confira as regras do banco.');
    return;
  }

  currentMeetingId = data.id;
  const code = data.code || createMeetingCode();
  await loadAccount();
  document.querySelector('#meetingCode').textContent = code;
  document.querySelector('#emptyMeetingCode').textContent = code;
  document.querySelector('#waitingList').innerHTML = `
    <div class="empty-state" id="waitingEmpty">
      <span>◎</span><strong>Aguardando participantes</strong>
      <p>Compartilhe o código <b>${code}</b></p>
    </div>`;
  document.querySelector('#waitingCount').textContent = '0 participantes conectados';
  document.querySelector('#startMeetingButton').disabled = false;
  showView('setup');
}

function createMeetingCode() {
  const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let suffix = '';
  for (let i = 0; i < 4; i += 1) suffix += characters[Math.floor(Math.random() * characters.length)];
  return `MF-${suffix}`;
}

document.querySelector('#copyCodeButton').addEventListener('click', async () => {
  const code = document.querySelector('#meetingCode').textContent;
  try {
    await navigator.clipboard.writeText(code);
    showToast(`Código ${code} copiado.`);
  } catch {
    showToast(`Código da sessão: ${code}`);
  }
});

document.querySelector('#startMeetingButton').addEventListener('click', async () => {
  clearInterval(waitingTimer);
  const title = document.querySelector('#meetingTitle').value.trim() || 'Reunião sem título';
  const platform = document.querySelector('#meetingPlatform').value;
  const button = document.querySelector('#startMeetingButton');
  button.disabled = true;
  button.textContent = 'Iniciando...';

  if (dataApi && currentMeetingId) {
    const { error } = await dataApi.updateMeeting(currentMeetingId, {
      title,
      platform,
      status: 'em_andamento',
      startedAt: new Date().toISOString()
    });

    if (error) {
      button.disabled = false;
      button.textContent = 'Iniciar análise';
      return showToast('Não foi possível iniciar. Confira as regras do banco.');
    }
  }

  button.disabled = false;
  button.textContent = 'Iniciar análise';
  document.querySelector('#liveMeetingTitle').textContent = title;
  meetingSeconds = 0;
  updateTimer();
  showView('live');
  startMeeting();
  showToast('Análise iniciada. O indicador já está atualizando.');
});

function startMeeting() {
  stopMeetingTimers();
  meetingTimer = setInterval(() => {
    meetingSeconds += 1;
    updateTimer();
  }, 1000);
  loadLiveData();
  metricsTimer = setInterval(loadLiveData, 5000);
}

function updateTimer() {
  const hours = String(Math.floor(meetingSeconds / 3600)).padStart(2, '0');
  const minutes = String(Math.floor((meetingSeconds % 3600) / 60)).padStart(2, '0');
  const seconds = String(meetingSeconds % 60).padStart(2, '0');
  document.querySelector('#meetingTimer').textContent = `${hours}:${minutes}:${seconds}`;
}

async function loadLiveData() {
  if (!dataApi || !currentMeetingId) return;
  const { data, error } = await dataApi.getLatestTimelinePoint(currentMeetingId);

  if (error || !data) {
    document.querySelector('#liveReaction').textContent = 'Aguardando dados';
    document.querySelector('#captureTime').textContent = '—';
    return;
  }

  const engagement = Math.round(data.engagedFraction * 100);
  const boredom = Math.round(data.boredFraction * 100);
  const confusion = Math.round(data.confusedFraction * 100);
  const frustration = Math.round(data.frustratedFraction * 100);
  const reactionMap = {
    verde: ['Engajado', '☺'],
    amarelo: ['Atenção', '•‿•'],
    vermelho: ['Momento para revisar', '—']
  };
  const [reaction, face] = reactionMap[data.color] || ['Leitura recebida', '•'];
  const analyzed = data.participants;

  latestMetrics = {
    reaction,
    face,
    engagement,
    boredom,
    confusion,
    frustration,
    analyzed,
    total: analyzed,
    capturedAt: data.startedAt
  };
  document.querySelector('#liveReaction').textContent = reaction;
  document.querySelector('#reactionFace').textContent = face;
  document.querySelector('#liveScore').textContent = `${engagement}%`;
  setMetric('boredom', boredom);
  setMetric('confusion', confusion);
  setMetric('frustration', frustration);
  document.querySelector('#captureTime').textContent = formatTime(data.startedAt);
  document.querySelector('#analyzedTotal').textContent = `${analyzed} participante${analyzed === 1 ? '' : 's'} analisado${analyzed === 1 ? '' : 's'}`;
  document.querySelector('#liveParticipantCount').textContent = String(analyzed);
  document.querySelector('#liveParticipantMessage').innerHTML = `<span>✓</span><strong>Leitura recebida</strong><p>Última janela registrada às ${formatTime(data.startedAt)}.</p>`;
  updateFloatingIndicator();
}

function setMetric(name, value) {
  const number = Number(value);
  document.querySelector(`#${name}Value`).textContent = Number.isFinite(number) ? `${number}%` : '—';
  document.querySelector(`#${name}Bar`).style.width = Number.isFinite(number) ? `${number}%` : '0';
}

// O navegador tenta abrir uma janelinha que pode ficar sobre o Teams.
// Se ele não souber fazer isso, mostramos o mesmo card no canto do site.
document.querySelector('#openFloatingButton').addEventListener('click', openFloatingIndicator);

async function openFloatingIndicator() {
  if ('documentPictureInPicture' in window) {
    try {
      if (!pipWindow || pipWindow.closed) {
        pipWindow = await window.documentPictureInPicture.requestWindow({ width: 310, height: 176 });
        pipWindow.document.title = 'MindFlowIA — Indicador';
        pipWindow.addEventListener('pagehide', () => { pipWindow = null; });
      }
      renderPipDocument();
      return;
    } catch {
      // Negou a janelinha? Sem crise, cai no card fixo.
    }
  }
  floatingFallback.classList.add('open');
  updateFloatingIndicator();
  showToast('Indicador aberto no canto da página.');
}

function renderPipDocument() {
  if (!pipWindow || pipWindow.closed) return;
  pipWindow.document.body.innerHTML = `
    <style>
      *{box-sizing:border-box}body{margin:0;background:#f4f5f8;color:#17203a;font:13px Inter,Segoe UI,sans-serif}
      .card{height:100vh;display:grid;grid-template-columns:58px 1fr;align-items:center;gap:13px;padding:17px;background:white;border:1px solid #e1e4eb}
      .face{display:grid;width:56px;height:56px;place-items:center;border:2px solid #1b9c5a;border-radius:50%;color:#1b9c5a;background:#eaf8f0;font-size:36px}
      small,strong,span{display:block}small{margin-bottom:4px;color:#6b7184;font-size:9px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
      strong{font-size:17px}span{margin-top:4px;color:#6b7184;font-size:11px}.score{color:#1b9c5a;font-weight:800}
    </style>
    <div class="card">
      <div class="face" id="pipFace"></div>
      <div><small>MindFlowIA · ao vivo</small><strong id="pipReaction"></strong><span><b class="score" id="pipScore"></b> · <span id="pipAnalyzed" style="display:inline"></span></span><span>Captura <b id="pipCapture"></b></span></div>
    </div>`;
  updateFloatingIndicator();
}

function updateFloatingIndicator() {
  const now = latestMetrics.capturedAt ? formatTime(latestMetrics.capturedAt) : 'aguardando';
  const people = `${latestMetrics.analyzed} participante${latestMetrics.analyzed === 1 ? '' : 's'} analisado${latestMetrics.analyzed === 1 ? '' : 's'}`;
  const scoreText = latestMetrics.capturedAt ? `${latestMetrics.engagement}%` : '—';
  if (pipWindow && !pipWindow.closed) {
    pipWindow.document.querySelector('#pipFace').textContent = latestMetrics.face;
    pipWindow.document.querySelector('#pipReaction').textContent = latestMetrics.reaction;
    pipWindow.document.querySelector('#pipScore').textContent = scoreText;
    pipWindow.document.querySelector('#pipAnalyzed').textContent = people;
    pipWindow.document.querySelector('#pipCapture').textContent = now;
  }

  floatingFallback.innerHTML = `
    <button type="button" aria-label="Fechar indicador">⌄</button>
    <span class="mini-face">${latestMetrics.face}</span>
    <div><small>MindFlowIA · ao vivo</small><strong>${latestMetrics.reaction} · ${scoreText}</strong><span>${people} · ${now}</span></div>`;
  floatingFallback.querySelector('button').addEventListener('click', () => floatingFallback.classList.remove('open'));
}

document.querySelector('#endMeetingButton').addEventListener('click', async () => {
  if (dataApi && currentMeetingId) {
    const { error } = await dataApi.updateMeeting(currentMeetingId, {
      status: 'encerrada',
      endedAt: new Date().toISOString()
    });
    if (error) showToast('A reunião fechou no site, mas o banco não foi atualizado.');
  }
  stopMeeting();
  selectedSummaryId = currentMeetingId;
  await loadAccount();
  showView('summary');
  showToast('Reunião encerrada. Resumo gerado.');
});

function stopMeetingTimers() {
  clearInterval(meetingTimer);
  clearInterval(metricsTimer);
}

function stopMeeting() {
  stopMeetingTimers();
  floatingFallback.classList.remove('open');
  if (pipWindow && !pipWindow.closed) pipWindow.close();
  pipWindow = null;
}

async function loadSelectedSummary() {
  if (!dataApi) return;
  if (!selectedSummaryId) {
    renderSummaryEmpty();
    return;
  }

  const { data: summary, error: summaryError } = await dataApi.getMeetingSummary(selectedSummaryId);
  if (summaryError || !summary) {
    renderSummaryEmpty();
    return;
  }

  selectedSummaryId = summary.id;
  const [{ data: timeline, error: timelineError }, { data: alerts, error: alertsError }] = await Promise.all([
    dataApi.getTimeline(summary.id),
    dataApi.getAlerts(summary.id)
  ]);
  currentSummaryAlerts = alertsError ? [] : alerts || [];
  selectedAnnotationMoment = null;
  selectedAnnotationEnd = null;
  renderSummary(summary, timelineError ? [] : timeline || []);
  await loadAnnotations(summary.id);
  if (pendingSummaryFocus === 'alerts') {
    pendingSummaryFocus = null;
    focusSummaryAlerts();
  }
}

function renderSummary(summary, timeline) {
  currentSummary = summary;
  currentSummaryTimeline = timeline;
  timelineTableExpanded = false;
  const dateText = summary.startedAt
    ? new Date(summary.startedAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })
    : 'Ainda não iniciada';
  document.querySelector('#summaryTitle').textContent = summary.title;
  document.querySelector('#summaryMeta').textContent = `${dateText} · ${formatDuration(summary.duration)} · ${summary.participants} participantes`;
  const canManageMeeting = Boolean(signedInUser && summary.ownerId === signedInUser.id);
  document.querySelector('#editMeetingTitleButton').hidden = !canManageMeeting;
  document.querySelector('#deleteMeetingButton').hidden = !canManageMeeting;
  document.querySelector('#summaryInferences').textContent = `${summary.inferences} inferências registradas`;
  document.querySelector('#summaryAlerts').textContent = String(summary.alerts);
  setupTimelineFilters(timeline);
  updateSummaryRange();
  loadDashboardLayouts();
}

document.querySelector('#editMeetingTitleButton').addEventListener('click', () => {
  if (!currentSummary) return showToast('Selecione uma reunião primeiro.');
  openMeetingTitleEditor(currentSummary.id, currentSummary.title);
});

document.querySelector('#deleteMeetingButton').addEventListener('click', () => {
  if (!currentSummary) return showToast('Selecione uma reunião primeiro.');
  openMeetingDeleteDialog(currentSummary.id, currentSummary.title);
});

function renderSummaryEmpty() {
  currentSummary = null;
  currentSummaryTimeline = [];
  currentSummaryAlerts = [];
  filteredSummaryTimeline = [];
  selectedAnnotationMoment = null;
  selectedAnnotationEnd = null;
  document.querySelector('#summaryTitle').textContent = 'Nenhuma reunião disponível';
  document.querySelector('#summaryMeta').textContent = 'Crie uma reunião ou confira o acesso às views do Supabase.';
  document.querySelector('#editMeetingTitleButton').hidden = true;
  document.querySelector('#deleteMeetingButton').hidden = true;
  ['summaryEngagement', 'summaryParticipants', 'summaryWindows', 'summaryAlerts'].forEach(id => {
    document.querySelector(`#${id}`).textContent = '—';
  });
  document.querySelector('#summaryAlertsNote').textContent = 'Sem período selecionado';
  document.querySelector('#timelineTableBody').innerHTML = '<tr><td colspan="6">Nenhuma leitura encontrada.</td></tr>';
  document.querySelector('#timelineTableCounter').textContent = '0 leituras';
  document.querySelector('#toggleTimelineTable').hidden = true;
  document.querySelector('#reactionDurationContent').innerHTML = '<div class="overview-empty">Nenhuma leitura encontrada.</div>';
  document.querySelector('#trafficDistribution').innerHTML = '<div class="overview-empty">Nenhuma leitura encontrada.</div>';
  document.querySelector('#qualityIndicators').innerHTML = '<div class="overview-empty">Nenhuma leitura encontrada.</div>';
  document.querySelector('#peakMoments').innerHTML = '<div class="overview-empty">Nenhuma leitura encontrada.</div>';
  document.querySelector('#reactionAverageBars').innerHTML = '<div class="overview-empty">Nenhuma leitura encontrada.</div>';
  document.querySelector('#momentMap').innerHTML = '<div class="overview-empty">Nenhuma leitura encontrada.</div>';
  document.querySelector('#periodComparison').innerHTML = '<div class="overview-empty">Nenhuma leitura encontrada.</div>';
  document.querySelector('#attentionMoments').innerHTML = '<div class="overview-empty">Nenhuma leitura encontrada.</div>';
  document.querySelector('#recommendationList').innerHTML = '<div class="overview-empty">Nenhuma leitura encontrada.</div>';
  document.querySelector('#annotationList').innerHTML = '<div class="overview-empty">Nenhuma anotação registrada.</div>';
  currentAnnotations = [];
  drawParticipantsChart([]);
  document.querySelector('#finalSummaryText').textContent = 'Ainda não há dados suficientes para gerar o resumo.';
  hideSummaryFocusNotice();
  setupTimelineFilters([]);
  drawSummaryChart([]);
  loadDashboardLayouts();
}

function renderTimelineTable(timeline) {
  const body = document.querySelector('#timelineTableBody');
  const toggle = document.querySelector('#toggleTimelineTable');
  document.querySelector('#timelineTableCounter').textContent = `${timeline.length} leitura${timeline.length === 1 ? '' : 's'}`;
  if (!timeline.length) {
    body.innerHTML = '<tr><td colspan="6">Esta reunião ainda não possui janelas registradas.</td></tr>';
    toggle.hidden = true;
    return;
  }
  const sessionStart = new Date(currentSummaryTimeline[0]?.startedAt || timeline[0].startedAt).getTime();
  const displayedRows = timelineTableExpanded ? timeline : timeline.slice(0, 4);
  body.innerHTML = displayedRows.map(row => {
    const elapsedSeconds = Math.max(0, Math.round((new Date(row.startedAt).getTime() - sessionStart) / 1000));
    return `<tr>
      <td>${formatElapsedTime(elapsedSeconds)}</td>
      <td>${row.participants}</td>
      <td>${formatPercent(row.engagedFraction)}</td>
      <td>${formatPercent(row.boredFraction)}</td>
      <td>${formatPercent(row.confusedFraction)}</td>
      <td>${formatPercent(row.frustratedFraction)}</td>
    </tr>`;
  }).join('');
  toggle.hidden = timeline.length <= 4;
  toggle.textContent = timelineTableExpanded ? 'Recolher tabela' : `Expandir ${timeline.length} linhas`;
  document.querySelector('#timelineTableScroll').classList.toggle('expanded', timelineTableExpanded);
}

function setupTimelineFilters(timeline) {
  const start = document.querySelector('#timelineStartFilter');
  const end = document.querySelector('#timelineEndFilter');
  const sessionStart = timeline.length ? new Date(timeline[0].startedAt).getTime() : 0;
  const options = timeline.map((row, index) => {
    const seconds = Math.max(0, Math.round((new Date(row.startedAt).getTime() - sessionStart) / 1000));
    return `<option value="${index}">${formatElapsedTime(seconds)}</option>`;
  }).join('');
  start.innerHTML = options || '<option value="0">—</option>';
  end.innerHTML = options || '<option value="0">—</option>';
  start.value = '0';
  end.value = String(Math.max(0, timeline.length - 1));
  start.disabled = !timeline.length;
  end.disabled = !timeline.length;
  chartRangeClickAnchor = null;
  chartRangePointerState = null;
  if (timeline.length) {
    selectedAnnotationMoment = timeline[0].startedAt;
    selectedAnnotationEnd = timeline[timeline.length - 1].startedAt;
    updateAnnotationSelectedLabel();
  } else {
    selectedAnnotationMoment = null;
    selectedAnnotationEnd = null;
    document.querySelector('#annotationSelectedLabel').textContent = 'Nenhum momento disponível para anotar';
  }
  updateChartSelectionHint();
}

function updateAnnotationSelectedLabel() {
  const startRow = currentSummaryTimeline.find(item => item.startedAt === selectedAnnotationMoment);
  const endRow = currentSummaryTimeline.find(item => item.startedAt === selectedAnnotationEnd);
  document.querySelector('#annotationSelectedLabel').textContent = startRow
    ? `A anotação será salva em: ${getElapsedLabel(startRow)}${endRow && endRow.startedAt !== startRow.startedAt ? ` até ${getElapsedLabel(endRow)}` : ''}`
    : 'Escolha o trecho na faixa azul do gráfico';
}

function updateSummaryRange(changedFilter) {
  const startSelect = document.querySelector('#timelineStartFilter');
  const endSelect = document.querySelector('#timelineEndFilter');
  const maxIndex = Math.max(0, currentSummaryTimeline.length - 1);
  let startIndex = Math.max(0, Math.min(maxIndex, Number(startSelect.value || 0)));
  let endIndex = Math.max(0, Math.min(maxIndex, Number(endSelect.value || maxIndex)));
  if (startIndex > endIndex) {
    if (changedFilter === 'start') endIndex = startIndex;
    else startIndex = endIndex;
  }
  startSelect.value = String(startIndex);
  endSelect.value = String(endIndex);
  selectedAnnotationMoment = currentSummaryTimeline[startIndex]?.startedAt || null;
  selectedAnnotationEnd = currentSummaryTimeline[endIndex]?.startedAt || null;
  updateAnnotationSelectedLabel();
  updateChartSelectionHint();
  filteredSummaryTimeline = currentSummaryTimeline.slice(startIndex, endIndex + 1);
  timelineTableExpanded = false;
  const rangeLabel = document.querySelector('#summaryRangeLabel');
  if (rangeLabel) {
    const startRow = currentSummaryTimeline[startIndex];
    const endRow = currentSummaryTimeline[endIndex];
    rangeLabel.textContent = startRow && endRow
      ? `${getElapsedLabel(startRow)} até ${getElapsedLabel(endRow)} · ${filteredSummaryTimeline.length} janela${filteredSummaryTimeline.length === 1 ? '' : 's'} recalculada${filteredSummaryTimeline.length === 1 ? '' : 's'}`
      : 'Aguardando dados da reunião.';
  }
  const resetButton = document.querySelector('#resetSummaryRange');
  if (resetButton) resetButton.disabled = !currentSummaryTimeline.length || (startIndex === 0 && endIndex === currentSummaryTimeline.length - 1);
  hideSummaryFocusNotice();
  renderSummaryDataset(filteredSummaryTimeline);
}

function renderSummaryDataset(timeline) {
  renderFilteredSummaryCards(timeline);
  renderReactionDurations(timeline);
  renderTrafficDistribution(timeline);
  renderQualityIndicators(timeline);
  renderPeakMoments(timeline);
  renderReactionAverages(timeline);
  renderMomentMap(timeline);
  renderPeriodComparison(timeline);
  renderAttentionMoments(timeline);
  renderRecommendations(timeline);
  renderTimelineTable(timeline);
  drawSummaryChart(currentSummaryTimeline);
  drawParticipantsChart(timeline);
  renderFinalSummary(timeline);
}

function renderFilteredSummaryCards(timeline) {
  const engagementValues = timeline.map(row => row.engagedFraction).filter(Number.isFinite);
  const engagement = engagementValues.length
    ? engagementValues.reduce((sum, value) => sum + value, 0) / engagementValues.length
    : null;
  const participants = timeline.length ? Math.max(...timeline.map(row => Number(row.participants || 0))) : 0;
  const colors = timeline.reduce((totals, row) => {
    if (row.color === 'verde') totals.green += 1;
    if (row.color === 'amarelo') totals.yellow += 1;
    if (row.color === 'vermelho') totals.red += 1;
    return totals;
  }, { green: 0, yellow: 0, red: 0 });
  document.querySelector('#summaryEngagement').textContent = engagement == null ? '—' : formatPercent(engagement);
  document.querySelector('#summaryEngagementNote').textContent = `${timeline.length} janela${timeline.length === 1 ? '' : 's'} no filtro`;
  document.querySelector('#summaryParticipants').textContent = timeline.length ? String(participants) : '—';
  document.querySelector('#summaryWindows').textContent = String(timeline.length);
  document.querySelector('#summaryTrafficLights').textContent = `${colors.green} verdes · ${colors.yellow} amarelas · ${colors.red} vermelhas`;
  const intervalAlerts = alertsForTimeline(timeline);
  document.querySelector('#summaryAlerts').textContent = currentSummary ? String(intervalAlerts.length) : '—';
  document.querySelector('#summaryAlertsNote').textContent = timeline.length
    ? `${intervalAlerts.length} mudança${intervalAlerts.length === 1 ? '' : 's'} de cor no período`
    : 'Sem período selecionado';
}

function renderReactionDurations(timeline) {
  const container = document.querySelector('#reactionDurationContent');
  if (!timeline.length) {
    container.innerHTML = '<div class="overview-empty">Sem reações neste intervalo.</div>';
    return;
  }
  const reactions = {
    engaged: { label: 'Engajamento', field: 'engagedFraction', color: '#1b9c5a', soft: '#eaf8f0', symbol: '☺', seconds: 0, windows: 0 },
    bored: { label: 'Tédio', field: 'boredFraction', color: '#4a67d8', soft: '#edf1ff', symbol: '—', seconds: 0, windows: 0 },
    confused: { label: 'Confusão', field: 'confusedFraction', color: '#e78531', soft: '#fff2e5', symbol: '?', seconds: 0, windows: 0 },
    frustrated: { label: 'Frustração', field: 'frustratedFraction', color: '#dc4c5c', soft: '#fff0f2', symbol: '!', seconds: 0, windows: 0 }
  };
  timeline.forEach((row, index) => {
    const duration = getTimelineRowDuration(row, timeline[index + 1]);
    const predominant = Object.values(reactions).reduce((best, reaction) => {
      return Number(row[reaction.field] || 0) > Number(row[best.field] || 0) ? reaction : best;
    });
    predominant.seconds += duration;
    predominant.windows += 1;
  });
  const ranking = Object.values(reactions).sort((a, b) => b.seconds - a.seconds);
  const [dominant, ...others] = ranking;
  container.innerHTML = `
    <div class="dominant-reaction" style="--reaction-color:${dominant.color};--reaction-soft:${dominant.soft}">
      <span class="reaction-symbol">${dominant.symbol}</span><small>Predominante por mais tempo</small><strong>${dominant.label}</strong><b>${formatClockDuration(dominant.seconds)} · ${dominant.windows} janelas</b>
    </div>
    <div class="reaction-duration-list">${others.map(reaction => `<div class="reaction-duration-item" style="border-left:3px solid ${reaction.color}"><span>${reaction.label}</span><strong>${formatClockDuration(reaction.seconds)}</strong><b>${reaction.windows} janelas</b></div>`).join('')}</div>`;
}

function getReactionRanking(timeline) {
  const reactions = {
    engaged: { label: 'Engajamento', field: 'engagedFraction', color: '#1b9c5a', seconds: 0, windows: 0 },
    bored: { label: 'Tédio', field: 'boredFraction', color: '#4a67d8', seconds: 0, windows: 0 },
    confused: { label: 'Confusão', field: 'confusedFraction', color: '#e78531', seconds: 0, windows: 0 },
    frustrated: { label: 'Frustração', field: 'frustratedFraction', color: '#dc4c5c', seconds: 0, windows: 0 }
  };
  timeline.forEach((row, index) => {
    const predominant = Object.values(reactions).reduce((best, reaction) => (
      Number(row[reaction.field] || 0) > Number(row[best.field] || 0) ? reaction : best
    ));
    predominant.seconds += getTimelineRowDuration(row, timeline[index + 1]);
    predominant.windows += 1;
  });
  return Object.values(reactions).sort((a, b) => b.seconds - a.seconds);
}

function renderTrafficDistribution(timeline) {
  const container = document.querySelector('#trafficDistribution');
  if (!timeline.length) {
    container.innerHTML = '<div class="overview-empty">Sem leituras neste intervalo.</div>';
    return;
  }
  const levels = [
    { id: 'verde', label: 'Estável', color: '#1b9c5a' },
    { id: 'amarelo', label: 'Atenção', color: '#e0a526' },
    { id: 'vermelho', label: 'Para revisão', color: '#dc4c5c' }
  ];
  container.innerHTML = levels.map(level => {
    const count = timeline.filter(row => row.color === level.id).length;
    const percentage = Math.round((count / timeline.length) * 100);
    return `<div class="traffic-row"><span><i style="background:${level.color}"></i>${level.label}</span><div><b style="width:${percentage}%;background:${level.color}"></b></div><strong>${percentage}%</strong><small>${count} janelas</small></div>`;
  }).join('');
}

function renderQualityIndicators(timeline) {
  const container = document.querySelector('#qualityIndicators');
  if (!timeline.length) {
    container.innerHTML = '<div class="overview-empty">Sem leituras neste intervalo.</div>';
    return;
  }
  const faceRatios = timeline.filter(row => row.faceRatio != null).map(row => Number(row.faceRatio)).filter(Number.isFinite);
  const faceRatio = faceRatios.length ? faceRatios.reduce((sum, value) => sum + value, 0) / faceRatios.length : null;
  const coveredWindows = timeline.filter(row => Number(row.participants || 0) > 0).length;
  const coverage = Math.round((coveredWindows / timeline.length) * 100);
  const participantPeak = Math.max(...timeline.map(row => Number(row.participants || 0)));
  container.innerHTML = `
    <article><span>Rostos detectados</span><strong>${faceRatio == null ? 'Não informado' : formatPercent(faceRatio)}</strong><small>Média das janelas com esse dado</small></article>
    <article><span>Cobertura do período</span><strong>${coverage}%</strong><small>${coveredWindows} de ${timeline.length} janelas com participantes</small></article>
    <article><span>Pico analisado</span><strong>${participantPeak}</strong><small>participantes simultâneos</small></article>`;
}

function getElapsedLabel(row) {
  if (!row || !currentSummaryTimeline.length) return '—';
  const sessionStart = new Date(currentSummaryTimeline[0].startedAt).getTime();
  const rowStart = new Date(row.startedAt).getTime();
  return formatElapsedTime(Math.max(0, Math.round((rowStart - sessionStart) / 1000)));
}

function renderPeakMoments(timeline) {
  const container = document.querySelector('#peakMoments');
  if (!timeline.length) {
    container.innerHTML = '<div class="overview-empty">Sem leituras neste intervalo.</div>';
    return;
  }
  const metrics = [
    { label: 'Engajamento', field: 'engagedFraction', color: '#1b9c5a' },
    { label: 'Tédio', field: 'boredFraction', color: '#4a67d8' },
    { label: 'Confusão', field: 'confusedFraction', color: '#e78531' },
    { label: 'Frustração', field: 'frustratedFraction', color: '#dc4c5c' }
  ];
  container.innerHTML = metrics.map(metric => {
    const peak = timeline.reduce((best, row) => Number(row[metric.field] || 0) > Number(best[metric.field] || 0) ? row : best, timeline[0]);
    return `<article style="--peak-color:${metric.color}"><span>${metric.label}</span><strong>${formatPercent(peak[metric.field])}</strong><small>em ${getElapsedLabel(peak)}</small></article>`;
  }).join('');
}

function reactionDefinitions() {
  return [
    { label: 'Engajamento', field: 'engagedFraction', color: '#1b9c5a', className: 'engaged' },
    { label: 'Tédio', field: 'boredFraction', color: '#4a67d8', className: 'bored' },
    { label: 'Confusão', field: 'confusedFraction', color: '#e78531', className: 'confused' },
    { label: 'Frustração', field: 'frustratedFraction', color: '#dc4c5c', className: 'frustrated' }
  ];
}

function averageMetric(timeline, field) {
  if (!timeline.length) return 0;
  return timeline.reduce((sum, row) => sum + Number(row[field] || 0), 0) / timeline.length;
}

function renderReactionAverages(timeline) {
  const container = document.querySelector('#reactionAverageBars');
  if (!timeline.length) {
    container.innerHTML = '<div class="overview-empty">Sem leituras neste intervalo.</div>';
    return;
  }
  container.innerHTML = reactionDefinitions().map(reaction => {
    const average = averageMetric(timeline, reaction.field);
    return `<div class="reaction-average-row"><span>${reaction.label}</span><div><i style="width:${Math.round(average * 100)}%;background:${reaction.color}"></i></div><strong>${formatPercent(average)}</strong></div>`;
  }).join('');
}

function renderMomentMap(timeline) {
  const container = document.querySelector('#momentMap');
  if (!timeline.length) {
    container.innerHTML = '<div class="overview-empty">Sem leituras neste intervalo.</div>';
    return;
  }
  const reactions = reactionDefinitions();
  container.innerHTML = timeline.map(row => {
    const predominant = reactions.reduce((best, reaction) => Number(row[reaction.field] || 0) > Number(row[best.field] || 0) ? reaction : best);
    const value = Number(row[predominant.field] || 0);
    const tooltip = `${getElapsedLabel(row)} · ${predominant.label}: ${formatPercent(value)}`;
    return `<span class="moment-block ${predominant.className}" style="opacity:${Math.max(.35, value)}" title="${tooltip}" aria-label="${tooltip}"></span>`;
  }).join('');
}

function renderPeriodComparison(timeline) {
  const container = document.querySelector('#periodComparison');
  if (timeline.length < 2) {
    container.innerHTML = '<div class="overview-empty">São necessárias pelo menos duas janelas para comparar.</div>';
    return;
  }
  const middle = Math.ceil(timeline.length / 2);
  const firstHalf = timeline.slice(0, middle);
  const secondHalf = timeline.slice(middle);
  container.innerHTML = reactionDefinitions().map(reaction => {
    const start = averageMetric(firstHalf, reaction.field);
    const end = averageMetric(secondHalf, reaction.field);
    const delta = end - start;
    const direction = Math.abs(delta) < .005 ? '→' : delta > 0 ? '↑' : '↓';
    return `<article style="--comparison-color:${reaction.color}"><span>${reaction.label}</span><div><small>${formatPercent(start)}</small><b>${direction}</b><strong>${formatPercent(end)}</strong></div><em>${delta >= 0 ? '+' : ''}${Math.round(delta * 100)} pontos</em></article>`;
  }).join('');
}

function attentionScore(row) {
  const reactionWeight = Number(row.confusedFraction || 0) + Number(row.frustratedFraction || 0) + Number(row.boredFraction || 0) + (1 - Number(row.engagedFraction || 0));
  const colorWeight = row.color === 'vermelho' ? 1.5 : row.color === 'amarelo' ? .7 : 0;
  return reactionWeight + colorWeight;
}

function predominantReaction(row) {
  return reactionDefinitions().reduce((best, reaction) => Number(row[reaction.field] || 0) > Number(row[best.field] || 0) ? reaction : best);
}

function renderAttentionMoments(timeline) {
  const container = document.querySelector('#attentionMoments');
  if (!timeline.length) {
    container.innerHTML = '<div class="overview-empty">Sem leituras neste intervalo.</div>';
    return;
  }
  const moments = [...timeline].sort((a, b) => attentionScore(b) - attentionScore(a)).slice(0, 5);
  container.innerHTML = moments.map((row, index) => {
    const reaction = predominantReaction(row);
    const status = row.color === 'vermelho' ? 'Revisão' : row.color === 'amarelo' ? 'Atenção' : 'Estável';
    return `<button type="button" class="attention-moment" data-focus-time="${row.startedAt}"><b>${String(index + 1).padStart(2, '0')}</b><span><strong>${getElapsedLabel(row)}</strong><small>${reaction.label} predominante</small></span><em class="${row.color || 'verde'}">${status}</em><i>${formatPercent(row[reaction.field])}</i></button>`;
  }).join('');
}

function drawParticipantsChart(timeline = []) {
  const svg = document.querySelector('#participantsChart');
  if (!svg) return;
  const width = 900;
  const height = 150;
  const pad = { left: 40, right: 16, top: 15, bottom: 27 };
  const usableWidth = width - pad.left - pad.right;
  const usableHeight = height - pad.top - pad.bottom;
  const values = timeline.map(row => Number(row.participants || 0));
  const maximum = Math.max(1, ...values);
  let markup = '';
  for (let index = 0; index <= 3; index += 1) {
    const y = pad.top + (usableHeight / 3) * index;
    const label = Math.round(maximum * (1 - index / 3));
    markup += `<line x1="${pad.left}" y1="${y}" x2="${width - pad.right}" y2="${y}" stroke="#e6e8ee"/><text x="8" y="${y + 4}" fill="#7b8294" font-size="10">${label}</text>`;
  }
  if (values.length) {
    const coordinates = values.map((value, index) => {
      const x = pad.left + usableWidth * (index / Math.max(1, values.length - 1));
      const y = pad.top + usableHeight * (1 - value / maximum);
      return { x, y, value };
    });
    const line = coordinates.map(point => `${point.x},${point.y}`).join(' ');
    const area = `${pad.left},${height - pad.bottom} ${line} ${width - pad.right},${height - pad.bottom}`;
    markup += `<polygon points="${area}" fill="rgba(88,82,196,.09)"/><polyline points="${line}" fill="none" stroke="#5852c4" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`;
    markup += coordinates.map(point => `<circle cx="${point.x}" cy="${point.y}" r="3" fill="#fff" stroke="#5852c4" stroke-width="2"><title>${point.value} participantes</title></circle>`).join('');
  } else {
    markup += '<text x="450" y="82" text-anchor="middle" fill="#7b8294" font-size="14">Sem leituras para esta reunião</text>';
  }
  svg.innerHTML = markup;
}

function renderRecommendations(timeline) {
  const container = document.querySelector('#recommendationList');
  if (!timeline.length) {
    container.innerHTML = '<div class="overview-empty">Sem leituras suficientes para gerar recomendações.</div>';
    return;
  }
  const engagement = averageMetric(timeline, 'engagedFraction');
  const boredom = averageMetric(timeline, 'boredFraction');
  const confusion = averageMetric(timeline, 'confusedFraction');
  const frustration = averageMetric(timeline, 'frustratedFraction');
  const coverage = timeline.filter(row => Number(row.participants || 0) > 0).length / timeline.length;
  const recommendations = [];
  if (engagement < .5) recommendations.push({ level: 'high', title: 'Revisar o contexto dos trechos vermelhos', text: 'Pergunte o que mudou nesses momentos: ritmo, assunto, atividade ou participação do grupo.' });
  if (confusion >= .2) recommendations.push({ level: 'medium', title: 'Verificar trechos com mais sinais de confusão', text: 'Confira se coincidem com explicações densas, mudanças de assunto ou falta de exemplos.' });
  if (boredom >= .25) recommendations.push({ level: 'medium', title: 'Verificar a dinâmica dos trechos destacados', text: 'Observe se houve fala prolongada, pouca interação ou uma atividade que pode ser ajustada.' });
  if (frustration >= .15) recommendations.push({ level: 'high', title: 'Revisar possíveis pontos de esforço', text: 'Consulte o contexto para saber se o conteúdo, a tarefa ou a dinâmica exigiu esforço maior.' });
  if (coverage < .7) recommendations.push({ level: 'neutral', title: 'Interpretar os resultados com cautela', text: 'Houve poucas janelas com participantes analisados; a leitura pode não representar a reunião inteira.' });
  if (!recommendations.length) recommendations.push({ level: 'good', title: 'Registrar o contexto dos momentos estáveis', text: 'Os indicadores variaram pouco no período. Use as anotações para guardar o que estava acontecendo.' });
  container.innerHTML = recommendations.map(item => `<article class="recommendation-item ${item.level}"><span aria-hidden="true">${item.level === 'good' ? '✓' : item.level === 'high' ? '!' : 'i'}</span><div><strong>${item.title}</strong><p>${item.text}</p></div></article>`).join('');
}

async function loadAnnotations(meetingId) {
  const canEdit = Boolean(signedInUser && currentSummary?.ownerId === signedInUser.id);
  document.querySelector('#annotationForm').hidden = !canEdit;
  document.querySelector('#annotationReadonly').hidden = canEdit;
  currentAnnotations = [];
  if (!canEdit || !dataApi) {
    renderAnnotations();
    drawSummaryChart(currentSummaryTimeline);
    return;
  }
  const { data, error } = await dataApi.listAnnotations(meetingId);
  if (!error) currentAnnotations = data || [];
  renderAnnotations(error ? 'Não foi possível carregar as anotações.' : '');
  drawSummaryChart(currentSummaryTimeline);
}

function renderAnnotations(errorMessage = '') {
  const container = document.querySelector('#annotationList');
  if (errorMessage) {
    container.innerHTML = `<div class="overview-empty">${errorMessage}</div>`;
    return;
  }
  if (!currentAnnotations.length) {
    container.innerHTML = '<div class="overview-empty">Nenhuma anotação registrada.</div>';
    return;
  }
  container.innerHTML = currentAnnotations.map(annotation => {
    const row = currentSummaryTimeline.find(item => item.startedAt === annotation.moment);
    const endRow = currentSummaryTimeline.find(item => item.startedAt === annotation.endMoment);
    const startLabel = row ? getElapsedLabel(row) : new Date(annotation.moment).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    const label = endRow && annotation.endMoment !== annotation.moment ? `${startLabel}–${getElapsedLabel(endRow)}` : startLabel;
    return `<article class="annotation-item"><b>${label}</b><p>${escapeHtml(annotation.text)}</p><button type="button" data-delete-annotation="${annotation.id}" aria-label="Excluir anotação">×</button></article>`;
  }).join('');
}

document.querySelector('#annotationForm').addEventListener('submit', async event => {
  event.preventDefault();
  const text = document.querySelector('#annotationText').value.trim();
  const moment = selectedAnnotationMoment;
  const endMoment = selectedAnnotationEnd;
  if (!text || !moment || !endMoment || !currentSummary || !signedInUser) return showToast('Escolha o intervalo e escreva a anotação.');
  const { data, error } = await dataApi.addAnnotation(signedInUser.id, currentSummary.id, moment, endMoment, text);
  if (error) return showToast('Não foi possível salvar a anotação.');
  currentAnnotations.push(data);
  currentAnnotations.sort((a, b) => new Date(a.moment) - new Date(b.moment));
  document.querySelector('#annotationText').value = '';
  renderAnnotations();
  drawSummaryChart(currentSummaryTimeline);
  showToast('Anotação salva na sua conta.');
});

document.querySelector('#annotationList').addEventListener('click', async event => {
  const button = event.target.closest('[data-delete-annotation]');
  if (!button) return;
  if (!window.confirm('Excluir esta anotação?')) return;
  const annotationId = Number(button.dataset.deleteAnnotation);
  const { error } = await dataApi.deleteAnnotation(annotationId);
  if (error) return showToast('Não foi possível excluir a anotação.');
  currentAnnotations = currentAnnotations.filter(annotation => Number(annotation.id) !== annotationId);
  renderAnnotations();
  drawSummaryChart(currentSummaryTimeline);
  showToast('Anotação removida.');
});

function safePresentationName(value = 'reuniao') {
  return String(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 70) || 'reuniao';
}

function addPresentationHeader(pptx, slide, title, subtitle = '') {
  slide.background = { color: 'F7F9FD' };
  slide.addText('MindFlowIA', {
    x: 0.65, y: 0.28, w: 2.2, h: 0.28,
    fontFace: 'Libre Franklin', fontSize: 16, bold: true, color: '243BCE', margin: 0
  });
  slide.addText(title, {
    x: 0.65, y: 0.72, w: 12, h: 0.52,
    fontFace: 'Libre Franklin', fontSize: 28, bold: true, color: '11183A', margin: 0
  });
  if (subtitle) {
    slide.addText(subtitle, {
      x: 0.65, y: 1.27, w: 12, h: 0.35,
      fontFace: 'Atkinson Hyperlegible', fontSize: 13, color: '667085', margin: 0
    });
  }
  slide.addShape(pptx.ShapeType.line, {
    x: 0.65, y: 1.72, w: 12, h: 0,
    line: { color: 'DCE2EF', width: 1 }
  });
  slide.addText('MindFlowIA', {
    x: 0.65, y: 7.15, w: 2, h: 0.2,
    fontFace: 'Libre Franklin', fontSize: 9, color: '7B8294', margin: 0
  });
}

function addPresentationMetric(slide, label, value, note, x, color) {
  slide.addText(label, {
    x, y: 2.05, w: 2.65, h: 0.25,
    fontFace: 'Atkinson Hyperlegible', fontSize: 12, color: '667085', margin: 0
  });
  slide.addText(value, {
    x, y: 2.36, w: 2.65, h: 0.55,
    fontFace: 'Roboto Mono', fontSize: 27, bold: true, color, margin: 0
  });
  slide.addText(note, {
    x, y: 2.95, w: 2.65, h: 0.28,
    fontFace: 'Atkinson Hyperlegible', fontSize: 10, color: '7B8294', margin: 0
  });
}

function presentationTimeline() {
  return filteredSummaryTimeline.length ? filteredSummaryTimeline : currentSummaryTimeline;
}

async function exportSummaryToPptx() {
  if (!currentSummary) return showToast('Selecione uma reunião antes de exportar.');
  if (!window.PptxGenJS) return showToast('O gerador de PowerPoint não carregou. Confira sua internet e tente novamente.');

  const button = document.querySelector('#exportSummaryButton');
  const originalContent = button.innerHTML;
  button.disabled = true;
  button.textContent = 'Gerando PPTX...';

  try {
    const timeline = presentationTimeline();
    const pptx = new window.PptxGenJS();
    pptx.layout = 'LAYOUT_WIDE';
    pptx.author = 'MindFlowIA';
    pptx.company = 'MindFlowIA';
    pptx.subject = 'Resumo de reunião';
    pptx.title = currentSummary.title;
    pptx.lang = 'pt-BR';
    pptx.theme = {
      headFontFace: 'Libre Franklin',
      bodyFontFace: 'Atkinson Hyperlegible',
      lang: 'pt-BR'
    };

    const dateText = currentSummary.startedAt
      ? new Date(currentSummary.startedAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })
      : 'Data não registrada';
    const engagement = timeline.length ? averageMetric(timeline, 'engagedFraction') : currentSummary.engagedFraction;
    const participants = timeline.length ? Math.max(...timeline.map(row => Number(row.participants || 0))) : currentSummary.participants;
    const activeLayout = getActiveDashboardLayout();
    const ranking = timeline.length ? getReactionRanking(timeline) : [];

    const summarySlide = pptx.addSlide();
    addPresentationHeader(pptx, summarySlide, currentSummary.title, `${dateText}   ${formatDuration(currentSummary.duration)}   Visualização: ${activeLayout.name}`);
    addPresentationMetric(summarySlide, 'Engajamento médio', formatPercent(engagement), `${timeline.length} janelas no intervalo`, 0.7, '16884F');
    addPresentationMetric(summarySlide, 'Participantes analisados', String(participants || 0), 'Maior total simultâneo', 3.75, '243BCE');
    addPresentationMetric(summarySlide, 'Alertas registrados', String(currentSummary.alerts || 0), 'Durante a reunião completa', 6.8, 'C93E50');
    addPresentationMetric(summarySlide, 'Reação predominante', ranking[0]?.label || '—', ranking[0] ? formatClockDuration(ranking[0].seconds) : 'Sem leituras', 9.85, '5B3FD6');
    summarySlide.addText('Leitura geral', {
      x: 0.7, y: 3.7, w: 3, h: 0.35,
      fontFace: 'Libre Franklin', fontSize: 18, bold: true, color: '11183A', margin: 0
    });
    summarySlide.addText(document.querySelector('#finalSummaryText').textContent, {
      x: 0.7, y: 4.18, w: 11.9, h: 1.3,
      fontFace: 'Atkinson Hyperlegible', fontSize: 18, color: '30384D',
      breakLine: false, valign: 'mid', margin: 0.05, fit: 'shrink'
    });
    summarySlide.addText('O relatório usa o intervalo atualmente selecionado no dashboard.', {
      x: 0.7, y: 6.38, w: 8.5, h: 0.3,
      fontFace: 'Atkinson Hyperlegible', fontSize: 11, italic: true, color: '7B8294', margin: 0
    });

    const chartSlide = pptx.addSlide();
    addPresentationHeader(pptx, chartSlide, 'Evolução da sessão', `${timeline.length} janelas no intervalo selecionado`);
    if (timeline.length) {
      const step = Math.max(1, Math.ceil(timeline.length / 40));
      const sampled = timeline.filter((row, index) => index % step === 0 || index === timeline.length - 1);
      const sessionStart = new Date(currentSummaryTimeline[0]?.startedAt || sampled[0].startedAt).getTime();
      const labels = sampled.map(row => formatElapsedTime(Math.max(0, Math.round((new Date(row.startedAt).getTime() - sessionStart) / 1000))));
      const series = [
        { name: 'Engajamento', field: 'engagedFraction' },
        { name: 'Tédio', field: 'boredFraction' },
        { name: 'Confusão', field: 'confusedFraction' },
        { name: 'Frustração', field: 'frustratedFraction' }
      ].map(item => ({ name: item.name, labels, values: sampled.map(row => Math.round(Number(row[item.field] || 0) * 100)) }));
      chartSlide.addChart(pptx.ChartType.line, series, {
        x: 0.72, y: 1.95, w: 11.9, h: 4.65,
        chartColors: ['1B9C5A', '4A67D8', 'E78531', 'DC4C5C'],
        showLegend: true, legendPos: 'b', legendFontFace: 'Atkinson Hyperlegible', legendFontSize: 11,
        showTitle: false, showValue: false, showCatName: false,
        catAxisLabelFontFace: 'Roboto Mono', catAxisLabelFontSize: 9,
        valAxisLabelFontFace: 'Roboto Mono', valAxisLabelFontSize: 9,
        valAxisMinVal: 0, valAxisMaxVal: 100, valAxisMajorUnit: 20,
        valAxisLabelFormatCode: '0"%"',
        showCatName: false, showValue: false,
        showBorder: false, showLine: true, lineSize: 2,
        showMarker: false
      });
    } else {
      chartSlide.addText('Esta reunião ainda não possui janelas para montar o gráfico.', {
        x: 0.8, y: 3.15, w: 11.6, h: 0.6,
        fontFace: 'Atkinson Hyperlegible', fontSize: 20, align: 'center', color: '7B8294', margin: 0
      });
    }

    const momentsSlide = pptx.addSlide();
    addPresentationHeader(pptx, momentsSlide, 'Principais momentos', 'Picos das reações e tempo de predominância');
    const definitions = [
      { label: 'Engajamento', field: 'engagedFraction', color: '16884F' },
      { label: 'Tédio', field: 'boredFraction', color: '4A67D8' },
      { label: 'Confusão', field: 'confusedFraction', color: 'D87820' },
      { label: 'Frustração', field: 'frustratedFraction', color: 'C93E50' }
    ];
    definitions.forEach((reaction, index) => {
      const peak = timeline.length
        ? timeline.reduce((best, row) => Number(row[reaction.field] || 0) > Number(best[reaction.field] || 0) ? row : best, timeline[0])
        : null;
      const duration = ranking.find(item => item.field === reaction.field)?.seconds || 0;
      const y = 2.05 + index * 0.82;
      momentsSlide.addText(reaction.label, { x: 0.75, y, w: 2.2, h: 0.32, fontFace: 'Libre Franklin', fontSize: 15, bold: true, color: reaction.color, margin: 0 });
      momentsSlide.addText(peak ? formatPercent(peak[reaction.field]) : '—', { x: 3.15, y, w: 1.2, h: 0.32, fontFace: 'Roboto Mono', fontSize: 17, bold: true, color: '11183A', margin: 0 });
      momentsSlide.addText(peak ? `pico em ${getElapsedLabel(peak)}` : 'sem leituras', { x: 4.45, y, w: 2.3, h: 0.32, fontFace: 'Atkinson Hyperlegible', fontSize: 12, color: '667085', margin: 0 });
      momentsSlide.addText(`${formatClockDuration(duration)} predominante`, { x: 7.2, y, w: 2.65, h: 0.32, fontFace: 'Roboto Mono', fontSize: 11, color: '4B556A', margin: 0 });
      momentsSlide.addShape(pptx.ShapeType.line, { x: 0.75, y: y + 0.48, w: 11.8, h: 0, line: { color: 'E4E8F1', width: 1 } });
    });
    momentsSlide.addText('Observação', { x: 0.75, y: 5.55, w: 2, h: 0.32, fontFace: 'Libre Franklin', fontSize: 15, bold: true, color: '11183A', margin: 0 });
    momentsSlide.addText('Os indicadores representam uma leitura coletiva. A interpretação final deve considerar o contexto da reunião.', {
      x: 0.75, y: 5.98, w: 11.6, h: 0.7,
      fontFace: 'Atkinson Hyperlegible', fontSize: 16, color: '30384D', margin: 0
    });

    await pptx.writeFile({ fileName: `MindFlowIA-${safePresentationName(currentSummary.title)}.pptx` });
    showToast('Apresentação PPTX baixada.');
  } catch (error) {
    console.error('Falha ao gerar PPTX:', error);
    showToast('Não foi possível gerar o PPTX. Tente novamente.');
  } finally {
    button.disabled = false;
    button.innerHTML = originalContent;
  }
}

document.querySelector('#exportSummaryButton').addEventListener('click', exportSummaryToPptx);

async function exportOverviewToPptx() {
  if (!overviewFinishedMeetings.length) return showToast('Ainda não existem reuniões concluídas para exportar.');
  if (!window.PptxGenJS) return showToast('O gerador de PowerPoint não carregou. Confira sua internet e tente novamente.');

  const button = document.querySelector('#exportOverviewButton');
  const originalContent = button.innerHTML;
  button.disabled = true;
  button.textContent = 'Gerando PPTX...';

  try {
    const selected = overviewFinishedMeetings.filter(meeting => overviewComparisonSelection.has(meeting.id));
    const meetings = selected.length >= 2 ? selected : overviewFinishedMeetings;
    const records = await getOverviewComparisonRecords(meetings);
    const metrics = overviewComparisonMetrics();
    if (!metrics.length) return showToast('Escolha pelo menos um grupo de métricas antes de exportar.');
    const pptx = new window.PptxGenJS();
    pptx.layout = 'LAYOUT_WIDE';
    pptx.author = 'MindFlowIA';
    pptx.company = 'MindFlowIA';
    pptx.subject = 'Dashboard geral e comparação de reuniões';
    pptx.title = 'Dashboard geral MindFlowIA';
    pptx.lang = 'pt-BR';
    pptx.theme = { headFontFace: 'Libre Franklin', bodyFontFace: 'Atkinson Hyperlegible', lang: 'pt-BR' };

    const engagementValues = overviewFinishedMeetings.map(meeting => meeting.engagedFraction).filter(Number.isFinite);
    const engagementAverage = engagementValues.length
      ? engagementValues.reduce((sum, value) => sum + value, 0) / engagementValues.length
      : null;
    const participants = overviewFinishedMeetings.reduce((sum, meeting) => sum + Number(meeting.participants || 0), 0);
    const alerts = overviewFinishedMeetings.reduce((sum, meeting) => sum + Number(meeting.alerts || 0), 0);
    const bestMeeting = [...overviewFinishedMeetings]
      .filter(meeting => Number.isFinite(meeting.engagedFraction))
      .sort((a, b) => Number(b.engagedFraction) - Number(a.engagedFraction))[0];
    const mostAlerts = [...overviewFinishedMeetings].sort((a, b) => Number(b.alerts || 0) - Number(a.alerts || 0))[0];

    const summarySlide = pptx.addSlide();
    addPresentationHeader(pptx, summarySlide, 'Dashboard geral', `${overviewFinishedMeetings.length} reuniões concluídas   Visualização: ${getActiveOverviewDashboardLayout().name}`);
    addPresentationMetric(summarySlide, 'Reuniões concluídas', String(overviewFinishedMeetings.length), 'Vinculadas à conta', 0.7, '243BCE');
    addPresentationMetric(summarySlide, 'Engajamento médio', formatPercent(engagementAverage), 'Média entre as sessões', 3.75, '16884F');
    addPresentationMetric(summarySlide, 'Participantes analisados', String(participants), 'Soma das reuniões', 6.8, '5B3FD6');
    addPresentationMetric(summarySlide, 'Alertas registrados', String(alerts), 'Soma das ocorrências', 9.85, 'C93E50');
    summarySlide.addText('Destaques', { x: 0.7, y: 3.65, w: 2, h: 0.35, fontFace: 'Libre Franklin', fontSize: 19, bold: true, color: '11183A', margin: 0 });
    summarySlide.addText(bestMeeting ? `Maior engajamento: ${bestMeeting.title} (${formatPercent(bestMeeting.engagedFraction)})` : 'Maior engajamento: sem dados', {
      x: 0.7, y: 4.2, w: 11.8, h: 0.48, fontFace: 'Atkinson Hyperlegible', fontSize: 19, color: '30384D', margin: 0
    });
    summarySlide.addText(mostAlerts ? `Mais alertas: ${mostAlerts.title} (${mostAlerts.alerts})` : 'Alertas: sem dados', {
      x: 0.7, y: 4.85, w: 11.8, h: 0.48, fontFace: 'Atkinson Hyperlegible', fontSize: 19, color: '30384D', margin: 0
    });
    summarySlide.addText('As próximas páginas usam as reuniões e os grupos de métricas selecionados no dashboard.', {
      x: 0.7, y: 6.25, w: 11.8, h: 0.35, fontFace: 'Atkinson Hyperlegible', fontSize: 12, italic: true, color: '7B8294', margin: 0
    });

    const chunks = [];
    for (let index = 0; index < records.length; index += 4) chunks.push(records.slice(index, index + 4));
    const metricChunks = [];
    for (let index = 0; index < metrics.length; index += 7) metricChunks.push(metrics.slice(index, index + 7));
    chunks.forEach((chunk, chunkIndex) => {
      metricChunks.forEach((metricChunk, metricIndex) => {
        const slide = pptx.addSlide();
        const groupLabel = chunks.length > 1 ? `Reuniões ${chunkIndex * 4 + 1} a ${chunkIndex * 4 + chunk.length}` : `${records.length} reuniões selecionadas`;
        const metricLabel = metricChunks.length > 1 ? `Métricas ${metricIndex * 7 + 1} a ${metricIndex * 7 + metricChunk.length}` : 'Métricas selecionadas';
        addPresentationHeader(pptx, slide, 'Comparação de reuniões', `${groupLabel}   ${metricLabel}`);
        const rows = [
          ['Métrica', ...chunk.map(meeting => meeting.title)],
          ...metricChunk.map(metric => [metric.label, ...chunk.map(meeting => metric.format(meeting[metric.field]))])
        ];
        slide.addTable(rows, {
          x: 0.55, y: 1.9, w: 12.25, h: 4.75,
          border: { type: 'solid', color: 'DCE2EF', pt: 1 },
          fill: { color: 'FFFFFF' }, color: '30384D',
          fontFace: 'Atkinson Hyperlegible', fontSize: 13,
          margin: 0.08, rowH: 0.52,
          bold: false, valign: 'mid',
          colW: [1.85, ...chunk.map(() => 2.55)]
        });
      });
    });

    await pptx.writeFile({ fileName: 'MindFlowIA-dashboard-geral.pptx' });
    showToast('Dashboard geral exportado em PPTX.');
  } catch (error) {
    console.error('Falha ao gerar o PPTX geral:', error);
    showToast('Não foi possível gerar o PPTX do dashboard geral.');
  } finally {
    button.disabled = false;
    button.innerHTML = originalContent;
  }
}

document.querySelector('#exportOverviewButton').addEventListener('click', exportOverviewToPptx);

function renderFinalSummary(timeline) {
  const paragraph = document.querySelector('#finalSummaryText');
  if (!timeline.length) {
    paragraph.textContent = 'Ainda não há dados suficientes para gerar o resumo.';
    return;
  }
  const engagement = timeline.reduce((sum, row) => sum + Number(row.engagedFraction || 0), 0) / timeline.length;
  const dominant = getReactionRanking(timeline)[0];
  const engagementPeak = timeline.reduce((best, row) => Number(row.engagedFraction || 0) > Number(best.engagedFraction || 0) ? row : best, timeline[0]);
  const participants = Math.max(...timeline.map(row => Number(row.participants || 0)));
  paragraph.textContent = `No período selecionado, ${timeline.length} janelas foram analisadas, com até ${participants} participantes. A fração média de engajamento foi ${formatPercent(engagement)} e ${dominant.label.toLowerCase()} foi a reação predominante por mais tempo (${formatClockDuration(dominant.seconds)}). O pico de engajamento chegou a ${formatPercent(engagementPeak.engagedFraction)} em ${getElapsedLabel(engagementPeak)}.`;
}

function getTimelineRowDuration(row, nextRow) {
  const start = new Date(row.startedAt).getTime();
  const end = row.endedAt ? new Date(row.endedAt).getTime() : NaN;
  const next = nextRow ? new Date(nextRow.startedAt).getTime() : NaN;
  const milliseconds = Number.isFinite(end) && end > start ? end - start : Number.isFinite(next) && next > start ? next - start : 30000;
  return Math.max(1, Math.round(milliseconds / 1000));
}

function formatElapsedTime(totalSeconds) {
  const seconds = Math.max(0, Math.round(Number(totalSeconds) || 0));
  return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}

function formatClockDuration(totalSeconds) {
  const seconds = Math.max(0, Math.round(Number(totalSeconds) || 0));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const rest = seconds % 60;
  return hours ? `${hours}h ${String(minutes).padStart(2, '0')}min` : `${minutes}min ${String(rest).padStart(2, '0')}s`;
}

function chartSeries(timeline) {
  const chartValue = (row, intensityField, fractionField) => {
    const intensity = Number(row[intensityField]);
    return Number.isFinite(intensity) ? intensity : Number(row[fractionField] || 0);
  };
  return [
    { label: 'Engajamento', color: '#1b9c5a', values: timeline.map(row => chartValue(row, 'engagementIntensity', 'engagedFraction') * 100) },
    { label: 'Tédio', color: '#4a67d8', values: timeline.map(row => chartValue(row, 'boredomIntensity', 'boredFraction') * 100) },
    { label: 'Confusão', color: '#e78531', values: timeline.map(row => chartValue(row, 'confusionIntensity', 'confusedFraction') * 100) },
    { label: 'Frustração', color: '#dc4c5c', values: timeline.map(row => chartValue(row, 'frustrationIntensity', 'frustratedFraction') * 100) }
  ];
}

function alertsForTimeline(timeline = []) {
  if (!timeline.length || !currentSummaryAlerts.length) return [];
  const start = new Date(timeline[0].startedAt).getTime();
  const last = timeline[timeline.length - 1];
  const end = last.endedAt ? new Date(last.endedAt).getTime() : new Date(last.startedAt).getTime() + 30_000;
  return currentSummaryAlerts.filter(alert => {
    const timestamp = new Date(alert.timestamp).getTime();
    return timestamp >= start && timestamp < end;
  });
}

function alertForTimelineRow(row) {
  const start = new Date(row.startedAt).getTime();
  const end = row.endedAt ? new Date(row.endedAt).getTime() : start + 30_000;
  return currentSummaryAlerts.find(alert => {
    const timestamp = new Date(alert.timestamp).getTime();
    return timestamp >= start && timestamp < end;
  }) || null;
}

function annotationForTimelineRow(row) {
  const rowStart = new Date(row.startedAt).getTime();
  const rowEnd = row.endedAt ? new Date(row.endedAt).getTime() : rowStart + 30_000;
  return currentAnnotations.find(annotation => {
    const annotationStart = new Date(annotation.moment).getTime();
    const rawEnd = new Date(annotation.endMoment || annotation.moment).getTime();
    const annotationEnd = Math.max(annotationStart + 1, rawEnd);
    return annotationStart < rowEnd && annotationEnd >= rowStart;
  }) || null;
}

// SVG leve, mas agora com quatro reações, grade vertical e leitura no hover.
function drawSummaryChart(timeline = []) {
  const svg = document.querySelector('#summaryChart');
  if (!svg) return;
  chartTimeline = timeline;
  const width = 900;
  const height = 240;
  const pad = { left: 46, right: 18, top: 15, bottom: 32 };
  const usableWidth = width - pad.left - pad.right;
  const usableHeight = height - pad.top - pad.bottom;
  const series = chartSeries(timeline);
  let markup = '';
  for (let level = 0; level <= 4; level += 1) {
    const y = pad.top + (usableHeight / 4) * level;
    const value = 100 - level * 25;
    markup += `<line x1="${pad.left}" y1="${y}" x2="${width - pad.right}" y2="${y}" stroke="#e6e8ee" stroke-width="1"/><text x="8" y="${y + 4}" fill="#7b8294" font-size="10">${value}%</text>`;
  }
  const sessionStart = currentSummaryTimeline.length ? new Date(currentSummaryTimeline[0].startedAt).getTime() : 0;
  const axisLabels = Array.from({ length: 6 }, (_, index) => {
    if (!timeline.length) return { label: '00:00', index };
    const rowIndex = Math.round((timeline.length - 1) * (index / 5));
    const secondsAtPoint = Math.max(0, Math.round((new Date(timeline[rowIndex].startedAt).getTime() - sessionStart) / 1000));
    return { label: formatElapsedTime(secondsAtPoint), index };
  });
  axisLabels.forEach(({ label, index }, _, labels) => {
    const x = pad.left + usableWidth * (index / (labels.length - 1));
    markup += `<line x1="${x}" y1="${pad.top}" x2="${x}" y2="${height - pad.bottom}" stroke="#eceef3" stroke-width="1" stroke-dasharray="3 5"/>`;
    markup += `<text x="${x}" y="${height - 9}" text-anchor="middle" fill="#7b8294" font-size="10">${label}</text>`;
  });
  if (timeline.length && currentAnnotations.length) {
    const visibleStart = new Date(timeline[0].startedAt).getTime();
    const lastRow = timeline[timeline.length - 1];
    const visibleEnd = lastRow.endedAt ? new Date(lastRow.endedAt).getTime() : new Date(lastRow.startedAt).getTime() + 30_000;
    const visibleDuration = Math.max(1, visibleEnd - visibleStart);
    currentAnnotations.forEach(annotation => {
      const annotationStart = new Date(annotation.moment).getTime();
      const annotationEnd = new Date(annotation.endMoment || annotation.moment).getTime();
      if (!Number.isFinite(annotationStart) || !Number.isFinite(annotationEnd) || annotationEnd < visibleStart || annotationStart > visibleEnd) return;
      const clippedStart = Math.max(visibleStart, annotationStart);
      const clippedEnd = Math.min(visibleEnd, Math.max(annotationStart + 1, annotationEnd));
      const x = pad.left + usableWidth * ((clippedStart - visibleStart) / visibleDuration);
      const naturalEndX = pad.left + usableWidth * ((clippedEnd - visibleStart) / visibleDuration);
      const width = Math.max(7, naturalEndX - x);
      markup += `<g class="chart-annotation-marker"><rect x="${x}" y="${pad.top + 1}" width="${width}" height="${usableHeight - 2}" rx="4" fill="#5b5fc7" opacity=".08"/><line x1="${x}" y1="${pad.top}" x2="${x}" y2="${height - pad.bottom}" stroke="#5b5fc7" stroke-width="1" stroke-dasharray="2 4" opacity=".48"/><circle cx="${x}" cy="${pad.top + 7}" r="3" fill="#5b5fc7" opacity=".72"/><title>Anotação: ${escapeHtml(annotation.text)}</title></g>`;
    });
  }
  series.forEach(item => {
    if (!item.values.length) return;
    const coordinates = item.values.map((value, index) => {
      const divisor = Math.max(1, item.values.length - 1);
      const x = pad.left + usableWidth * (index / divisor);
      const safeValue = Math.max(0, Math.min(100, Number(value) || 0));
      const y = pad.top + usableHeight * (1 - safeValue / 100);
      return { x, y };
    });
    const points = coordinates.map(point => `${point.x},${point.y}`).join(' ');
    markup += `<polyline points="${points}" fill="none" stroke="${item.color}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`;
    if (timeline.length <= 2) {
      markup += coordinates.map(point => `<circle cx="${point.x}" cy="${point.y}" r="5" fill="#fff" stroke="${item.color}" stroke-width="3"/>`).join('');
    }
  });
  timeline.forEach((row, index) => {
    const alert = alertForTimelineRow(row);
    if (!alert) return;
    const x = pad.left + usableWidth * (index / Math.max(1, timeline.length - 1));
    const critical = alert.color === 'vermelho';
    const color = critical ? '#dc4c5c' : '#d99b1b';
    const label = critical ? 'Momento para revisão' : 'Alerta de atenção';
    markup += `<g class="chart-alert-marker" data-alert-index="${index}"><line x1="${x}" y1="${pad.top}" x2="${x}" y2="${height - pad.bottom}" stroke="${color}" stroke-width="1.5" stroke-dasharray="5 5" opacity=".72"/><path d="M ${x} ${pad.top + 2} l 6 6 -6 6 -6 -6 z" fill="${color}"><title>${label} · ${escapeHtml(alert.reason || 'mudança no semáforo')}</title></path></g>`;
  });
  if (!timeline.length) {
    markup += `<text x="450" y="125" text-anchor="middle" fill="#7b8294" font-size="14">Sem leituras para esta reunião</text>`;
  }
  markup += '<g id="chartSelectionLayer"></g><g id="chartHoverLayer"></g>';
  svg.innerHTML = markup;
  updateChartSelectionOverlay();
}

function chartSelectionIndices() {
  const maxIndex = Math.max(0, currentSummaryTimeline.length - 1);
  const startIndex = Math.max(0, Math.min(maxIndex, Number(document.querySelector('#timelineStartFilter').value || 0)));
  const endIndex = Math.max(startIndex, Math.min(maxIndex, Number(document.querySelector('#timelineEndFilter').value || maxIndex)));
  return { startIndex, endIndex, maxIndex };
}

function updateChartSelectionHint(message = '') {
  const hint = document.querySelector('#chartSelectionHint');
  if (!hint) return;
  if (message) {
    hint.textContent = message;
    hint.dataset.state = 'pending';
    return;
  }
  if (chartRangeClickAnchor !== null && currentSummaryTimeline[chartRangeClickAnchor]) {
    hint.textContent = `Primeiro ponto: ${getElapsedLabel(currentSummaryTimeline[chartRangeClickAnchor])}. Clique novamente para fechar o intervalo.`;
    hint.dataset.state = 'pending';
    return;
  }
  hint.textContent = 'Clique duas vezes para criar um intervalo. Depois, arraste as bordas ou mova a faixa inteira.';
  delete hint.dataset.state;
}

function updateChartSelectionOverlay() {
  const svg = document.querySelector('#summaryChart');
  const layer = svg?.querySelector('#chartSelectionLayer');
  if (!layer) return;
  if (!currentSummaryTimeline.length) {
    layer.innerHTML = '';
    return;
  }
  const { startIndex, endIndex, maxIndex } = chartSelectionIndices();
  const pad = { left: 46, right: 18, top: 15, bottom: 32 };
  const width = 900;
  const height = 240;
  const usableWidth = width - pad.left - pad.right;
  const bottom = height - pad.bottom;
  const divisor = Math.max(1, maxIndex);
  const startX = pad.left + usableWidth * (startIndex / divisor);
  const endX = pad.left + usableWidth * (endIndex / divisor);
  const selectionWidth = Math.max(3, endX - startX);
  const leftMaskWidth = Math.max(0, startX - pad.left);
  const rightMaskX = Math.max(startX + selectionWidth, endX);
  const rightMaskWidth = Math.max(0, width - pad.right - rightMaskX);
  const startLabel = currentSummaryTimeline[startIndex] ? getElapsedLabel(currentSummaryTimeline[startIndex]) : '00:00';
  const endLabel = currentSummaryTimeline[endIndex] ? getElapsedLabel(currentSummaryTimeline[endIndex]) : '00:00';
  const intervalLabel = `${startLabel}–${endLabel}`;
  const badgeWidth = 80;
  const badgeX = Math.max(pad.left, Math.min(width - pad.right - badgeWidth, (startX + endX - badgeWidth) / 2));
  const anchorMarkup = chartRangeClickAnchor !== null && currentSummaryTimeline[chartRangeClickAnchor]
    ? (() => {
        const anchorX = pad.left + usableWidth * (chartRangeClickAnchor / divisor);
        return `<line x1="${anchorX}" y1="${pad.top}" x2="${anchorX}" y2="${bottom}" stroke="#2f6fad" stroke-width="2" stroke-dasharray="4 4"/><rect x="${Math.max(pad.left, Math.min(width - pad.right - 58, anchorX - 29))}" y="${pad.top + 3}" width="58" height="18" rx="9" fill="#2f6fad"/><text x="${Math.max(pad.left + 29, Math.min(width - pad.right - 29, anchorX))}" y="${pad.top + 16}" text-anchor="middle" fill="#fff" font-size="9" font-weight="700">1º ponto</text>`;
      })()
    : '';
  layer.innerHTML = `<g pointer-events="none">
    ${leftMaskWidth ? `<rect x="${pad.left}" y="${pad.top}" width="${leftMaskWidth}" height="${bottom - pad.top}" fill="#fff" opacity=".5"/>` : ''}
    ${rightMaskWidth ? `<rect x="${rightMaskX}" y="${pad.top}" width="${rightMaskWidth}" height="${bottom - pad.top}" fill="#fff" opacity=".5"/>` : ''}
    <rect x="${startX}" y="${pad.top}" width="${selectionWidth}" height="${bottom - pad.top}" rx="5" fill="#509bdd" opacity=".09" stroke="#3575bf" stroke-width="1.5"/>
    <line x1="${startX}" y1="${pad.top}" x2="${startX}" y2="${bottom}" stroke="#3575bf" stroke-width="2.5"/>
    <line x1="${endX}" y1="${pad.top}" x2="${endX}" y2="${bottom}" stroke="#3575bf" stroke-width="2.5"/>
    <circle cx="${startX}" cy="${bottom}" r="6" fill="#3575bf" stroke="#fff" stroke-width="2"/>
    <circle cx="${endX}" cy="${bottom}" r="6" fill="#3575bf" stroke="#fff" stroke-width="2"/>
    <rect x="${badgeX}" y="${pad.top + 3}" width="${badgeWidth}" height="16" rx="8" fill="#edf6ff" stroke="#b8d4ef"/>
    <text x="${badgeX + badgeWidth / 2}" y="${pad.top + 14}" text-anchor="middle" fill="#285f99" font-size="8" font-weight="700">${intervalLabel}</text>
    ${anchorMarkup}
  </g>`;
}

function chartIndexFromPointerEvent(event) {
  const svg = event.currentTarget;
  const rect = svg.getBoundingClientRect();
  const pad = { left: 46, right: 18 };
  const svgX = ((event.clientX - rect.left) / Math.max(1, rect.width)) * 900;
  const ratio = Math.max(0, Math.min(1, (svgX - pad.left) / (900 - pad.left - pad.right)));
  return Math.round(ratio * Math.max(0, currentSummaryTimeline.length - 1));
}

function previewChartRange(startIndex, endIndex) {
  const maxIndex = Math.max(0, currentSummaryTimeline.length - 1);
  const safeStart = Math.max(0, Math.min(maxIndex, startIndex));
  const safeEnd = Math.max(safeStart, Math.min(maxIndex, endIndex));
  document.querySelector('#timelineStartFilter').value = String(safeStart);
  document.querySelector('#timelineEndFilter').value = String(safeEnd);
  selectedAnnotationMoment = currentSummaryTimeline[safeStart]?.startedAt || null;
  selectedAnnotationEnd = currentSummaryTimeline[safeEnd]?.startedAt || null;
  updateAnnotationSelectedLabel();
  updateChartSelectionOverlay();
  const startRow = currentSummaryTimeline[safeStart];
  const endRow = currentSummaryTimeline[safeEnd];
  if (startRow && endRow) {
    document.querySelector('#summaryRangeLabel').textContent = `${getElapsedLabel(startRow)} até ${getElapsedLabel(endRow)} · solte para aplicar`;
  }
}

document.querySelector('#timelineStartFilter').addEventListener('change', () => {
  chartRangeClickAnchor = null;
  updateSummaryRange('start');
});
document.querySelector('#timelineEndFilter').addEventListener('change', () => {
  chartRangeClickAnchor = null;
  updateSummaryRange('end');
});
document.querySelector('#resetSummaryRange').addEventListener('click', () => {
  const start = document.querySelector('#timelineStartFilter');
  const end = document.querySelector('#timelineEndFilter');
  start.value = '0';
  end.value = String(Math.max(0, currentSummaryTimeline.length - 1));
  chartRangeClickAnchor = null;
  updateSummaryRange();
  showToast('Resumo restaurado para a reunião inteira.');
});

function hideSummaryFocusNotice() {
  document.querySelector('#summaryFocusNotice').hidden = true;
}

function showSummaryFocus(action) {
  if (action === 'alerts') {
    focusSummaryAlerts();
    return;
  }
  const startIndex = Number(document.querySelector('#timelineStartFilter').value || 0);
  const endIndex = Number(document.querySelector('#timelineEndFilter').value || Math.max(0, currentSummaryTimeline.length - 1));
  const source = currentSummaryTimeline.slice(startIndex, endIndex + 1);
  if (!source.length) return showToast('Esta reunião ainda não tem leituras para destacar.');
  const scorer = action === 'engagement'
    ? row => Number(row.engagedFraction || 0)
    : row => attentionScore(row);
  const highlights = [...source].sort((a, b) => scorer(b) - scorer(a)).slice(0, 2).sort((a, b) => new Date(a.startedAt) - new Date(b.startedAt));
  filteredSummaryTimeline = highlights;
  timelineTableExpanded = false;
  renderSummaryDataset(highlights);
  document.querySelector('#summaryFocusText').textContent = action === 'engagement'
    ? 'Mostrando os dois maiores picos de engajamento do intervalo.'
    : 'Mostrando os dois momentos que mais pediram atenção.';
  document.querySelector('#summaryFocusNotice').hidden = false;
}

function focusSummaryAlerts() {
  if (!currentSummaryTimeline.length) return showToast('Esta reunião ainda não tem leituras para revisar.');
  const source = filteredSummaryTimeline.length ? filteredSummaryTimeline : currentSummaryTimeline;
  const intervalAlerts = alertsForTimeline(source);
  if (!intervalAlerts.length) return showToast('Nenhuma mudança para atenção ou revisão foi registrada no intervalo escolhido.');
  const chart = document.querySelector('[data-dashboard-widget="chart"]');
  chart.hidden = false;
  drawSummaryChart(currentSummaryTimeline);
  document.querySelector('#summaryFocusText').textContent = `${intervalAlerts.length} alerta${intervalAlerts.length === 1 ? '' : 's'} marcado${intervalAlerts.length === 1 ? '' : 's'} no intervalo escolhido.`;
  document.querySelector('#summaryFocusNotice').hidden = false;
  chart.classList.add('dashboard-widget-new-highlight');
  chart.scrollIntoView({ behavior: 'smooth', block: 'center' });
  window.setTimeout(() => chart.classList.remove('dashboard-widget-new-highlight'), 1900);
}

document.querySelectorAll('[data-summary-action]').forEach(card => {
  const activate = () => showSummaryFocus(card.dataset.summaryAction);
  card.addEventListener('click', event => {
    if (event.target.closest('.summary-widget-drag-handle, .summary-widget-resize')) return;
    activate();
  });
  card.addEventListener('keydown', event => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    event.preventDefault();
    activate();
  });
});

document.querySelector('#clearSummaryFocus').addEventListener('click', () => updateSummaryRange());

document.querySelector('#attentionMoments').addEventListener('click', event => {
  const button = event.target.closest('[data-focus-time]');
  if (!button) return;
  const row = currentSummaryTimeline.find(item => item.startedAt === button.dataset.focusTime);
  if (!row) return;
  filteredSummaryTimeline = [row];
  renderSummaryDataset([row]);
  document.querySelector('#summaryFocusText').textContent = `Mostrando a janela de ${getElapsedLabel(row)}.`;
  document.querySelector('#summaryFocusNotice').hidden = false;
});
document.querySelector('#toggleTimelineTable').addEventListener('click', () => {
  timelineTableExpanded = !timelineTableExpanded;
  renderTimelineTable(filteredSummaryTimeline);
});

document.querySelector('#summaryChart').addEventListener('pointerdown', event => {
  if (!currentSummaryTimeline.length || event.button !== 0) return;
  const svg = event.currentTarget;
  const rect = svg.getBoundingClientRect();
  const { startIndex, endIndex, maxIndex } = chartSelectionIndices();
  const usableClientWidth = rect.width * ((900 - 46 - 18) / 900);
  const chartClientLeft = rect.left + rect.width * (46 / 900);
  const divisor = Math.max(1, maxIndex);
  const startClientX = chartClientLeft + usableClientWidth * (startIndex / divisor);
  const endClientX = chartClientLeft + usableClientWidth * (endIndex / divisor);
  const pointerIndex = chartIndexFromPointerEvent(event);
  const startDistance = Math.abs(event.clientX - startClientX);
  const endDistance = Math.abs(event.clientX - endClientX);
  let mode = 'new';
  if (Math.min(startDistance, endDistance) <= 13) mode = startDistance <= endDistance ? 'start' : 'end';
  else if (pointerIndex >= startIndex && pointerIndex <= endIndex) mode = 'move';
  chartRangePointerState = {
    pointerId: event.pointerId,
    downClientX: event.clientX,
    downIndex: pointerIndex,
    initialStart: startIndex,
    initialEnd: endIndex,
    mode,
    active: false
  };
  svg.setPointerCapture?.(event.pointerId);
  event.preventDefault();
});

document.querySelector('#summaryChart').addEventListener('pointermove', event => {
  const state = chartRangePointerState;
  if (!state || state.pointerId !== event.pointerId) return;
  if (!state.active && Math.abs(event.clientX - state.downClientX) < 5) return;
  state.active = true;
  chartRangeClickAnchor = null;
  const currentIndex = chartIndexFromPointerEvent(event);
  let startIndex = state.initialStart;
  let endIndex = state.initialEnd;
  if (state.mode === 'start') startIndex = Math.min(currentIndex, endIndex);
  else if (state.mode === 'end') endIndex = Math.max(currentIndex, startIndex);
  else if (state.mode === 'move') {
    const width = state.initialEnd - state.initialStart;
    const maxIndex = Math.max(0, currentSummaryTimeline.length - 1);
    startIndex = Math.max(0, Math.min(maxIndex - width, state.initialStart + currentIndex - state.downIndex));
    endIndex = startIndex + width;
  } else {
    startIndex = Math.min(state.downIndex, currentIndex);
    endIndex = Math.max(state.downIndex, currentIndex);
  }
  previewChartRange(startIndex, endIndex);
  updateChartSelectionHint('Solte para aplicar este intervalo ao resumo e à anotação.');
  event.currentTarget.style.cursor = state.mode === 'move' ? 'grabbing' : 'ew-resize';
  document.querySelector('#chartTooltip').hidden = true;
  const hoverLayer = event.currentTarget.querySelector('#chartHoverLayer');
  if (hoverLayer) hoverLayer.innerHTML = '';
  event.preventDefault();
});

function finishChartRangePointer(event, cancelled = false) {
  const state = chartRangePointerState;
  if (!state || state.pointerId !== event.pointerId) return;
  const svg = event.currentTarget;
  if (state.active) {
    if (cancelled) {
      document.querySelector('#timelineStartFilter').value = String(state.initialStart);
      document.querySelector('#timelineEndFilter').value = String(state.initialEnd);
    }
    updateSummaryRange();
  } else if (!cancelled) {
    const index = chartIndexFromPointerEvent(event);
    if (chartRangeClickAnchor === null) {
      chartRangeClickAnchor = index;
      updateChartSelectionHint();
      updateChartSelectionOverlay();
    } else {
      document.querySelector('#timelineStartFilter').value = String(Math.min(chartRangeClickAnchor, index));
      document.querySelector('#timelineEndFilter').value = String(Math.max(chartRangeClickAnchor, index));
      chartRangeClickAnchor = null;
      updateSummaryRange();
      showToast('Intervalo aplicado à análise e à próxima anotação.');
    }
  }
  if (svg.hasPointerCapture?.(event.pointerId)) svg.releasePointerCapture(event.pointerId);
  svg.style.cursor = '';
  chartRangePointerState = null;
}

document.querySelector('#summaryChart').addEventListener('pointerup', event => finishChartRangePointer(event));
document.querySelector('#summaryChart').addEventListener('pointercancel', event => finishChartRangePointer(event, true));

document.querySelector('#summaryChart').addEventListener('mousemove', event => {
  if (!chartTimeline.length || chartRangePointerState?.active) return;
  const svg = event.currentTarget;
  const rect = svg.getBoundingClientRect();
  const width = 900;
  const height = 240;
  const pad = { left: 46, right: 18, top: 15, bottom: 32 };
  const svgX = ((event.clientX - rect.left) / rect.width) * width;
  const ratio = Math.max(0, Math.min(1, (svgX - pad.left) / (width - pad.left - pad.right)));
  const index = Math.round(ratio * Math.max(0, chartTimeline.length - 1));
  const row = chartTimeline[index];
  const x = pad.left + (width - pad.left - pad.right) * (index / Math.max(1, chartTimeline.length - 1));
  const layer = svg.querySelector('#chartHoverLayer');
  const currentSeries = chartSeries(chartTimeline);
  const dots = currentSeries.map(series => {
    const value = Math.max(0, Math.min(100, Number(series.values[index]) || 0));
    const y = pad.top + (height - pad.top - pad.bottom) * (1 - value / 100);
    return `<circle cx="${x}" cy="${y}" r="4" fill="#fff" stroke="${series.color}" stroke-width="2"/>`;
  }).join('');
  layer.innerHTML = `<line x1="${x}" y1="${pad.top}" x2="${x}" y2="${height - pad.bottom}" stroke="#596174" stroke-width="1"/>${dots}`;

  const tooltip = document.querySelector('#chartTooltip');
  const sessionStart = new Date(currentSummaryTimeline[0]?.startedAt || row.startedAt).getTime();
  const seconds = Math.max(0, Math.round((new Date(row.startedAt).getTime() - sessionStart) / 1000));
  const alert = alertForTimelineRow(row);
  const annotation = annotationForTimelineRow(row);
  tooltip.innerHTML = `<strong>${formatElapsedTime(seconds)} · ${row.participants} analisados</strong><small>Intensidade estimada dos indicadores</small>${currentSeries.map(series => `<span>${series.label} <b>${Math.round(series.values[index])}%</b></span>`).join('')}${alert ? `<em class="chart-alert-tooltip ${alert.color === 'vermelho' ? 'critical' : ''}">${alert.color === 'vermelho' ? 'Momento para revisão' : 'Alerta de atenção'} · ${escapeHtml(alert.reason || 'mudança no semáforo')}</em>` : ''}${annotation ? `<em class="chart-annotation-tooltip">Anotação · ${escapeHtml(annotation.text)}</em>` : ''}`;
  tooltip.hidden = false;
  const left = Math.max(4, Math.min(rect.width - tooltip.offsetWidth - 4, (x / width) * rect.width + 10));
  tooltip.style.left = `${left}px`;
  tooltip.style.top = '32px';
});

document.querySelector('#summaryChart').addEventListener('mouseleave', event => {
  document.querySelector('#chartTooltip').hidden = true;
  const layer = event.currentTarget.querySelector('#chartHoverLayer');
  if (layer) layer.innerHTML = '';
});

function overviewDashboardStorageKey() {
  return `mindflow-overview-layouts-${signedInUser?.id || 'local'}`;
}

function expandLegacyOverviewWidgetIds(items = []) {
  const cardIds = ['meetingsCard', 'engagementCard', 'participantsCard', 'alertsCard'];
  const expanded = items.flatMap(id => id === 'metrics' ? cardIds : [id]);
  return [...new Set(expanded)];
}

function completeOverviewDashboardOrder(preferred = []) {
  const safePreferred = expandLegacyOverviewWidgetIds(preferred).filter(id => id in OVERVIEW_DASHBOARD_WIDGETS);
  return [...safePreferred, ...Object.keys(OVERVIEW_DASHBOARD_WIDGETS).filter(id => !safePreferred.includes(id))];
}

function normalizeResizableWidgetSize(requested, fallback) {
  const legacyColumns = typeof requested === 'string' ? LEGACY_OVERVIEW_SIZE_COLUMNS[requested] : null;
  const requestedColumns = requested == null
    ? NaN
    : typeof requested === 'object' ? Number(requested.columns) : Number(requested);
  const columns = Number.isFinite(legacyColumns)
    ? legacyColumns
    : Number.isFinite(requestedColumns) ? requestedColumns : fallback.columns;
  const requestedHeight = typeof requested === 'object' && requested !== null ? Number(requested.height) : NaN;
  return {
    columns: Math.max(2, Math.min(12, Math.round(columns))),
    height: Number.isFinite(requestedHeight) && requestedHeight > 0
      ? Math.max(110, Math.min(900, Math.round(requestedHeight)))
      : null
  };
}

function normalizeOverviewDashboardSizes(sizes = {}) {
  return Object.fromEntries(Object.keys(OVERVIEW_DASHBOARD_WIDGETS).map(id => {
    return [id, normalizeResizableWidgetSize(sizes?.[id], OVERVIEW_DASHBOARD_DEFAULT_SIZES[id])];
  }));
}

function builtInOverviewDashboardLayouts() {
  return [
    {
      id: 'overview-normal',
      name: 'Normal',
      description: 'Panorama das reuniões da conta.',
      order: ['meetingsCard', 'engagementCard', 'participantsCard', 'alertsCard', 'alerts', 'engagement', 'traffic', 'ranking', 'volume', 'comparison'],
      visible: DEFAULT_OVERVIEW_DASHBOARD_VISIBLE,
      sizes: normalizeOverviewDashboardSizes()
    },
    {
      id: 'overview-alerts',
      name: 'Foco em alertas',
      description: 'Destaca as reuniões que mais pediram atenção.',
      order: ['alertsCard', 'meetingsCard', 'engagementCard', 'participantsCard', 'alerts', 'traffic', 'comparison', 'ranking', 'engagement', 'volume'],
      visible: ['alertsCard', 'meetingsCard', 'engagementCard', 'participantsCard', 'alerts', 'traffic', 'comparison'],
      sizes: normalizeOverviewDashboardSizes({ traffic: { columns: 6 }, alerts: { columns: 12 } })
    },
    {
      id: 'overview-comparison',
      name: 'Comparação',
      description: 'Coloca lado a lado resultados, participação, semáforo e volume de dados.',
      order: ['comparison', 'meetingsCard', 'engagementCard', 'participantsCard', 'alertsCard', 'ranking', 'traffic', 'volume', 'engagement', 'alerts'],
      visible: ['comparison', 'meetingsCard', 'engagementCard', 'participantsCard', 'alertsCard', 'ranking', 'traffic', 'volume'],
      sizes: normalizeOverviewDashboardSizes({ comparison: { columns: 12 }, ranking: { columns: 6 }, traffic: { columns: 6 }, volume: { columns: 12 } })
    }
  ];
}

function isBuiltInOverviewDashboard(layoutId) {
  return builtInOverviewDashboardLayouts().some(layout => layout.id === layoutId);
}

function normalizeOverviewDashboardLayout(layout) {
  const validOrder = Array.isArray(layout.order) ? expandLegacyOverviewWidgetIds(layout.order).filter(id => id in OVERVIEW_DASHBOARD_WIDGETS) : [];
  const visible = Array.isArray(layout.visible)
    ? expandLegacyOverviewWidgetIds(layout.visible).filter(id => id in OVERVIEW_DASHBOARD_WIDGETS)
    : DEFAULT_OVERVIEW_DASHBOARD_VISIBLE;
  return {
    id: String(layout.id),
    name: String(layout.name),
    order: completeOverviewDashboardOrder(validOrder),
    visible,
    sizes: normalizeOverviewDashboardSizes(layout.sizes)
  };
}

async function loadOverviewDashboardLayouts() {
  try {
    const saved = JSON.parse(localStorage.getItem(overviewDashboardStorageKey()) || '[]');
    overviewDashboardLayouts = Array.isArray(saved) ? saved.filter(layout => layout?.id?.startsWith('overview-layout-')).map(normalizeOverviewDashboardLayout) : [];
  } catch {
    overviewDashboardLayouts = [];
  }
  if (dataApi && signedInUser) {
    const { data, error } = await dataApi.listDashboardLayouts(signedInUser.id);
    if (!error) {
      const accountLayouts = (data || [])
        .filter(layout => layout?.id?.startsWith('overview-layout-'))
        .map(normalizeOverviewDashboardLayout);
      const merged = new Map(overviewDashboardLayouts.map(layout => [layout.id, layout]));
      accountLayouts.forEach(layout => merged.set(layout.id, layout));
      overviewDashboardLayouts = [...merged.values()];
      localStorage.setItem(overviewDashboardStorageKey(), JSON.stringify(overviewDashboardLayouts));
    }
  }
  if (!isBuiltInOverviewDashboard(activeOverviewDashboardLayoutId) && !overviewDashboardLayouts.some(layout => layout.id === activeOverviewDashboardLayoutId)) {
    activeOverviewDashboardLayoutId = 'overview-normal';
  }
  refreshOverviewDashboardLayoutSelect();
  applyOverviewDashboardLayout(activeOverviewDashboardLayoutId);
}

function refreshOverviewDashboardLayoutSelect() {
  const select = document.querySelector('#overviewDashboardViewSelect');
  const readyOptions = builtInOverviewDashboardLayouts().map(layout => `<option value="${layout.id}" title="${escapeHtml(layout.description)}">${layout.name}</option>`).join('');
  const customOptions = overviewDashboardLayouts.length
    ? `<optgroup label="Minhas visualizações">${overviewDashboardLayouts.map(layout => `<option value="${escapeHtml(layout.id)}">${escapeHtml(layout.name)}</option>`).join('')}</optgroup>`
    : '';
  select.innerHTML = `<optgroup label="Modelos prontos">${readyOptions}</optgroup>${customOptions}`;
  select.value = activeOverviewDashboardLayoutId;
}

function getActiveOverviewDashboardLayout() {
  return builtInOverviewDashboardLayouts().find(layout => layout.id === activeOverviewDashboardLayoutId)
    || overviewDashboardLayouts.find(layout => layout.id === activeOverviewDashboardLayoutId)
    || builtInOverviewDashboardLayouts()[0];
}

function renderOverviewDashboardLayout(layout) {
  const container = document.querySelector('#overviewWidgets');
  const widgets = new Map([...container.querySelectorAll('[data-overview-widget]')].map(widget => [widget.dataset.overviewWidget, widget]));
  const sizes = normalizeOverviewDashboardSizes(layout.sizes);
  completeOverviewDashboardOrder(layout.order).filter(id => widgets.has(id)).forEach(id => container.appendChild(widgets.get(id)));
  widgets.forEach((widget, id) => {
    widget.hidden = !layout.visible.includes(id);
    const size = sizes[id];
    widget.dataset.overviewColumns = String(size.columns);
    widget.style.setProperty('--overview-span', size.columns);
    widget.style.height = size.height ? `${size.height}px` : '';
    if (size.height) widget.dataset.widgetHeight = String(size.height);
    else delete widget.dataset.widgetHeight;
  });
}

function applyOverviewDashboardLayout(layoutId) {
  activeOverviewDashboardLayoutId = layoutId;
  const layout = getActiveOverviewDashboardLayout();
  renderOverviewDashboardLayout(layout);
  document.querySelector('#overviewDashboardViewSelect').value = layoutId;
  document.querySelector('#overviewDashboardViewSelect').title = layout.description || 'Visualização personalizada do dashboard geral.';
  document.querySelector('#overviewDashboardViewDescription').textContent = layout.description || 'Visualização personalizada do dashboard geral.';
  document.querySelector('#editOverviewViewButton').hidden = isBuiltInOverviewDashboard(layoutId);
}

function previewOverviewDashboardEditor() {
  renderOverviewDashboardLayout({ order: editingOverviewDashboardOrder, visible: [...editingOverviewDashboardVisible], sizes: editingOverviewDashboardSizes });
}

function setOverviewDashboardDragMode(enabled) {
  const container = document.querySelector('#overviewWidgets');
  container.classList.toggle('overview-arranging', enabled);
  container.querySelectorAll('[data-overview-widget]').forEach(widget => {
    let handle = widget.querySelector(':scope > .overview-widget-drag-handle');
    if (!handle) {
      handle = document.createElement('button');
      handle.type = 'button';
      handle.className = 'overview-widget-drag-handle';
      handle.draggable = true;
      handle.innerHTML = '<span aria-hidden="true">⋮⋮</span> Arrastar';
      handle.setAttribute('aria-label', `Arrastar bloco ${OVERVIEW_DASHBOARD_WIDGETS[widget.dataset.overviewWidget] || ''}`);
      widget.prepend(handle);
    }
    let resize = widget.querySelector(':scope > .overview-widget-resize');
    if (!resize) {
      resize = document.createElement('button');
      resize.type = 'button';
      resize.className = 'overview-widget-resize';
      resize.innerHTML = '<span aria-hidden="true">↘</span>';
      resize.title = 'Arraste para ajustar a largura e a altura';
      resize.setAttribute('aria-label', `Arrastar para ajustar o tamanho de ${OVERVIEW_DASHBOARD_WIDGETS[widget.dataset.overviewWidget] || ''}`);
      widget.prepend(resize);
    }
    handle.draggable = enabled;
  });
}

function openOverviewDashboardEditor(mode = 'create') {
  const layout = getActiveOverviewDashboardLayout();
  overviewDashboardEditorMode = mode === 'edit' && !isBuiltInOverviewDashboard(layout.id) ? 'edit' : 'create';
  editingOverviewDashboardOrder = [...layout.order];
  editingOverviewDashboardVisible = new Set(layout.visible);
  editingOverviewDashboardSizes = normalizeOverviewDashboardSizes(layout.sizes);
  document.querySelector('#overviewDashboardLayoutName').value = overviewDashboardEditorMode === 'edit' ? layout.name : '';
  document.querySelector('#overviewDashboardEditorTitle').textContent = overviewDashboardEditorMode === 'edit' ? 'Personalizar visualização' : 'Criar visualização personalizada';
  document.querySelector('#deleteOverviewViewButton').hidden = overviewDashboardEditorMode !== 'edit';
  document.querySelector('#overviewDashboardEditor').hidden = false;
  document.querySelector('#overviewDashboardEditorFeedback').textContent = 'Marque um bloco: ele será mostrado e destacado imediatamente no painel abaixo.';
  setOverviewDashboardDragMode(true);
  renderOverviewDashboardWidgetControls();
  document.querySelector('#overviewDashboardLayoutName').focus();
}

function closeOverviewDashboardEditor() {
  document.querySelector('#overviewDashboardEditor').hidden = true;
  setOverviewDashboardDragMode(false);
  applyOverviewDashboardLayout(activeOverviewDashboardLayoutId);
}

function renderOverviewDashboardWidgetControls() {
  document.querySelector('#overviewDashboardWidgetControls').innerHTML = editingOverviewDashboardOrder.map((id, index) => `
    <div class="dashboard-widget-control" draggable="true" data-overview-widget-id="${id}" title="${OVERVIEW_DASHBOARD_WIDGET_DESCRIPTIONS[id]}">
      <span class="dashboard-drag-handle" aria-hidden="true" title="Arraste para ordenar">⋮⋮</span>
      <input type="checkbox" data-overview-dashboard-visible="${id}" ${editingOverviewDashboardVisible.has(id) ? 'checked' : ''} aria-label="Exibir ${OVERVIEW_DASHBOARD_WIDGETS[id]}">
      <span class="dashboard-widget-name">${OVERVIEW_DASHBOARD_WIDGETS[id]}</span>
      <div class="dashboard-order-buttons"><button type="button" data-overview-dashboard-move="up" data-overview-widget-id="${id}" ${index === 0 ? 'disabled' : ''} aria-label="Mover ${OVERVIEW_DASHBOARD_WIDGETS[id]} para cima">↑</button>
      <button type="button" data-overview-dashboard-move="down" data-overview-widget-id="${id}" ${index === editingOverviewDashboardOrder.length - 1 ? 'disabled' : ''} aria-label="Mover ${OVERVIEW_DASHBOARD_WIDGETS[id]} para baixo">↓</button></div>
    </div>`).join('');
}

document.querySelector('#overviewWidgets').addEventListener('pointerdown', event => {
  const resize = event.target.closest('.overview-widget-resize');
  if (!resize || !document.querySelector('#overviewWidgets').classList.contains('overview-arranging')) return;
  event.preventDefault();
  event.stopPropagation();
  const widget = resize.closest('[data-overview-widget]');
  const id = widget.dataset.overviewWidget;
  const container = document.querySelector('#overviewWidgets');
  overviewResizeState = {
    id,
    widget,
    pointerId: event.pointerId,
    startX: event.clientX,
    startColumns: editingOverviewDashboardSizes[id]?.columns || OVERVIEW_DASHBOARD_DEFAULT_SIZES[id].columns,
    startHeight: widget.getBoundingClientRect().height,
    startY: event.clientY,
    columnWidth: container.getBoundingClientRect().width / 12
  };
  widget.classList.add('is-resizing');
  container.classList.add('overview-resizing');
  resize.setPointerCapture?.(event.pointerId);
});

document.addEventListener('pointermove', event => {
  if (!overviewResizeState || event.pointerId !== overviewResizeState.pointerId) return;
  event.preventDefault();
  const deltaColumns = Math.round((event.clientX - overviewResizeState.startX) / overviewResizeState.columnWidth);
  const columns = Math.max(2, Math.min(12, overviewResizeState.startColumns + deltaColumns));
  const height = Math.max(110, Math.min(900, Math.round((overviewResizeState.startHeight + event.clientY - overviewResizeState.startY) / 10) * 10));
  editingOverviewDashboardSizes[overviewResizeState.id] = { columns, height };
  overviewResizeState.widget.dataset.overviewColumns = String(columns);
  overviewResizeState.widget.style.setProperty('--overview-span', columns);
  overviewResizeState.widget.style.height = `${height}px`;
  overviewResizeState.widget.dataset.widgetHeight = String(height);
});

function finishOverviewResize(event) {
  if (!overviewResizeState || (event?.pointerId != null && event.pointerId !== overviewResizeState.pointerId)) return;
  overviewResizeState.widget.classList.remove('is-resizing');
  document.querySelector('#overviewWidgets').classList.remove('overview-resizing');
  overviewResizeState = null;
}

document.addEventListener('pointerup', finishOverviewResize);
document.addEventListener('pointercancel', finishOverviewResize);

document.querySelector('#overviewWidgets').addEventListener('dragstart', event => {
  const handle = event.target.closest('.overview-widget-drag-handle');
  if (!handle || !document.querySelector('#overviewWidgets').classList.contains('overview-arranging')) return;
  const widget = handle.closest('[data-overview-widget]');
  draggedOverviewDashboardWidgetId = widget?.dataset.overviewWidget || null;
  if (!draggedOverviewDashboardWidgetId) return;
  widget.classList.add('dragging-dashboard-widget');
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', draggedOverviewDashboardWidgetId);
});

document.querySelector('#overviewWidgets').addEventListener('dragover', event => {
  if (!draggedOverviewDashboardWidgetId) return;
  const target = event.target.closest('[data-overview-widget]');
  if (!target || target.dataset.overviewWidget === draggedOverviewDashboardWidgetId || target.hidden) return;
  event.preventDefault();
  document.querySelectorAll('#overviewWidgets .overview-dashboard-drop-target').forEach(widget => widget.classList.remove('overview-dashboard-drop-target'));
  target.classList.add('overview-dashboard-drop-target');
});

document.querySelector('#overviewWidgets').addEventListener('drop', event => {
  const target = event.target.closest('[data-overview-widget]');
  if (!target || !draggedOverviewDashboardWidgetId) return;
  event.preventDefault();
  const sourceIndex = editingOverviewDashboardOrder.indexOf(draggedOverviewDashboardWidgetId);
  const targetIndex = editingOverviewDashboardOrder.indexOf(target.dataset.overviewWidget);
  if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return;
  editingOverviewDashboardOrder.splice(sourceIndex, 1);
  editingOverviewDashboardOrder.splice(targetIndex, 0, draggedOverviewDashboardWidgetId);
  draggedOverviewDashboardWidgetId = null;
  previewOverviewDashboardEditor();
  renderOverviewDashboardWidgetControls();
  document.querySelectorAll('#overviewWidgets .dragging-dashboard-widget, #overviewWidgets .overview-dashboard-drop-target').forEach(widget => widget.classList.remove('dragging-dashboard-widget', 'overview-dashboard-drop-target'));
});

document.querySelector('#overviewWidgets').addEventListener('dragend', () => {
  draggedOverviewDashboardWidgetId = null;
  document.querySelectorAll('#overviewWidgets .dragging-dashboard-widget, #overviewWidgets .overview-dashboard-drop-target').forEach(widget => widget.classList.remove('dragging-dashboard-widget', 'overview-dashboard-drop-target'));
});

document.querySelector('#overviewDashboardViewSelect').addEventListener('change', event => {
  applyOverviewDashboardLayout(event.target.value);
  closeOverviewDashboardEditor();
});
document.querySelector('#editOverviewViewButton').addEventListener('click', () => openOverviewDashboardEditor('edit'));
document.querySelector('#openOverviewCustomization').addEventListener('click', () => openOverviewDashboardEditor('create'));
document.querySelector('#closeOverviewDashboardEditor').addEventListener('click', closeOverviewDashboardEditor);
document.querySelector('#cancelOverviewDashboardEdit').addEventListener('click', closeOverviewDashboardEditor);

document.querySelector('#overviewDashboardWidgetControls').addEventListener('change', event => {
  if (event.target.matches('[data-overview-dashboard-visible]')) {
    const id = event.target.dataset.overviewDashboardVisible;
    if (event.target.checked) editingOverviewDashboardVisible.add(id);
    else editingOverviewDashboardVisible.delete(id);
    previewOverviewDashboardEditor();
    revealDashboardWidgetChange('overview', id, event.target.checked);
  }
});

document.querySelector('#overviewDashboardWidgetControls').addEventListener('click', event => {
  const button = event.target.closest('[data-overview-dashboard-move]');
  if (!button) return;
  const index = editingOverviewDashboardOrder.indexOf(button.dataset.overviewWidgetId);
  const targetIndex = button.dataset.overviewDashboardMove === 'up' ? index - 1 : index + 1;
  if (index < 0 || targetIndex < 0 || targetIndex >= editingOverviewDashboardOrder.length) return;
  [editingOverviewDashboardOrder[index], editingOverviewDashboardOrder[targetIndex]] = [editingOverviewDashboardOrder[targetIndex], editingOverviewDashboardOrder[index]];
  renderOverviewDashboardWidgetControls();
  previewOverviewDashboardEditor();
});

document.querySelector('#overviewDashboardWidgetControls').addEventListener('dragstart', event => {
  const item = event.target.closest('.dashboard-widget-control[data-overview-widget-id]');
  if (!item) return;
  draggedOverviewDashboardWidgetId = item.dataset.overviewWidgetId;
  item.classList.add('dragging');
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', draggedOverviewDashboardWidgetId);
});

document.querySelector('#overviewDashboardWidgetControls').addEventListener('dragover', event => {
  const item = event.target.closest('.dashboard-widget-control[data-overview-widget-id]');
  if (!item || item.dataset.overviewWidgetId === draggedOverviewDashboardWidgetId) return;
  event.preventDefault();
  document.querySelectorAll('#overviewDashboardWidgetControls .drag-over').forEach(control => control.classList.remove('drag-over'));
  item.classList.add('drag-over');
});

document.querySelector('#overviewDashboardWidgetControls').addEventListener('drop', event => {
  const target = event.target.closest('.dashboard-widget-control[data-overview-widget-id]');
  if (!target || !draggedOverviewDashboardWidgetId) return;
  event.preventDefault();
  const sourceIndex = editingOverviewDashboardOrder.indexOf(draggedOverviewDashboardWidgetId);
  const targetIndex = editingOverviewDashboardOrder.indexOf(target.dataset.overviewWidgetId);
  if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return;
  editingOverviewDashboardOrder.splice(sourceIndex, 1);
  editingOverviewDashboardOrder.splice(targetIndex, 0, draggedOverviewDashboardWidgetId);
  draggedOverviewDashboardWidgetId = null;
  renderOverviewDashboardWidgetControls();
  previewOverviewDashboardEditor();
});

document.querySelector('#overviewDashboardWidgetControls').addEventListener('dragend', () => {
  draggedOverviewDashboardWidgetId = null;
  document.querySelectorAll('#overviewDashboardWidgetControls .dragging, #overviewDashboardWidgetControls .drag-over').forEach(control => control.classList.remove('dragging', 'drag-over'));
});

document.querySelector('#saveOverviewViewButton').addEventListener('click', async () => {
  const name = document.querySelector('#overviewDashboardLayoutName').value.trim();
  if (!name) return showToast('Dê um nome para a visualização geral.');
  if (!editingOverviewDashboardVisible.size) return showToast('Escolha pelo menos um bloco para mostrar.');
  const current = getActiveOverviewDashboardLayout();
  const id = overviewDashboardEditorMode === 'edit' && !isBuiltInOverviewDashboard(current.id) ? current.id : `overview-layout-${Date.now()}`;
  const layout = { id, name, order: [...editingOverviewDashboardOrder], visible: [...editingOverviewDashboardVisible], sizes: { ...editingOverviewDashboardSizes } };
  const existingIndex = overviewDashboardLayouts.findIndex(item => item.id === id);
  if (existingIndex >= 0) overviewDashboardLayouts[existingIndex] = layout;
  else overviewDashboardLayouts.push(layout);
  localStorage.setItem(overviewDashboardStorageKey(), JSON.stringify(overviewDashboardLayouts));
  let syncError = false;
  if (dataApi && signedInUser) {
    const { error } = await dataApi.saveDashboardLayout(signedInUser.id, layout);
    syncError = Boolean(error);
  }
  activeOverviewDashboardLayoutId = id;
  refreshOverviewDashboardLayoutSelect();
  applyOverviewDashboardLayout(id);
  closeOverviewDashboardEditor();
  showToast(syncError ? 'A visualização ficou neste dispositivo, mas não foi sincronizada.' : `Visualização “${name}” salva na sua conta.`);
});

document.querySelector('#deleteOverviewViewButton').addEventListener('click', async () => {
  if (isBuiltInOverviewDashboard(activeOverviewDashboardLayoutId)) return;
  const layout = getActiveOverviewDashboardLayout();
  if (!window.confirm(`Excluir a visualização “${layout.name}”?`)) return;
  if (dataApi && signedInUser) {
    const { error } = await dataApi.deleteDashboardLayout(signedInUser.id, activeOverviewDashboardLayoutId);
    if (error) return showToast('Não foi possível excluir a visualização da conta.');
  }
  overviewDashboardLayouts = overviewDashboardLayouts.filter(item => item.id !== activeOverviewDashboardLayoutId);
  localStorage.setItem(overviewDashboardStorageKey(), JSON.stringify(overviewDashboardLayouts));
  activeOverviewDashboardLayoutId = 'overview-normal';
  refreshOverviewDashboardLayoutSelect();
  applyOverviewDashboardLayout(activeOverviewDashboardLayoutId);
  closeOverviewDashboardEditor();
  showToast('Visualização geral excluída.');
});

function dashboardStorageKey() {
  return `mindflow-dashboard-layouts-${signedInUser?.id || 'local'}`;
}

function expandLegacyDashboardWidgetIds(items = []) {
  const cardIds = ['engagementCard', 'participantsCard', 'windowsCard', 'alertsCard'];
  return [...new Set(items.flatMap(id => id === 'metrics' ? cardIds : [id]))];
}

function completeDashboardOrder(preferred = []) {
  const safePreferred = expandLegacyDashboardWidgetIds(preferred).filter(id => id in DASHBOARD_WIDGETS);
  return [...safePreferred, ...Object.keys(DASHBOARD_WIDGETS).filter(id => !safePreferred.includes(id))];
}

function normalizeDashboardSizes(sizes = {}) {
  return Object.fromEntries(Object.keys(DASHBOARD_WIDGETS).map(id => [
    id,
    normalizeResizableWidgetSize(sizes?.[id], DASHBOARD_DEFAULT_SIZES[id])
  ]));
}

function builtInDashboardLayouts() {
  return [
    {
      id: 'normal',
      name: 'Normal',
      description: 'Visão equilibrada com os principais resultados da reunião.',
      order: Object.keys(DASHBOARD_WIDGETS),
      visible: DEFAULT_DASHBOARD_VISIBLE,
      sizes: normalizeDashboardSizes()
    },
    {
      id: 'executive',
      name: 'Resumo executivo',
      description: 'Foco em decisão rápida: panorama, alertas, picos e conclusão.',
      order: completeDashboardOrder(['metrics', 'traffic', 'peaks', 'attention', 'recommendations', 'finalSummary']),
      visible: expandLegacyDashboardWidgetIds(['metrics', 'traffic', 'peaks', 'attention', 'recommendations', 'finalSummary']),
      sizes: normalizeDashboardSizes()
    },
    {
      id: 'analytical',
      name: 'Análise detalhada',
      description: 'Foco em investigação: evolução, comparações, participação e leituras.',
      order: completeDashboardOrder(['chart', 'averages', 'heatmap', 'comparison', 'participantsChart', 'quality', 'attention', 'table', 'finalSummary']),
      visible: ['chart', 'averages', 'heatmap', 'comparison', 'participantsChart', 'quality', 'attention', 'table', 'finalSummary'],
      sizes: normalizeDashboardSizes()
    }
  ];
}

function isBuiltInDashboard(layoutId) {
  return builtInDashboardLayouts().some(layout => layout.id === layoutId);
}

function normalDashboardLayout() {
  return builtInDashboardLayouts()[0];
}

function normalizeDashboardLayout(layout) {
  const validOrder = Array.isArray(layout.order) ? expandLegacyDashboardWidgetIds(layout.order).filter(id => id in DASHBOARD_WIDGETS) : [];
  return {
    id: String(layout.id),
    name: String(layout.name),
    order: completeDashboardOrder(validOrder),
    visible: Array.isArray(layout.visible) ? expandLegacyDashboardWidgetIds(layout.visible).filter(id => id in DASHBOARD_WIDGETS) : DEFAULT_DASHBOARD_VISIBLE,
    sizes: normalizeDashboardSizes(layout.sizes)
  };
}

async function loadDashboardLayouts() {
  try {
    const saved = JSON.parse(localStorage.getItem(dashboardStorageKey()) || '[]');
    dashboardLayouts = Array.isArray(saved) ? saved.filter(layout => layout?.id && layout?.name).map(normalizeDashboardLayout) : [];
  } catch {
    dashboardLayouts = [];
  }
  if (dataApi && signedInUser) {
    const { data, error } = await dataApi.listDashboardLayouts(signedInUser.id);
    if (!error) {
      const accountLayouts = (data || [])
        .filter(layout => layout?.id && layout?.name && !layout.id.startsWith('overview-layout-'))
        .map(normalizeDashboardLayout);
      const merged = new Map(dashboardLayouts.map(layout => [layout.id, layout]));
      accountLayouts.forEach(layout => merged.set(layout.id, layout));
      dashboardLayouts = [...merged.values()];
      localStorage.setItem(dashboardStorageKey(), JSON.stringify(dashboardLayouts));
    }
  }
  if (!isBuiltInDashboard(activeDashboardLayoutId) && !dashboardLayouts.some(layout => layout.id === activeDashboardLayoutId)) {
    activeDashboardLayoutId = 'normal';
  }
  refreshDashboardLayoutSelect();
  applyDashboardLayout(activeDashboardLayoutId);
}

function refreshDashboardLayoutSelect() {
  const select = document.querySelector('#dashboardViewSelect');
  const readyOptions = builtInDashboardLayouts().map(layout => `<option value="${layout.id}" title="${escapeHtml(layout.description)}">${layout.name}</option>`).join('');
  const customOptions = dashboardLayouts.length
    ? `<optgroup label="Minhas visualizações">${dashboardLayouts.map(layout => `<option value="${escapeHtml(layout.id)}">${escapeHtml(layout.name)}</option>`).join('')}</optgroup>`
    : '';
  select.innerHTML = `<optgroup label="Modelos prontos">${readyOptions}</optgroup>${customOptions}`;
  select.value = activeDashboardLayoutId;
  document.querySelector('#deleteDashboardViewButton').hidden = isBuiltInDashboard(activeDashboardLayoutId);
}

function getActiveDashboardLayout() {
  return builtInDashboardLayouts().find(layout => layout.id === activeDashboardLayoutId)
    || dashboardLayouts.find(layout => layout.id === activeDashboardLayoutId)
    || normalDashboardLayout();
}

function renderDashboardLayout(layout) {
  const container = document.querySelector('#summaryWidgets');
  const widgets = new Map([...container.querySelectorAll('[data-dashboard-widget]')].map(widget => [widget.dataset.dashboardWidget, widget]));
  const safeOrder = completeDashboardOrder(layout.order).filter(id => widgets.has(id));
  const sizes = normalizeDashboardSizes(layout.sizes);
  safeOrder.forEach(id => container.appendChild(widgets.get(id)));
  widgets.forEach((widget, id) => {
    widget.hidden = !layout.visible.includes(id);
    const size = sizes[id];
    widget.dataset.dashboardColumns = String(size.columns);
    widget.style.setProperty('--dashboard-span', size.columns);
    widget.style.height = size.height ? `${size.height}px` : '';
    if (size.height) widget.dataset.widgetHeight = String(size.height);
    else delete widget.dataset.widgetHeight;
  });
}

function applyDashboardLayout(layoutId) {
  activeDashboardLayoutId = layoutId;
  const layout = getActiveDashboardLayout();
  renderDashboardLayout(layout);
  document.querySelector('#dashboardViewSelect').value = activeDashboardLayoutId;
  document.querySelector('#dashboardViewSelect').title = layout.description || 'Visualização personalizada para esta reunião.';
  document.querySelector('#dashboardViewDescription').textContent = layout.description || 'Visualização personalizada para esta reunião.';
  document.querySelector('#deleteDashboardViewButton').hidden = isBuiltInDashboard(activeDashboardLayoutId);
}

function previewDashboardEditor() {
  renderDashboardLayout({ order: editingDashboardOrder, visible: [...editingDashboardVisible], sizes: editingDashboardSizes });
}

function setDashboardDragMode(enabled) {
  const container = document.querySelector('#summaryWidgets');
  container.classList.toggle('summary-arranging', enabled);
  container.querySelectorAll('[data-dashboard-widget]').forEach(widget => {
    let handle = widget.querySelector(':scope > .summary-widget-drag-handle');
    if (!handle) {
      handle = document.createElement('button');
      handle.type = 'button';
      handle.className = 'summary-widget-drag-handle';
      handle.draggable = true;
      handle.innerHTML = '<span aria-hidden="true">⋮⋮</span> Arrastar';
      handle.setAttribute('aria-label', `Arrastar bloco ${DASHBOARD_WIDGETS[widget.dataset.dashboardWidget] || ''}`);
      widget.prepend(handle);
    }
    let resize = widget.querySelector(':scope > .summary-widget-resize');
    if (!resize) {
      resize = document.createElement('button');
      resize.type = 'button';
      resize.className = 'summary-widget-resize';
      resize.innerHTML = '<span aria-hidden="true">↘</span>';
      resize.title = 'Arraste para ajustar a largura e a altura';
      resize.setAttribute('aria-label', `Arrastar para ajustar o tamanho de ${DASHBOARD_WIDGETS[widget.dataset.dashboardWidget] || ''}`);
      widget.prepend(resize);
    }
    handle.draggable = enabled;
  });
}

function openDashboardEditor(mode = 'create') {
  const layout = getActiveDashboardLayout();
  dashboardEditorMode = mode === 'edit' && !isBuiltInDashboard(layout.id) ? 'edit' : 'create';
  editingDashboardOrder = [...layout.order];
  editingDashboardVisible = new Set(layout.visible);
  editingDashboardSizes = normalizeDashboardSizes(layout.sizes);
  document.querySelector('#dashboardLayoutName').value = dashboardEditorMode === 'edit' ? layout.name : '';
  document.querySelector('#dashboardEditorTitle').textContent = dashboardEditorMode === 'edit' ? 'Organizar visualização salva' : 'Organizar dashboard';
  document.querySelector('#deleteDashboardViewButton').hidden = dashboardEditorMode !== 'edit';
  document.querySelector('#dashboardEditor').hidden = false;
  document.querySelector('#dashboardEditorFeedback').textContent = 'Marque um bloco: ele será mostrado e destacado imediatamente no painel abaixo.';
  setDashboardDragMode(true);
  renderDashboardWidgetControls();
  document.querySelector('#dashboardLayoutName').focus();
}

function closeDashboardEditor() {
  document.querySelector('#dashboardEditor').hidden = true;
  setDashboardDragMode(false);
  applyDashboardLayout(activeDashboardLayoutId);
}

function renderDashboardWidgetControls() {
  document.querySelector('#dashboardWidgetControls').innerHTML = editingDashboardOrder.map((id, index) => `
    <div class="dashboard-widget-control" draggable="true" data-widget-id="${id}" title="${DASHBOARD_WIDGET_DESCRIPTIONS[id]}">
      <span class="dashboard-drag-handle" aria-hidden="true" title="Arraste para ordenar">⋮⋮</span>
      <input type="checkbox" data-dashboard-visible="${id}" ${editingDashboardVisible.has(id) ? 'checked' : ''} aria-label="Exibir ${DASHBOARD_WIDGETS[id]}">
      <span>${DASHBOARD_WIDGETS[id]}</span>
      <div class="dashboard-order-buttons"><button type="button" data-dashboard-move="up" data-widget-id="${id}" ${index === 0 ? 'disabled' : ''} aria-label="Mover ${DASHBOARD_WIDGETS[id]} para cima">↑</button>
      <button type="button" data-dashboard-move="down" data-widget-id="${id}" ${index === editingDashboardOrder.length - 1 ? 'disabled' : ''} aria-label="Mover ${DASHBOARD_WIDGETS[id]} para baixo">↓</button></div>
    </div>`).join('');
}

document.querySelector('#summaryWidgets').addEventListener('pointerdown', event => {
  const resize = event.target.closest('.summary-widget-resize');
  if (!resize || !document.querySelector('#summaryWidgets').classList.contains('summary-arranging')) return;
  event.preventDefault();
  event.stopPropagation();
  const widget = resize.closest('[data-dashboard-widget]');
  const id = widget.dataset.dashboardWidget;
  const container = document.querySelector('#summaryWidgets');
  summaryResizeState = {
    id,
    widget,
    pointerId: event.pointerId,
    startX: event.clientX,
    startY: event.clientY,
    startColumns: editingDashboardSizes[id]?.columns || DASHBOARD_DEFAULT_SIZES[id].columns,
    startHeight: widget.getBoundingClientRect().height,
    columnWidth: container.getBoundingClientRect().width / 12
  };
  widget.classList.add('is-resizing');
  container.classList.add('summary-resizing');
  resize.setPointerCapture?.(event.pointerId);
});

document.addEventListener('pointermove', event => {
  if (!summaryResizeState || event.pointerId !== summaryResizeState.pointerId) return;
  event.preventDefault();
  const deltaColumns = Math.round((event.clientX - summaryResizeState.startX) / summaryResizeState.columnWidth);
  const columns = Math.max(2, Math.min(12, summaryResizeState.startColumns + deltaColumns));
  const height = Math.max(110, Math.min(900, Math.round((summaryResizeState.startHeight + event.clientY - summaryResizeState.startY) / 10) * 10));
  editingDashboardSizes[summaryResizeState.id] = { columns, height };
  summaryResizeState.widget.dataset.dashboardColumns = String(columns);
  summaryResizeState.widget.style.setProperty('--dashboard-span', columns);
  summaryResizeState.widget.style.height = `${height}px`;
  summaryResizeState.widget.dataset.widgetHeight = String(height);
});

function finishSummaryResize(event) {
  if (!summaryResizeState || (event?.pointerId != null && event.pointerId !== summaryResizeState.pointerId)) return;
  summaryResizeState.widget.classList.remove('is-resizing');
  document.querySelector('#summaryWidgets').classList.remove('summary-resizing');
  summaryResizeState = null;
}

document.addEventListener('pointerup', finishSummaryResize);
document.addEventListener('pointercancel', finishSummaryResize);

document.querySelector('#summaryWidgets').addEventListener('dragstart', event => {
  const handle = event.target.closest('.summary-widget-drag-handle');
  if (!handle || !document.querySelector('#summaryWidgets').classList.contains('summary-arranging')) return;
  const widget = handle.closest('[data-dashboard-widget]');
  draggedDashboardWidgetId = widget?.dataset.dashboardWidget || null;
  if (!draggedDashboardWidgetId) return;
  widget.classList.add('dragging-dashboard-widget');
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', draggedDashboardWidgetId);
});

document.querySelector('#summaryWidgets').addEventListener('dragover', event => {
  if (!draggedDashboardWidgetId) return;
  const target = event.target.closest('[data-dashboard-widget]');
  if (!target || target.dataset.dashboardWidget === draggedDashboardWidgetId || target.hidden) return;
  event.preventDefault();
  document.querySelectorAll('#summaryWidgets .summary-dashboard-drop-target').forEach(widget => widget.classList.remove('summary-dashboard-drop-target'));
  target.classList.add('summary-dashboard-drop-target');
});

document.querySelector('#summaryWidgets').addEventListener('drop', event => {
  const target = event.target.closest('[data-dashboard-widget]');
  if (!target || !draggedDashboardWidgetId) return;
  event.preventDefault();
  const sourceIndex = editingDashboardOrder.indexOf(draggedDashboardWidgetId);
  const targetIndex = editingDashboardOrder.indexOf(target.dataset.dashboardWidget);
  if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return;
  editingDashboardOrder.splice(sourceIndex, 1);
  editingDashboardOrder.splice(targetIndex, 0, draggedDashboardWidgetId);
  draggedDashboardWidgetId = null;
  previewDashboardEditor();
  renderDashboardWidgetControls();
  document.querySelectorAll('#summaryWidgets .dragging-dashboard-widget, #summaryWidgets .summary-dashboard-drop-target').forEach(widget => widget.classList.remove('dragging-dashboard-widget', 'summary-dashboard-drop-target'));
});

document.querySelector('#summaryWidgets').addEventListener('dragend', () => {
  draggedDashboardWidgetId = null;
  document.querySelectorAll('#summaryWidgets .dragging-dashboard-widget, #summaryWidgets .summary-dashboard-drop-target').forEach(widget => widget.classList.remove('dragging-dashboard-widget', 'summary-dashboard-drop-target'));
});

document.querySelector('#dashboardViewSelect').addEventListener('change', event => {
  applyDashboardLayout(event.target.value);
  closeDashboardEditor();
});
document.querySelector('#editDashboardButton').addEventListener('click', () => openDashboardEditor('edit'));
document.querySelector('#closeDashboardEditor').addEventListener('click', closeDashboardEditor);
document.querySelector('#cancelDashboardEdit').addEventListener('click', closeDashboardEditor);

document.querySelector('#dashboardWidgetControls').addEventListener('change', event => {
  if (!event.target.matches('[data-dashboard-visible]')) return;
  const id = event.target.dataset.dashboardVisible;
  if (event.target.checked) editingDashboardVisible.add(id);
  else editingDashboardVisible.delete(id);
  previewDashboardEditor();
  revealDashboardWidgetChange('summary', id, event.target.checked);
});

document.querySelector('#dashboardWidgetControls').addEventListener('click', event => {
  const button = event.target.closest('[data-dashboard-move]');
  if (!button) return;
  const index = editingDashboardOrder.indexOf(button.dataset.widgetId);
  const targetIndex = button.dataset.dashboardMove === 'up' ? index - 1 : index + 1;
  if (index < 0 || targetIndex < 0 || targetIndex >= editingDashboardOrder.length) return;
  [editingDashboardOrder[index], editingDashboardOrder[targetIndex]] = [editingDashboardOrder[targetIndex], editingDashboardOrder[index]];
  renderDashboardWidgetControls();
  previewDashboardEditor();
});

// Arrastar é o jeito rápido; as setas continuam ali para teclado e telas de toque.
document.querySelector('#dashboardWidgetControls').addEventListener('dragstart', event => {
  const item = event.target.closest('.dashboard-widget-control');
  if (!item) return;
  draggedDashboardWidgetId = item.dataset.widgetId;
  item.classList.add('dragging');
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', draggedDashboardWidgetId);
});

document.querySelector('#dashboardWidgetControls').addEventListener('dragover', event => {
  const item = event.target.closest('.dashboard-widget-control');
  if (!item || item.dataset.widgetId === draggedDashboardWidgetId) return;
  event.preventDefault();
  document.querySelectorAll('.dashboard-widget-control.drag-over').forEach(control => control.classList.remove('drag-over'));
  item.classList.add('drag-over');
});

document.querySelector('#dashboardWidgetControls').addEventListener('drop', event => {
  const target = event.target.closest('.dashboard-widget-control');
  if (!target || !draggedDashboardWidgetId) return;
  event.preventDefault();
  const sourceIndex = editingDashboardOrder.indexOf(draggedDashboardWidgetId);
  const targetIndex = editingDashboardOrder.indexOf(target.dataset.widgetId);
  if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return;
  editingDashboardOrder.splice(sourceIndex, 1);
  editingDashboardOrder.splice(targetIndex, 0, draggedDashboardWidgetId);
  draggedDashboardWidgetId = null;
  renderDashboardWidgetControls();
  previewDashboardEditor();
});

document.querySelector('#dashboardWidgetControls').addEventListener('dragend', () => {
  draggedDashboardWidgetId = null;
  document.querySelectorAll('.dashboard-widget-control.dragging, .dashboard-widget-control.drag-over').forEach(control => control.classList.remove('dragging', 'drag-over'));
});

document.querySelector('#saveDashboardViewButton').addEventListener('click', async () => {
  const name = document.querySelector('#dashboardLayoutName').value.trim();
  if (!name) return showToast('Dê um nome para a visualização.');
  if (!editingDashboardVisible.size) return showToast('Escolha pelo menos um item para mostrar.');
  const current = getActiveDashboardLayout();
  const id = dashboardEditorMode === 'edit' && !isBuiltInDashboard(current.id) ? current.id : `layout-${Date.now()}`;
  const layout = { id, name, order: [...editingDashboardOrder], visible: [...editingDashboardVisible], sizes: { ...editingDashboardSizes } };
  const existingIndex = dashboardLayouts.findIndex(item => item.id === id);
  if (existingIndex >= 0) dashboardLayouts[existingIndex] = layout;
  else dashboardLayouts.push(layout);
  localStorage.setItem(dashboardStorageKey(), JSON.stringify(dashboardLayouts));
  let syncError = false;
  if (dataApi && signedInUser) {
    const { error } = await dataApi.saveDashboardLayout(signedInUser.id, layout);
    syncError = Boolean(error);
  }
  activeDashboardLayoutId = id;
  refreshDashboardLayoutSelect();
  applyDashboardLayout(id);
  closeDashboardEditor();
  showToast(syncError ? 'A visualização ficou neste dispositivo, mas não foi sincronizada.' : `Visualização “${name}” salva na sua conta.`);
});

document.querySelector('#deleteDashboardViewButton').addEventListener('click', async () => {
  if (isBuiltInDashboard(activeDashboardLayoutId)) return;
  const layout = getActiveDashboardLayout();
  if (!window.confirm(`Excluir a visualização “${layout.name}”?`)) return;
  if (dataApi && signedInUser) {
    const { error } = await dataApi.deleteDashboardLayout(signedInUser.id, activeDashboardLayoutId);
    if (error) return showToast('Não foi possível excluir a visualização da conta.');
  }
  dashboardLayouts = dashboardLayouts.filter(item => item.id !== activeDashboardLayoutId);
  localStorage.setItem(dashboardStorageKey(), JSON.stringify(dashboardLayouts));
  activeDashboardLayoutId = 'normal';
  refreshDashboardLayoutSelect();
  applyDashboardLayout('normal');
  closeDashboardEditor();
  showToast('Visualização excluída.');
});

let toastTimer;
function showToast(message) {
  let toast = document.querySelector('#toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2300);
}

document.querySelector('#extensionPreferencesForm').addEventListener('input', () => {
  syncExtensionOptionControls();
  renderExtensionPreview(readExtensionPreferencesForm());
  const status = document.querySelector('#extensionSyncStatus');
  status.textContent = 'Alterações ainda não salvas';
  status.dataset.state = 'dirty';
});

document.querySelector('#extensionPreferencesForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!dataApi || !signedInUser) return showToast('Entre na sua conta para salvar as preferências.');
  const button = document.querySelector('#saveExtensionPreferences');
  const status = document.querySelector('#extensionSyncStatus');
  const preferences = readExtensionPreferencesForm();
  button.disabled = true;
  button.textContent = 'Salvando...';
  const { error } = await dataApi.saveExtensionPreferences(signedInUser.id, preferences);
  button.disabled = false;
  button.textContent = 'Salvar para a extensão';
  if (error) {
    status.textContent = 'Não foi possível salvar';
    status.dataset.state = 'error';
    return showToast('Prepare a tabela de preferências no Supabase e tente novamente.');
  }
  currentExtensionPreferences = preferences;
  status.textContent = 'Sincronizado com sua conta';
  status.dataset.state = 'saved';
  showToast('Preferências salvas. Use “Sincronizar agora” na extensão.');
});

document.querySelector('#resetExtensionPreferences').addEventListener('click', () => {
  fillExtensionPreferencesForm(DEFAULT_EXTENSION_PREFERENCES);
  const status = document.querySelector('#extensionSyncStatus');
  status.textContent = 'Padrão restaurado; falta salvar';
  status.dataset.state = 'dirty';
});

document.querySelector('#supportQuestion').addEventListener('input', event => {
  document.querySelector('#supportQuestionCount').textContent = `${event.target.value.length}/1000`;
});

document.querySelector('#supportQuestionForm').addEventListener('submit', event => {
  event.preventDefault();
  const question = document.querySelector('#supportQuestion').value.trim();
  if (!question) return showToast('Escreva sua dúvida antes de continuar.');
  const subject = encodeURIComponent('Dúvida sobre o MindFlowIA');
  const body = encodeURIComponent(`Olá, equipe MindFlowIA!\n\n${question}\n\nObrigado.`);
  window.location.href = `mailto:tccmindflowai@gmail.com?subject=${subject}&body=${body}`;
});

// Se a sessão ainda existir no navegador, o usuário volta direto para a home.
async function initializeApp() {
  initializeSidebar();
  drawSummaryChart();
  setAuthMode('login');

  if (!db) {
    showToast('A biblioteca do Supabase não carregou. Confira sua internet.');
    return;
  }

  const { data, error } = await db.auth.getSession();
  if (error || !data.session) {
    showView('landing');
    return;
  }

  signedInUser = data.session.user;
  await loadAccount();
  showView('home');
}

// Começa tudo por aqui.
initializeApp();
setInterval(() => void refreshExtensionPresence(), 10_000);
