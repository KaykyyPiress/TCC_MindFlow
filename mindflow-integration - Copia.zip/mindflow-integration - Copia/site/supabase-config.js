// Essa chave é a pública (anon). Ela pode ficar no navegador porque o acesso
// de verdade é limitado pelas regras RLS do Supabase.
window.MINDFLOW_SUPABASE = {
  url: 'https://xeykjfytdvqtgcewvoii.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhleWtqZnl0ZHZxdGdjZXd2b2lpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg4MTA2MzMsImV4cCI6MjEwNDM4NjYzM30.DHrm3C3Zl7ZnckpEv1FsngbkkUWC1a94q8577l3aLc0'
};
