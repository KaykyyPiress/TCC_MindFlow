-- Execute uma vez no SQL Editor do Supabase.
-- Esta tabela guarda somente escolhas visuais da extensão por conta.
-- Não recebe nomes, vídeos nem resultados individuais dos participantes.

create table if not exists public.extensao_preferencia (
  comunicador_id uuid primary key references public.comunicador(id) on delete cascade,
  configuracao jsonb not null default '{}'::jsonb,
  atualizado_em timestamptz not null default now()
);

alter table public.extensao_preferencia enable row level security;

drop policy if exists extensao_preferencia_propria on public.extensao_preferencia;
create policy extensao_preferencia_propria
  on public.extensao_preferencia for all to authenticated
  using (comunicador_id = (select auth.uid()))
  with check (comunicador_id = (select auth.uid()));

grant select, insert, update, delete on public.extensao_preferencia to authenticated;
