-- ARQUIVO OBSOLETO.
-- As demonstrações agora devem permanecer visíveis para todas as contas.
-- Use supabase-ajustes-dashboard.sql para aplicar a configuração atual.
select 'Nenhuma alteração executada: as demonstrações permanecem públicas para usuários autenticados.' as aviso;
