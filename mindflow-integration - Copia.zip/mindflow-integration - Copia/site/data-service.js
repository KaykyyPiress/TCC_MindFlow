// Essa é a ponte entre as telas e o banco.
// Se os nomes das tabelas mudarem depois, a manutenção começa por aqui.
window.createMindFlowData = function createMindFlowData(db) {
  const sources = {
    profile: 'comunicador',
    sessions: 'sessao',
    summary: 'v_resumo_sessao',
    timeline: 'v_timeline_sessao',
    alerts: 'alerta_semaforo',
    dashboardLayouts: 'dashboard_visualizacao',
    extensionPreferences: 'extensao_preferencia',
    annotations: 'anotacao_sessao'
  };

  const summaryFields = [
    'sessao_id', 'comunicador_id', 'titulo', 'codigo', 'status',
    'iniciada_em', 'encerrada_em', 'duracao', 'n_participantes',
    'n_inferencias', 'n_janelas', 'fracao_engajado_media',
    'engajamento_medio', 'janelas_verde', 'janelas_amarelo',
    'janelas_vermelho', 'n_alertas', 'is_demo'
  ].join(',');

  const timelineLegacyFields = [
    'inicio', 'fim', 'n_participantes', 'cor', 'fracao_engajado',
    'engajamento_medio', 'fracao_entediado', 'fracao_confuso',
    'fracao_frustrado', 'face_ratio_medio'
  ].join(',');
  const timelineFields = `${timelineLegacyFields},tedio_medio,confusao_media,frustracao_media`;

  function normalizeIntensity(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return null;
    return Math.max(0, Math.min(1, numeric / 3));
  }

  function normalizeSummary(row) {
    if (!row) return null;
    return {
      id: row.sessao_id,
      ownerId: row.comunicador_id,
      title: row.titulo,
      code: row.codigo,
      status: row.status,
      startedAt: row.iniciada_em,
      endedAt: row.encerrada_em,
      duration: row.duracao,
      participants: Number(row.n_participantes || 0),
      inferences: Number(row.n_inferencias || 0),
      windows: Number(row.n_janelas || 0),
      engagedFraction: row.fracao_engajado_media == null ? null : Number(row.fracao_engajado_media),
      averageEngagement: row.engajamento_medio == null ? null : Number(row.engajamento_medio),
      greenWindows: Number(row.janelas_verde || 0),
      yellowWindows: Number(row.janelas_amarelo || 0),
      redWindows: Number(row.janelas_vermelho || 0),
      alerts: Number(row.n_alertas || 0),
      isDemo: Boolean(row.is_demo)
    };
  }

  function normalizeTimeline(row) {
    if (!row) return null;
    return {
      startedAt: row.inicio,
      endedAt: row.fim,
      participants: Number(row.n_participantes || 0),
      color: row.cor,
      engagedFraction: Number(row.fracao_engajado || 0),
      averageEngagement: Number(row.engajamento_medio || 0),
      engagementIntensity: normalizeIntensity(row.engajamento_medio),
      boredFraction: Number(row.fracao_entediado || 0),
      boredomIntensity: normalizeIntensity(row.tedio_medio),
      confusedFraction: Number(row.fracao_confuso || 0),
      confusionIntensity: normalizeIntensity(row.confusao_media),
      frustratedFraction: Number(row.fracao_frustrado || 0),
      frustrationIntensity: normalizeIntensity(row.frustracao_media),
      faceRatio: row.face_ratio_medio == null ? null : Number(row.face_ratio_medio)
    };
  }

  async function normalizeProfile(row) {
    if (!row) return null;
    let photoUrl = null;
    if (row.foto_path) {
      const signed = await db.storage.from('avatars').createSignedUrl(row.foto_path, 3600);
      photoUrl = signed.data?.signedUrl || null;
    }
    return {
      name: row.nome,
      email: row.email,
      institution: row.instituicao,
      gender: row.genero,
      occupation: row.atuacao,
      photoPath: row.foto_path,
      photoUrl
    };
  }

  return {
    async getProfile(userId) {
      const result = await db.from(sources.profile)
        .select('nome, email, instituicao, genero, atuacao, foto_path')
        .eq('id', userId)
        .maybeSingle();
      return { ...result, data: await normalizeProfile(result.data) };
    },

    // Atualizar o perfil fica aqui também para a tela não conhecer os nomes do banco.
    async updateProfile(userId, profile) {
      const result = await db.from(sources.profile).update({
        nome: profile.name,
        genero: profile.gender,
        atuacao: profile.occupation,
        ...(profile.photoPath ? { foto_path: profile.photoPath } : {})
      }).eq('id', userId).select('nome, email, instituicao, genero, atuacao, foto_path').single();
      return { ...result, data: await normalizeProfile(result.data) };
    },

    async updateRegistrationData(userId, institution) {
      const result = await db.from(sources.profile)
        .update({ instituicao: institution })
        .eq('id', userId)
        .select('nome, email, instituicao, genero, atuacao, foto_path')
        .single();
      return { ...result, data: await normalizeProfile(result.data) };
    },

    async uploadProfilePhoto(userId, file) {
      const path = `${userId}/profile-photo`;
      const result = await db.storage.from('avatars').upload(path, file, {
        upsert: true,
        contentType: file.type,
        cacheControl: '3600'
      });
      return { ...result, data: result.data ? { path: result.data.path } : null };
    },

    async listMeetingSummaries() {
      const result = await db.from(sources.summary)
        .select(summaryFields)
        .order('iniciada_em', { ascending: false, nullsFirst: false });
      return { ...result, data: (result.data || []).map(normalizeSummary) };
    },

    async closeStaleExtensionMeetings(userId, staleBefore) {
      const now = new Date().toISOString();
      return db.from(sources.sessions)
        .update({ status: 'encerrada', encerrada_em: now })
        .eq('comunicador_id', userId)
        .eq('origem', 'extensao')
        .eq('status', 'em_andamento')
        .lt('extensao_ativa_em', staleBefore);
    },

    async getActiveExtensionMeeting(userId, activeSince) {
      const result = await db.from(sources.sessions)
        .select('id, titulo, codigo, status, iniciada_em, extensao_ativa_em')
        .eq('comunicador_id', userId)
        .eq('origem', 'extensao')
        .eq('status', 'em_andamento')
        .gte('extensao_ativa_em', activeSince)
        .order('extensao_ativa_em', { ascending: false })
        .limit(1)
        .maybeSingle();
      return {
        ...result,
        data: result.data ? {
          id: result.data.id,
          title: result.data.titulo,
          code: result.data.codigo,
          status: result.data.status,
          startedAt: result.data.iniciada_em,
          activeAt: result.data.extensao_ativa_em
        } : null
      };
    },

    async createMeeting(ownerId) {
      const result = await db.from(sources.sessions).insert({
        comunicador_id: ownerId,
        titulo: 'Nova reunião',
        plataforma: 'Microsoft Teams'
      }).select('id, codigo').single();
      return { ...result, data: result.data ? { id: result.data.id, code: result.data.codigo } : null };
    },

    updateMeeting(meetingId, changes) {
      const databaseChanges = {};
      if ('title' in changes) databaseChanges.titulo = changes.title;
      if ('platform' in changes) databaseChanges.plataforma = changes.platform;
      if ('status' in changes) databaseChanges.status = changes.status;
      if ('startedAt' in changes) databaseChanges.iniciada_em = changes.startedAt;
      if ('endedAt' in changes) databaseChanges.encerrada_em = changes.endedAt;
      return db.from(sources.sessions).update(databaseChanges).eq('id', meetingId);
    },

    deleteMeeting(meetingId, ownerId) {
      return db.from(sources.sessions)
        .delete()
        .eq('id', meetingId)
        .eq('comunicador_id', ownerId);
    },

    async getMeetingSummary(meetingId) {
      let query = db.from(sources.summary).select(summaryFields);
      query = meetingId
        ? query.eq('sessao_id', meetingId)
        : query.order('iniciada_em', { ascending: false, nullsFirst: false }).limit(1);
      const result = await query;
      return { ...result, data: normalizeSummary(result.data?.[0]) };
    },

    async getTimeline(meetingId) {
      let result = await db.from(sources.timeline)
        .select(timelineFields)
        .eq('sessao_id', meetingId)
        .order('inicio', { ascending: true });
      // Compatibilidade durante a aplicação da migração que acrescenta as
      // intensidades usadas pela extensão ao vivo.
      if (result.error) {
        result = await db.from(sources.timeline)
          .select(timelineLegacyFields)
          .eq('sessao_id', meetingId)
          .order('inicio', { ascending: true });
      }
      return { ...result, data: (result.data || []).map(normalizeTimeline) };
    },

    async getLatestTimelinePoint(meetingId) {
      let result = await db.from(sources.timeline)
        .select(timelineFields)
        .eq('sessao_id', meetingId)
        .order('inicio', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (result.error) {
        result = await db.from(sources.timeline)
          .select(timelineLegacyFields)
          .eq('sessao_id', meetingId)
          .order('inicio', { ascending: false })
          .limit(1)
          .maybeSingle();
      }
      return { ...result, data: normalizeTimeline(result.data) };
    },

    async getAlerts(meetingId) {
      const result = await db.from(sources.alerts)
        .select('id,janela_id,ts,cor,cor_anterior,motivo,detalhes')
        .eq('sessao_id', meetingId)
        .neq('cor', 'verde')
        .order('ts', { ascending: true });
      return {
        ...result,
        data: (result.data || []).map(row => ({
          id: row.id,
          windowId: row.janela_id,
          timestamp: row.ts,
          color: row.cor,
          previousColor: row.cor_anterior,
          reason: row.motivo,
          details: row.detalhes || {}
        }))
      };
    },

    async listDashboardLayouts(userId) {
      const result = await db.from(sources.dashboardLayouts)
        .select('id, nome, configuracao')
        .eq('comunicador_id', userId)
        .order('atualizado_em', { ascending: false });
      return {
        ...result,
        data: (result.data || []).map(row => ({
          id: row.id,
          name: row.nome,
          order: Array.isArray(row.configuracao?.order) ? row.configuracao.order : [],
          visible: Array.isArray(row.configuracao?.visible) ? row.configuracao.visible : [],
          sizes: row.configuracao?.sizes && typeof row.configuracao.sizes === 'object' ? row.configuracao.sizes : {}
        }))
      };
    },

    saveDashboardLayout(userId, layout) {
      return db.from(sources.dashboardLayouts).upsert({
        comunicador_id: userId,
        id: layout.id,
        nome: layout.name,
        configuracao: { order: layout.order, visible: layout.visible, sizes: layout.sizes || {} },
        atualizado_em: new Date().toISOString()
      }, { onConflict: 'comunicador_id,id' });
    },

    deleteDashboardLayout(userId, layoutId) {
      return db.from(sources.dashboardLayouts)
        .delete()
        .eq('comunicador_id', userId)
        .eq('id', layoutId);
    },

    async getExtensionPreferences(userId) {
      const result = await db.from(sources.extensionPreferences)
        .select('configuracao, atualizado_em')
        .eq('comunicador_id', userId)
        .maybeSingle();
      return {
        ...result,
        data: result.data ? {
          configuration: result.data.configuracao || {},
          updatedAt: result.data.atualizado_em
        } : null
      };
    },

    saveExtensionPreferences(userId, configuration) {
      return db.from(sources.extensionPreferences).upsert({
        comunicador_id: userId,
        configuracao: configuration,
        atualizado_em: new Date().toISOString()
      }, { onConflict: 'comunicador_id' });
    },

    async listAnnotations(meetingId) {
      let result = await db.from(sources.annotations)
        .select('id, instante, fim, texto, criado_em')
        .eq('sessao_id', meetingId)
        .order('instante', { ascending: true });
      if (result.error && /fim/i.test(result.error.message || '')) {
        result = await db.from(sources.annotations)
          .select('id, instante, texto, criado_em')
          .eq('sessao_id', meetingId)
          .order('instante', { ascending: true });
      }
      return {
        ...result,
        data: (result.data || []).map(row => ({
          id: row.id,
          moment: row.instante,
          endMoment: row.fim || row.instante,
          text: row.texto,
          createdAt: row.criado_em
        }))
      };
    },

    async addAnnotation(userId, meetingId, moment, endMoment, text) {
      let result = await db.from(sources.annotations).insert({
        comunicador_id: userId,
        sessao_id: meetingId,
        instante: moment,
        fim: endMoment,
        texto: text
      }).select('id, instante, fim, texto, criado_em').single();
      if (result.error && /fim/i.test(result.error.message || '')) {
        result = await db.from(sources.annotations).insert({
          comunicador_id: userId,
          sessao_id: meetingId,
          instante: moment,
          texto: text
        }).select('id, instante, texto, criado_em').single();
      }
      return {
        ...result,
        data: result.data ? {
          id: result.data.id,
          moment: result.data.instante,
          endMoment: result.data.fim || endMoment || result.data.instante,
          text: result.data.texto,
          createdAt: result.data.criado_em
        } : null
      };
    },

    deleteAnnotation(annotationId) {
      return db.from(sources.annotations).delete().eq('id', annotationId);
    }
  };
};
