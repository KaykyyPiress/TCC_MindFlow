-- MindFlowIA — privacidade, demonstrações públicas e gráfico alinhado à extensão.
-- Pode ser executado mais de uma vez.

begin;

alter table public.sessao enable row level security;

-- Reuniões comuns: somente o proprietário autenticado.
drop policy if exists sessao_select_propria on public.sessao;
create policy sessao_select_propria
  on public.sessao for select to authenticated
  using (comunicador_id = (select auth.uid()));

-- Reuniões de demonstração: leitura para todas as contas autenticadas.
drop policy if exists sessao_select_demonstracao on public.sessao;
create policy sessao_select_demonstracao
  on public.sessao for select to authenticated
  using (is_demo = true);

drop policy if exists janela_demo_select on public.janela;
create policy janela_demo_select on public.janela for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = janela.sessao_id and s.is_demo = true));

drop policy if exists inferencia_demo_select on public.inferencia;
create policy inferencia_demo_select on public.inferencia for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = inferencia.sessao_id and s.is_demo = true));

drop policy if exists inferencia_dimensao_demo_select on public.inferencia_dimensao;
create policy inferencia_dimensao_demo_select on public.inferencia_dimensao for select to authenticated
  using (exists (
    select 1
    from public.inferencia i
    join public.sessao s on s.id = i.sessao_id
    where i.id = inferencia_dimensao.inferencia_id and s.is_demo = true
  ));

drop policy if exists participante_demo_select on public.participante;
create policy participante_demo_select on public.participante for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = participante.sessao_id and s.is_demo = true));

drop policy if exists alerta_demo_select on public.alerta_semaforo;
create policy alerta_demo_select on public.alerta_semaforo for select to authenticated
  using (exists (select 1 from public.sessao s where s.id = alerta_semaforo.sessao_id and s.is_demo = true));

-- Exclusão: cada usuário só pode apagar a própria reunião.
drop policy if exists sessao_delete_propria on public.sessao;
create policy sessao_delete_propria
  on public.sessao for delete to authenticated
  using (comunicador_id = (select auth.uid()));
grant delete on public.sessao to authenticated;

-- A extensão mostra a intensidade esperada de cada dimensão (0 a 3 convertida
-- para 0% a 100%). A view agora expõe a mesma medida para as quatro linhas.
create or replace view public.v_timeline_sessao
with (security_invoker = true)
as
select
  sessao_id,
  inicio,
  fim,
  max(n_participantes) as n_participantes,
  max(cor) filter (where dimensao = 'engajamento'::public.dimensao_cognitiva) as cor,
  max(fracao_estado) filter (where dimensao = 'engajamento'::public.dimensao_cognitiva) as fracao_engajado,
  max(nivel_medio) filter (where dimensao = 'engajamento'::public.dimensao_cognitiva) as engajamento_medio,
  max(fracao_estado) filter (where dimensao = 'tedio'::public.dimensao_cognitiva) as fracao_entediado,
  max(fracao_estado) filter (where dimensao = 'confusao'::public.dimensao_cognitiva) as fracao_confuso,
  max(fracao_estado) filter (where dimensao = 'frustracao'::public.dimensao_cognitiva) as fracao_frustrado,
  max(face_ratio_medio) filter (where dimensao = 'engajamento'::public.dimensao_cognitiva) as face_ratio_medio,
  max(nivel_medio) filter (where dimensao = 'tedio'::public.dimensao_cognitiva) as tedio_medio,
  max(nivel_medio) filter (where dimensao = 'confusao'::public.dimensao_cognitiva) as confusao_media,
  max(nivel_medio) filter (where dimensao = 'frustracao'::public.dimensao_cognitiva) as frustracao_media
from public.janela
group by sessao_id, inicio, fim;

revoke all on public.v_timeline_sessao from anon;
grant select on public.v_timeline_sessao to authenticated;

notify pgrst, 'reload schema';

commit;

select schemaname, tablename, policyname, cmd
from pg_policies
where schemaname = 'public'
  and policyname in (
    'sessao_select_propria', 'sessao_select_demonstracao',
    'janela_demo_select', 'inferencia_demo_select',
    'inferencia_dimensao_demo_select', 'participante_demo_select',
    'alerta_demo_select', 'sessao_delete_propria'
  )
order by tablename, policyname;
