-- MindFlowIA — permite vincular uma anotação a um intervalo da reunião.
-- Migração idempotente: pode ser executada mais de uma vez.

begin;

alter table public.anotacao_sessao
  add column if not exists fim timestamptz;

update public.anotacao_sessao
set fim = instante
where fim is null;

notify pgrst, 'reload schema';

commit;

select column_name, data_type, is_nullable
from information_schema.columns
where table_schema = 'public'
  and table_name = 'anotacao_sessao'
  and column_name in ('instante', 'fim')
order by ordinal_position;
