# Extensão final do MindFlow para Google Meet

Esta versão une o controle de fontes dentro do Meet ao extrator Python mais
atualizado. A extensão não executa MediaPipe e não escolhe silenciosamente quem
será analisado.

## Fluxo real

```text
vídeos visíveis no Google Meet
  -> identificação do tile e nome exibido pelo Meet (somente na interface)
  -> tela e apresentador bloqueados automaticamente
  -> participantes permitidos entram automaticamente em análise
  -> Ignorar análise / Retomar análise controla a captura
  -> JPEG 640x480 enviado a http://127.0.0.1:8765/frame
  -> MediaPipe Face Mesh + Pose no Python
  -> vetor de 120 features, com NaN onde o dado não pôde ser observado
  -> sequência individual de 30 frames
  -> NaN/inf substituído por zero antes de scaler -> PCA -> LSTM
  -> quatro índices independentes: engajamento, tédio, confusão e frustração
  -> suavização das últimas 5 previsões no Meet
  -> farol individual/coletivo e gráfico local dos últimos 5 minutos
  -> probabilidades podem ser persistidas no Supabase, sem imagens ou nomes
```

## Como a escolha de fontes funciona

Cada vídeo visível recebe um pseudônimo local, como `participant_01`, e uma
etiqueta sobre o próprio tile. O nome mostrado pelo Google Meet é usado apenas
para o operador reconhecer a fonte; ele não é enviado ao Python nem ao banco.
Não existe reconhecimento facial. Telas compartilhadas e a câmera do próprio
apresentador são classificadas e bloqueadas automaticamente, sem pedir escolha.

Uma fonte nova começa em **REVISAR — NÃO ENVIADO**. Os botões fazem o seguinte:

| Opção | Resultado |
|---|---|
| **IA ATIVA** | participante permitido enviado automaticamente ao Python local |
| **Ignorar análise** | interrompe o envio daquela fonte |
| **Retomar análise** | libera novamente uma fonte ignorada |

A extensão procura sinais do próprio Meet e do dispositivo local para detectar
tela e apresentador. Essas fontes ficam bloqueadas automaticamente e não exibem
botões de decisão. Os demais participantes oferecem **Ignorar análise** e
**Retomar análise**. No máximo cinco fontes podem ficar autorizadas ao mesmo tempo.

Quando uma fonte desaparece por mais de 12 segundos, seu buffer no Python é
reiniciado e a decisão é descartada. Se ela reaparecer depois disso, volta para
revisão. Uma troca de decisão também limpa previsões e buffers anteriores.

## Instalação e execução

Na primeira vez:

```powershell
cd "CAMINHO\mindflow-integration"
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Para iniciar o servidor nas próximas vezes:

```powershell
cd "CAMINHO\mindflow-integration"
.\.venv\Scripts\python.exe -m mindflow_extractor.runners.extension_server
```

O terminal deve informar que o modelo foi carregado e que o serviço está em
`http://127.0.0.1:8765`.

Depois, no Chrome:

1. abra `chrome://extensions`;
2. ative **Modo do desenvolvedor**;
3. clique em **Carregar sem compactação**;
4. selecione a pasta `mindflow-integration\extension`;
5. recarregue a aba do Google Meet.

O ZIP de entrega serve para transporte. Para testar, extraia-o primeiro e
carregue a pasta que contém `manifest.json`.

## Teste recomendado

1. Abra um Meet com o Python ligado.
2. Confirme no painel: **Python conectado · modelo carregado**.
3. Verifique que todos os tiles aparecem como não enviados.
4. Confirme que sua própria câmera aparece como apresentador bloqueado.
5. Confirme que a apresentação compartilhada aparece como tela bloqueada.
6. Confirme que participantes permitidos aparecem como **IA ATIVA** e ignore uma fonte incorreta quando necessário.
7. Aguarde a coleta inicial de 30 frames, aproximadamente cinco segundos.
8. Confira `rosto/sem rosto`, `pose/sem pose`, o fps real e os quatro índices.
9. Troque uma fonte para **Ignorar** e confirme que o status deixa de ser
   **IA ATIVA** imediatamente.

## 6 FPS: alinhamento com o modelo oficial

A captura tenta iniciar até 6 requisições por segundo por fonte. Como cada
fonte mantém apenas uma requisição em andamento, o sistema não cria uma fila
infinita: se o Python estiver ocupado, novos frames daquela fonte são pulados.
O painel mostra o `fps real` processado, que pode ficar abaixo de 6 conforme
CPU, quantidade de pessoas e resolução do Meet.

O modelo oficial foi treinado com `skip_frames=4`, aproximadamente 6 FPS em
vídeos de 30 FPS. A versão 1.6.3 usa o mesmo alvo ao vivo: 30 frames representam
cerca de cinco segundos. O piloto novo a 30 FPS usa 150 frames e não deve
substituir o modelo oficial sem adaptar e validar o servidor.

## Histórico no Supabase

O histórico é opcional e fica no servidor Python. Ele só é ativado quando as
quatro configurações abaixo são fornecidas:

```powershell
$env:MINDFLOW_SUPABASE_URL = "https://SEU-PROJETO.supabase.co"
$env:MINDFLOW_SUPABASE_ANON_KEY = "SUA-CHAVE-ANON"
$env:MINDFLOW_SESSION_CODE = "CODIGO_DA_SESSAO"
$env:MINDFLOW_CONSENT_VERSION = "VERSAO-DO-TERMO-ACEITO"
.\.venv\Scripts\python.exe -m mindflow_extractor.runners.extension_server
```

O escritor usa as RPCs existentes `entrar_sessao`, `registrar_inferencia` e
`sair_sessao`. Uma amostra é enfileirada a cada 30 frames processados por fonte,
aproximadamente a cada cinco segundos no alvo atual.
São persistidos somente:

- pseudônimo gerado pela sessão;
- timestamp;
- quatro distribuições de probabilidade;
- proporção recente de detecção de rosto e pose;
- latência e versão do modelo.

Não são persistidos no Supabase vídeo, frame, landmark, nome do Meet ou
identificador facial. O launcher de teste pode salvar snapshots somente na
pasta local `capturas_local/`.
A versão do termo de consentimento não possui valor padrão de propósito. Use
apenas a chave pública `anon`; nunca coloque `service_role` na extensão.

## Limites do protótipo

- nomes e papéis dependem do DOM mutável do Google Meet; por isso a decisão
  manual é a autoridade final;
- “IA ATIVA” confirma a fonte enviada, não a precisão científica da previsão;
- os limiares do farol são operacionais e ainda precisam de validação;
- uma fonte sem rosto/pose pode produzir muitos NaN; eles são contabilizados
  na resposta e substituídos por zero somente na entrada do modelo;
- o gráfico de cinco minutos vive apenas na página atual; o histórico durável
  depende da sessão configurada no Supabase.
