# Guia do MindFlow Integration

Documentação em linguagem simples para instalar, executar e entender a integração entre a extensão do Google Meet, o Python, o modelo de Inteligência Artificial, o Supabase e o site do MindFlow.

Este guia acompanha o arquivo `mindflow-integration.zip`.

> **Versão documentada:** extensão MindFlow AI 1.6.3  
> **Ambiente testado:** Windows 10/11, Google Chrome e Python 3.11.9

---

## 1. O que existe dentro do projeto?

O MindFlow atual possui quatro partes principais:

| Parte | Onde funciona | Responsabilidade |
|---|---|---|
| Extensão | Google Chrome, dentro do Google Meet | Encontra os vídeos, bloqueia fontes indevidas, permite escolher participantes e mostra o painel |
| Python local | Computador do apresentador | Executa MediaPipe, cria as 120 features e consulta o modelo LSTM |
| Supabase | Internet | Guarda conta, reunião, preferências e histórico numérico |
| Site | Netlify, conectado ao Supabase | Mostra reuniões concluídas, dashboards e preferências da extensão |

Em uma frase:

> A extensão enxerga os vídeos do Meet, o Python faz a análise e o Supabase guarda somente o histórico numérico que será exibido pelo site.

---

## 2. Fluxo completo, do Meet até o site

```text
┌──────────────────────────────┐
│ Google Meet                  │
│ vídeos visíveis na reunião   │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│ Extensão MindFlow            │
│ • exige login                │
│ • detecta tela/apresentador  │
│ • usuário autoriza fontes    │
└──────────────┬───────────────┘
               │ JPEG temporário 640 × 480
               │ http://127.0.0.1:8765/frame
               ▼
┌──────────────────────────────┐
│ Python no computador         │
│ MediaPipe Face + Pose        │
│ 120 features → scaler → PCA  │
│ → LSTM → quatro índices      │
└───────────┬───────────┬──────┘
            │           │
            │ resposta  │ histórico numérico
            ▼           ▼
┌──────────────────┐  ┌──────────────────────┐
│ Painel no Meet   │  │ Supabase             │
│ farol e gráfico  │  │ sessão e inferências │
└──────────────────┘  └──────────┬───────────┘
                                  │
                                  ▼
                       ┌──────────────────────┐
                       │ Site no Netlify      │
                       │ dashboards/histórico│
                       └──────────────────────┘
```

### O que é enviado pela extensão ao Python?

A extensão envia uma imagem JPEG temporária de cada fonte autorizada para:

```text
http://127.0.0.1:8765/frame
```

`127.0.0.1` significa **o próprio computador**. Esse frame não é enviado pela internet ao Supabase. No modo atual de teste, o `iniciar_mindflow.bat` salva uma imagem local a cada cinco segundos em `capturas_local`; essas imagens não entram na inferência depois de salvas.

### O que é enviado ao Supabase?

O histórico contém somente dados como:

- código e título da reunião;
- horário da leitura;
- identificador anônimo, como `participant_01`;
- probabilidades dos quatro níveis de cada indicador;
- proporção de frames em que rosto e pose foram detectados;
- latência e versão do modelo.

Não são salvos no Supabase:

- vídeo;
- frame ou fotografia;
- landmarks do rosto ou do corpo;
- nome dos participantes;
- áudio;
- reconhecimento facial.

---

## 3. O que a extensão faz?

### 3.1 Login obrigatório

A extensão exige login antes de liberar a análise. Deve ser usada a mesma conta cadastrada no site.

O login é necessário para:

- vincular a reunião ao usuário correto;
- criar a sessão no Supabase;
- carregar as preferências visuais configuradas no site;
- mostrar posteriormente o histórico no dashboard da mesma conta.

O cadastro de uma nova conta é feito no site. A extensão possui apenas a entrada em uma conta existente.

### 3.2 Identificação das fontes do Meet

A extensão examina os elementos de vídeo visíveis no Google Meet. Cada fonte recebe um identificador local e anônimo, como:

```text
Fonte 01
Fonte 02
Fonte 03
```

Ela tenta classificar automaticamente:

| Fonte | Comportamento |
|---|---|
| Tela compartilhada | Bloqueada automaticamente |
| Câmera do próprio apresentador | Bloqueada automaticamente |
| Possível participante | Entra automaticamente em análise depois do login e da criação da reunião; pode ser ignorado manualmente |

As etiquetas deixam visível quais fontes estão em **IA ATIVA**. O usuário pode clicar em **Ignorar análise** e depois em **Retomar análise**.

O protótipo permite até **cinco fontes analisadas ao mesmo tempo**.

> A identificação depende da estrutura visual do Google Meet, que pode ser alterada pelo Google. Por isso é importante conferir as etiquetas sobre os vídeos antes de autorizar a análise.

### 3.3 Captura alinhada a 6 FPS

A extensão tenta capturar até 6 frames por segundo de cada fonte autorizada. Esse é o FPS efetivo aproximado usado para treinar o modelo oficial, portanto 30 frames continuam representando cerca de cinco segundos.

Isso é um **alvo**, não uma garantia. O valor real depende de:

- velocidade do processador;
- quantidade de participantes analisados;
- resolução dos vídeos;
- desempenho do navegador;
- tempo necessário para o MediaPipe.

Cada fonte mantém somente uma requisição em andamento. Se o Python ainda estiver processando o frame anterior, a extensão pula o próximo em vez de criar uma fila infinita.

O painel mostra o FPS realmente processado.

### 3.4 Título e encerramento da reunião

A extensão tenta encontrar o título mostrado pelo Google Meet. Esse título aparece ao lado de **MindFlow AI** e é salvo na coluna de título da reunião.

Quando o Meet oferece apenas o código da sala, o sistema usa um título semelhante a:

```text
Google Meet · abc-defg-hij
```

O título do cabeçalho é clicável. O usuário pode corrigi-lo manualmente e a alteração também será enviada ao Supabase.

A sessão é marcada como concluída quando a extensão identifica mensagens como:

- `Você saiu da reunião`;
- `A reunião terminou`;
- `Participar novamente`;
- mensagens equivalentes em inglês.

Isso acontece mesmo que a aba do Meet continue aberta. Se o navegador for fechado abruptamente, o sinal periódico deixa de chegar e o site trata a sessão como abandonada quando o dashboard é reaberto ou atualizado.

### 3.5 Painel da extensão

O painel mostra:

- farol geral do grupo;
- indicador predominante;
- confiança da resposta predominante;
- seta de tendência do engajamento;
- quatro índices independentes;
- gráfico dos últimos cinco minutos;
- quantidade de fontes analisadas e ignoradas;
- conexão com o Python e situação do histórico.

O painel pode ser movido e redimensionado. As opções de aparência são configuradas na aba **Extensão** do site e sincronizadas pela conta.

---

## 4. O que o Python faz?

O Python é a parte que realmente executa a visão computacional e o modelo. A extensão não contém MediaPipe nem executa a LSTM.

### 4.1 MediaPipe

Para cada frame recebido, o Python tenta localizar:

- até 478 pontos do rosto, incluindo íris;
- 33 pontos de pose corporal.

Esses pontos são usados temporariamente para calcular medidas geométricas. Eles não são enviados ao banco.

### 4.2 Vetor de 120 features

O resultado de cada frame é um vetor com 120 números:

| Bloco | Quantidade | Explicação simples |
|---|---:|---|
| A — sinais faciais | 32 | Movimentos aproximados de sobrancelhas, olhos, boca e outras regiões |
| B — posição da cabeça | 12 | Direção e movimento da cabeça |
| C — olhar | 24 | Direção, estabilidade e mudanças do olhar |
| D — olhos | 16 | Abertura dos olhos, piscadas e sinais de sonolência |
| E — boca | 8 | Abertura da boca e sinal aproximado de bocejo |
| F — postura | 24 | Posição e movimento da parte superior do corpo |
| G — qualidade | 4 | Indica se rosto, pose e iluminação estavam utilizáveis |
| **Total** | **120** | Uma descrição matemática do frame |

### 4.3 O que acontece quando algo não é detectado?

Se uma parte não puder ser observada, a feature correspondente recebe `NaN`, que significa “valor indisponível”.

O frame não é descartado, pois isso quebraria a continuidade temporal. No servidor de inferência atual, valores `NaN` ou infinitos são substituídos por zero antes de passar pelo scaler, PCA e LSTM. As features de qualidade informam ao modelo que parte da observação estava ausente.

### 4.4 Buffer e LSTM

Cada participante possui seu próprio buffer. O Python:

1. acumula 30 frames processados;
2. seleciona os 30 frames mais recentes;
3. aplica o scaler;
4. aplica o PCA;
5. envia a sequência para a LSTM;
6. produz uma nova previsão a cada 15 frames processados.

Depois, a extensão suaviza as últimas cinco previsões de cada fonte e calcula a média das fontes analisadas.

### 4.5 Os quatro índices

O modelo retorna quatro indicadores independentes:

- Engajamento;
- Tédio;
- Confusão;
- Frustração.

Cada indicador possui quatro níveis possíveis:

```text
muito baixo → baixo → alto → muito alto
```

O percentual mostrado é uma intensidade estimada a partir desses níveis. Por exemplo:

```text
Engajamento: 72%
```

Isso não significa “72% das pessoas estão engajadas” e também não significa “72% de certeza”. É a posição estimada do engajamento na escala de muito baixo a muito alto.

A confiança é mostrada separadamente e representa quanto o modelo concentrou sua resposta em um dos quatro níveis daquela reação.

Os quatro índices não precisam somar 100%, pois são avaliados separadamente.

### 4.6 Farol

O painel escolhe o maior dos quatro índices como leitura predominante:

| Predominante | Cor |
|---|---|
| Engajamento | Verde |
| Confusão | Amarelo |
| Tédio | Vermelho |
| Frustração | Vermelho |

Se o maior índice ainda estiver abaixo de 50%, o farol permanece cinza, indicando que não existe uma leitura forte.

---

## 5. Como instalar a partir de `mindflow-integration.zip`

### 5.1 Requisitos

Cada integrante precisa ter:

- Windows 10 ou 11;
- Google Chrome atualizado;
- Python 3.11 de 64 bits;
- internet na primeira instalação das bibliotecas;
- conta cadastrada no site MindFlow;
- acesso ao mesmo projeto Supabase para testar o histórico compartilhado.

> Recomendamos Python 3.11 porque esta é a versão em que o projeto e os 26 testes automatizados foram executados com sucesso.

### 5.2 Extrair o ZIP

Extraia completamente o arquivo. Não execute os arquivos diretamente de dentro do ZIP.

Exemplo de pasta:

```text
C:\MindFlow\mindflow-integration
```

Dentro dela devem existir pelo menos:

```text
mindflow-integration\
├── extension\
├── mindflow_extractor\
├── models\
│   └── apresentacao_TCC\
│       ├── lstm_mindflow.pt
│       ├── scaler.joblib
│       └── pca.joblib
├── requirements.txt
└── GUIA_MINDFLOW_INTEGRACAO.md
```

### 5.3 Criar o ambiente Python

Abra o PowerShell dentro da pasta `mindflow-integration` e execute:

```powershell
py -3.11 -m venv .venv
```

Depois instale as bibliotecas:

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

A instalação pode demorar porque inclui MediaPipe, OpenCV, PyTorch e scikit-learn.

> A pasta `.venv` de outro computador não deve ser reutilizada. Cada integrante deve criar o próprio ambiente virtual.

### 5.4 Testar a instalação

Execute:

```powershell
.\.venv\Scripts\python.exe -m pytest tests -q
```

O resultado esperado atualmente é:

```text
26 passed
```

---

## 6. Como executar extensão + Python

### Forma recomendada para a equipe

Depois de criar a `.venv` e instalar as dependências, dê dois cliques em:

```text
iniciar_mindflow.bat
```

Esse arquivo inicia o servidor local com o histórico do Supabase configurado para o projeto MindFlow. A janela deve permanecer aberta durante a reunião.

Depois que a extensão fizer login e registrar a reunião, o painel deverá mudar de **Histórico Supabase: desativado** para **Histórico Supabase: ativo**.

### 6.1 Teste simples, sem salvar histórico

Para testar somente a análise ao vivo:

```powershell
.\.venv\Scripts\python.exe -m mindflow_extractor.runners.extension_server
```

O terminal deve mostrar algo semelhante a:

```text
Modelo carregado: ...\models\apresentacao_TCC
Histórico Supabase desativado...
MindFlow local em http://127.0.0.1:8765 | alvo=6 FPS
```

Nesse modo o painel funciona, mas as inferências não são gravadas no Supabase.

### 6.2 Execução completa, com histórico no Supabase

No PowerShell, informe as configurações fornecidas pelo responsável pelo projeto:

```powershell
$env:MINDFLOW_SUPABASE_URL = "https://SEU-PROJETO.supabase.co"
$env:MINDFLOW_SUPABASE_ANON_KEY = "SUA-CHAVE-ANON"
$env:MINDFLOW_CONSENT_VERSION = "v1"
.\.venv\Scripts\python.exe -m mindflow_extractor.runners.extension_server
```

Não é necessário informar manualmente o código da reunião. Depois do login, a extensão cria ou encontra a sessão e envia o código ao Python.

Essas variáveis valem apenas para a janela atual do PowerShell. Se o terminal for fechado, devem ser configuradas novamente na próxima execução.

Nunca use ou distribua uma chave `service_role`. O protótipo foi preparado para usar a chave pública `anon` junto das políticas e funções do banco.

### 6.3 Instalar a extensão no Chrome

1. Abra o Chrome.
2. Digite `chrome://extensions` na barra de endereço.
3. Ative **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação**.
5. Selecione a pasta `mindflow-integration\extension`.
6. Confirme que aparece **MindFlow AI — Controle Local**, versão 1.6.3.
7. Abra ou recarregue uma página do Google Meet.

O Chrome deve receber a pasta extraída, e não o arquivo ZIP.

Quando houver uma atualização no código da extensão, volte a `chrome://extensions` e clique no botão de recarregar da extensão.

### 6.4 Usar durante uma reunião

1. Deixe o terminal do Python aberto.
2. Entre em uma reunião do Google Meet.
3. Faça login no painel MindFlow usando a mesma conta do site.
4. Aguarde a mensagem de Python conectado e histórico ativo, quando configurado.
5. Confira quais fontes foram bloqueadas como apresentador ou tela.
6. Confirme que participantes permitidos aparecem como **IA ATIVA**; use **Ignorar análise** quando necessário.
7. Aguarde pelo menos 30 frames realmente processados, cerca de cinco segundos no alvo atual.
8. Observe o farol, os índices, a confiança e o gráfico.
9. Ao sair da reunião, aguarde a indicação de histórico concluído.
10. Abra o site e consulte o dashboard com a mesma conta.

---

## 7. Como executar somente o Python

O Python pode ser usado sem a extensão para validar o extrator. Existem duas formas principais.

### 7.1 Testar a webcam

```powershell
.\.venv\Scripts\python.exe -m mindflow_extractor.runners.webcam_runner
```

Uma janela mostrará:

- malha do rosto;
- esqueleto da pose;
- abertura dos olhos e da boca;
- direção da cabeça e do olhar;
- piscada, bocejo e estabilidade;
- FPS de processamento.

Atalhos:

| Tecla | Ação |
|---|---|
| `Q` ou `Esc` | Fechar |
| `S` | Salvar screenshot de diagnóstico |
| `R` | Limpar buffer temporal |
| `L` | Mostrar ou ocultar FaceMesh |
| `P` | Mostrar ou ocultar Pose |

> Esse modo é uma ferramenta de diagnóstico das 120 features. Ele não mostra as quatro previsões finais da LSTM.

### 7.2 Processar um vídeo gravado

```powershell
.\.venv\Scripts\python.exe -m mindflow_extractor.runners.video_runner single `
  --video "C:\caminho\video.mp4" `
  --output "outputs\teste"
```

O Python cria:

- um arquivo `.npy` com um vetor de 120 features por frame;
- um arquivo `_metadata.json` com qualidade, detecções e quantidade de `NaN`.

Esse comando extrai features, mas não gera sozinho o dashboard do site.

### 7.3 Servidor local sem abrir o Meet

Também é possível iniciar apenas o servidor:

```powershell
.\.venv\Scripts\python.exe -m mindflow_extractor.runners.extension_server
```

Ele ficará aguardando requisições em `127.0.0.1:8765`. Sem a extensão ou outro cliente enviando frames, nenhuma análise será realizada.

### Sobre o arquivo `run.py`

O `run.py` abre a demonstração de webcam, não o servidor utilizado pela extensão. Para evitar confusão no Windows, prefira sempre os comandos explícitos apresentados neste guia.

---

## 8. Supabase e site

### O que a extensão faz no banco?

Depois do login, a extensão:

1. cria a reunião na tabela de sessões;
2. salva o título e o código;
3. marca a sessão como `em_andamento`;
4. envia um sinal de presença aproximadamente a cada 15 segundos;
5. informa ao Python qual código usar no histórico;
6. marca a reunião como `encerrada` ao detectar a saída do Meet.

### O que o Python faz no banco?

Quando o histórico está configurado, o Python:

1. cria um participante anônimo para a fonte;
2. registra as probabilidades das quatro reações;
3. inclui qualidade de face, pose e latência;
4. encerra a participação quando a fonte é ignorada ou removida.

O envio ao banco é feito em uma fila separada. Uma demora do Supabase não deve travar a resposta ao vivo da extensão.

### O que o site faz?

O site não inicia a reunião. A reunião nasce no Meet por meio da extensão.

O site:

- mostra a mensagem **Você está em uma reunião** enquanto o sinal estiver recente;
- lista reuniões vinculadas à conta;
- lê resumos e linhas do tempo;
- mostra dashboards depois da reunião;
- salva preferências visuais que a extensão sincroniza.

A extensão e o site não conversam diretamente entre abas. Os dois usam o Supabase como ponte.

### Configuração única do projeto

O responsável pelo Supabase deve executar os scripts SQL do projeto uma vez. Os demais integrantes não precisam recriar as tabelas em seus computadores.

Os scripts de integração ficam na pasta:

```text
supabase\
```

---

## 9. O que mudou em relação ao `mindflow_sem_data_set`?

O `mindflow_sem_data_set` era principalmente um extrator e ambiente de treinamento. Ele já possuía MediaPipe, vetor de 120 features, processamento de webcam/vídeo, treinamento e os artefatos do modelo.

O `mindflow-integration` transformou essa base em um protótipo utilizável durante uma reunião.

| Antes: `mindflow_sem_data_set` | Agora: `mindflow-integration` |
|---|---|
| Webcam ou vídeo executados diretamente pelo Python | Google Meet envia fontes autorizadas ao Python local |
| Não havia extensão final integrada | Extensão Manifest V3 com painel dentro do Meet |
| Não havia login na extensão | Login obrigatório usando a conta do site |
| Não havia controle visual por fonte no Meet | Fontes anônimas, análise automática com `Ignorar/Retomar` e bloqueio de tela/apresentador |
| Não havia servidor HTTP próprio para a extensão | Servidor local com `/health`, `/frame`, `/reset` e `/history/session` |
| Extração das 120 features | Extração mantida e conectada ao modelo em tempo real |
| Modelo usado por runners experimentais | Novo carregador dedicado: scaler → PCA → LSTM de quatro saídas |
| Sem vínculo automático com uma reunião do site | Extensão cria sessão, título, código, presença e encerramento |
| Sem histórico integrado da extensão | Escritor assíncrono envia inferências numéricas ao Supabase |
| Sem painel coletivo no Meet | Média do grupo, suavização, farol e gráfico de cinco minutos |
| Sem sincronização visual | Tema, tamanho e informações visíveis configuráveis pelo site |
| Processamento DAiSEE sujeito a erro no cabeçalho `Frustration ` | Cabeçalhos normalizados e quatro rótulos preservados no metadata |
| Métrica de treino multi-output favorecia Engajamento | Checkpoint usa média das quatro tarefas e recarrega a melhor época |
| Sem piloto organizado de 30 FPS | Ferramenta de piloto a 30 FPS, seleção balanceada, cache e `--workers` |
| Poucos testes de integração | Testes do modelo, payload do Supabase e contrato da extensão |

Também foram removidos da rota principal alguns runners experimentais antigos. Para o protótipo atual, o caminho oficial é:

```text
Google Meet → extensão → extension_server.py → modelo → extensão/Supabase
```

### O que não mudou?

O núcleo das 120 features continua baseado nos mesmos blocos A–G.

Mais importante: os arquivos distribuídos atualmente em `models\apresentacao_TCC` são os mesmos artefatos que já existiam em `mindflow_sem_data_set`:

- `lstm_mindflow.pt`;
- `scaler.joblib`;
- `pca.joblib`;
- `metrics.json`.

Portanto:

> A integração ficou muito mais completa, mas o modelo oficial da extensão ainda não foi substituído por um novo treinamento definitivo.

Foram realizados treinos-piloto a 30 FPS e eles permanecem separados em `outputs\training\runs`. Esses pilotos não foram promovidos automaticamente para a pasta `models\apresentacao_TCC`.

A diferença temporal imediata foi corrigida na versão 1.6.3:

- o modelo oficial atual veio de uma configuração em que 30 frames representavam aproximadamente cinco segundos, pois a extração pulava frames e trabalhava perto de 6 FPS;
- o servidor e a extensão agora usam alvo de 6 FPS e fazem inferência com 30 frames, aproximadamente cinco segundos;
- a ferramenta nova de piloto a 30 FPS usa 150 frames para preservar cinco segundos, mas o servidor distribuído ainda está configurado para sequências de 30 frames.

Treino oficial e uso real agora possuem duração temporal semelhante. O piloto de 30 FPS continua experimental e só poderá ser promovido junto com uma alteração do servidor para 150 frames e nova validação.

Antes de trocar o modelo oficial, ainda é necessário:

1. escolher um treino com quantidade suficiente de vídeos;
2. garantir que a duração da sequência usada no treino é compatível com a sequência usada no servidor;
3. avaliar em vídeos de teste nunca vistos durante o treino;
4. analisar F1 por classe e matrizes de confusão;
5. copiar scaler, PCA e LSTM do mesmo treino, sempre juntos;
6. repetir os testes da extensão.

---

## 10. Situação atual da precisão

O modelo existente foi treinado e produz resultados, mas deve continuar sendo tratado como protótipo acadêmico.

As métricas atualmente distribuídas mostram acurácia aproximada de:

| Indicador | Acurácia registrada | F1 macro |
|---|---:|---:|
| Engajamento | 49,5% | 26,1% |
| Tédio | 29,3% | 19,6% |
| Confusão | 40,1% | 20,7% |
| Frustração | 59,4% | 24,6% |

Esses números não devem ser usados sozinhos para dizer que o modelo está “59% correto”. O DAiSEE é desbalanceado: há muitos exemplos em alguns níveis e poucos em outros. Por isso o F1 macro e a matriz de confusão são importantes.

O sistema deve ser apresentado como:

- indicador experimental de sinais visuais;
- apoio ao apresentador;
- leitura coletiva aproximada;
- tecnologia ainda em validação.

Ele não deve ser apresentado como detector infalível de emoção, verdade ou intenção.

---

## 11. Problemas comuns

### O painel mostra “Python desconectado”

Confira se o terminal continua aberto e se aparece:

```text
MindFlow local em http://127.0.0.1:8765
```

Se não aparecer, inicie novamente:

```powershell
.\.venv\Scripts\python.exe -m mindflow_extractor.runners.extension_server
```

### O terminal mostra “inferência desativada”

Confira se existem os três arquivos:

```text
models\apresentacao_TCC\lstm_mindflow.pt
models\apresentacao_TCC\scaler.joblib
models\apresentacao_TCC\pca.joblib
```

### A extensão não mostra resultados

Verifique:

1. se o login foi realizado;
2. se o Python está conectado;
3. se a fonte aparece como **IA ATIVA** e não foi ignorada;
4. se já foram processados pelo menos 30 frames;
5. se o rosto está visível e iluminado.

### O histórico aparece como desativado

O Python provavelmente foi iniciado sem as três variáveis do Supabase:

- `MINDFLOW_SUPABASE_URL`;
- `MINDFLOW_SUPABASE_ANON_KEY`;
- `MINDFLOW_CONSENT_VERSION`.

### A reunião não aparece no site

Confira se:

- extensão e site usam a mesma conta;
- o computador está conectado à internet;
- os scripts SQL foram executados no Supabase;
- o painel informou que o histórico estava ativo;
- a página do site foi atualizada após o encerramento.

### O título está errado

Clique no título ao lado de **MindFlow AI**, digite o nome correto e confirme.

### A reunião continua “em andamento” depois da saída

Atualize o dashboard. Se a saída explícita do Meet não tiver sido detectada, o site verifica o último sinal da extensão e encerra sessões antigas após o período de segurança.

### O FPS está abaixo de 30

Isso não é necessariamente um erro. Reduza a quantidade de fontes analisadas, feche programas pesados e confira a resolução dos vídeos. Cinco participantes podem exigir bastante CPU porque cada um possui MediaPipe e buffer próprios.

---

## 12. Como preparar o ZIP para os outros integrantes

O ZIP distribuído deve conter código e modelo, mas não precisa carregar arquivos pessoais ou temporários.

Inclua:

- `extension\`;
- `mindflow_extractor\`;
- `models\apresentacao_TCC\`;
- `tests\`;
- `training\` e `tools\`, caso a equipe também vá treinar;
- `supabase\`;
- `requirements.txt`;
- `iniciar_mindflow.bat`;
- este guia.

Evite incluir:

- `.venv\`;
- `.git\`;
- `__pycache__\`;
- backups antigos da extensão;
- vídeos do DAiSEE;
- outputs grandes de treino que não serão usados;
- chaves `service_role` ou senhas.

Uma estrutura enxuta reduz o tamanho do download e evita problemas entre computadores diferentes.

---

## 13. Resumo para quem vai testar pela primeira vez

```text
1. Extrair mindflow-integration.zip
2. Instalar Python 3.11
3. Criar .venv
4. Instalar requirements.txt
5. Configurar as variáveis do Supabase, se quiser histórico
6. Iniciar extension_server
7. Carregar a pasta extension no Chrome
8. Abrir o Google Meet
9. Entrar na conta MindFlow
10. Autorizar somente os participantes corretos
11. Acompanhar o painel
12. Sair da reunião
13. Consultar o dashboard no site
```

O terminal do Python deve permanecer aberto enquanto a extensão estiver sendo usada.

---

## 14. Limitações conhecidas

- O Python precisa estar instalado localmente. Em uma versão pública futura, ele poderá ser substituído por um serviço servidor, mas isso exigirá decisões de custo, latência e privacidade.
- Cinco participantes podem pesar em computadores mais simples.
- O Google pode alterar o HTML do Meet e exigir ajustes na detecção de fontes ou título.
- O título nem sempre é disponibilizado pelo Meet; por isso existe a correção manual.
- O alvo de 6 FPS pode não ser alcançado em todas as fontes.
- O modelo oficial ainda precisa de novo treinamento e validação mais fortes.
- Os índices representam estimativas visuais, não diagnóstico psicológico.
- O sistema não deve ser usado para tomar decisões automáticas sobre pessoas.

---

## 15. Glossário rápido

| Termo | Significado simples |
|---|---|
| Frame | Uma imagem individual do vídeo |
| FPS | Quantidade de frames processados por segundo |
| Landmark | Ponto localizado no rosto ou corpo |
| Feature | Número calculado a partir dos landmarks |
| MediaPipe | Biblioteca que localiza rosto e pose |
| Buffer | Memória temporária dos frames recentes |
| Scaler | Padroniza os números para o formato esperado pelo modelo |
| PCA | Reduz a quantidade de informações antes da LSTM |
| LSTM | Modelo que analisa uma sequência ao longo do tempo |
| Inferência | Momento em que o modelo calcula uma resposta |
| Supabase | Banco e autenticação usados pelo projeto |
| Netlify | Serviço onde o site pode ser publicado |
| `NaN` | Indicação de que uma medida não pôde ser calculada |

---

## Conclusão

O `mindflow-integration` não é apenas um novo treinamento do Python. Ele é a união da base de visão computacional já existente com uma extensão controlada, autenticação, persistência e visualização no site.

O fluxo atual preserva a ideia principal do projeto:

```text
observar sinais visuais sem identificar pessoas,
transformar imagens temporárias em números,
mostrar uma leitura coletiva ao apresentador
e guardar apenas o histórico necessário.
```

Para demonstração e TCC, o conjunto já permite testar o caminho completo. Para uso real em produção, os próximos trabalhos principais são retreinar e validar melhor o modelo, medir desempenho em diferentes computadores e revisar continuamente privacidade e consentimento.
