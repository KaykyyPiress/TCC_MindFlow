const PYTHON_BASE_URL = "http://127.0.0.1:8765";

async function fetchJson(path, options = {}, timeoutMs = 8000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${PYTHON_BASE_URL}${path}`, {
      ...options,
      signal: controller.signal
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(payload.message || payload.error || `HTTP ${response.status}`);
    }
    return payload;
  } finally {
    clearTimeout(timeout);
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "MINDFLOW_HEALTH") {
    fetchJson("/health", {}, 2500)
      .then(data => sendResponse({ success: true, python: data }))
      .catch(error => sendResponse({ success: false, error: String(error) }));
    return true;
  }

  if (message?.type === "MINDFLOW_PROCESS_FRAME") {
    fetchJson("/frame", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(message.payload)
    })
      .then(data => sendResponse({ success: true, python: data }))
      .catch(error => sendResponse({ success: false, error: String(error) }));
    return true;
  }

  if (message?.type === "MINDFLOW_RESET_PARTICIPANT") {
    const id = encodeURIComponent(message.participantId || "");
    fetchJson(`/reset/${id}`, { method: "POST" })
      .then(data => sendResponse({ success: true, python: data }))
      .catch(error => sendResponse({ success: false, error: String(error) }));
    return true;
  }

  return false;
});

